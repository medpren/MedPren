# M'MEDPREN Platform V3 — édition adaptée à la nouvelle identité

Cette archive reprend **le backend V3 PostgreSQL/FastAPI** et adapte les interfaces Web/PWA, Admin et Flutter au nouveau système visuel M'MEDPREN : **orange, pêche douce, noir charbon et gris clair**, avec le symbole cerveau–ampoule.

## Identité visuelle intégrée
- Orange principal : `#F7934A`
- Orange accent : `#FF6B1A`
- Pêche douce : `#FFD8B8`
- Noir charbon : `#1F1F1F`
- Gris clair : `#F7F7F5`
- Signature : **Work4Future • Mundu ku Gundi**
- Logo SVG redessiné et adapté au numérique

Les planches approuvées sont conservées dans `docs/visual-reference/` pour servir de référence aux développeurs.

## Ce qui est maintenant visible dans l’interface
### Web/PWA
- accueil conforme au nouveau design
- navigation desktop + navigation mobile
- Marché avec vraies images de produits **Poules Élevage**
- fiche produit
- panier
- checkout / paiement
- authentification téléphone + OTP
- espace vendeur
- création produit vendeur
- Work4Future : emplois + formations
- Services
- M'MEDPREN Business : statistiques et outils
- Mundu ku Gundi / Impact
- profil utilisateur
- assistant M'MEDPREN

### Administration
- connexion OTP
- tableau de bord orange/pêche/noir
- indicateurs utilisateurs, vendeurs, produits, commandes et paiements
- validation/suspension des vendeurs
- activité récente

### Flutter
- écran OTP conforme à la maquette
- écran d’accueil
- Marché connecté à la même API
- fiches produits avec images locales
- Work4Future Jobs
- Business analytics
- Profil
- navigation mobile principale

## Backend conservé et testé
- FastAPI
- PostgreSQL 16
- Redis
- Alembic
- JWT
- OTP
- rôles : client / vendeur / livreur / admin
- vendeurs et boutiques
- catalogue et stock
- commandes
- paiement sandbox + adaptateurs M-Pesa / Airtel / Orange
- livraison
- administration

Le seed de démonstration utilise maintenant **Poules Élevage — Ets Mundu ku Gundi W4F** avec plusieurs équipements visibles dans le Market.

## Démarrage complet
### 1. Configuration
```bash
cp .env.example .env
```
Remplacer au minimum :
```env
SECRET_KEY=une-cle-longue-et-aleatoire
```

### 2. Backend + PostgreSQL + Redis
```bash
docker compose up --build
```

- API : `http://localhost:8000`
- Swagger : `http://localhost:8000/docs`
- Health : `http://localhost:8000/health`

Le conteneur API lance automatiquement :
```bash
alembic upgrade head
python -m app.seed
```

### 3. Interface Web/PWA
```bash
cd web-pwa
python -m http.server 8080
```
Puis ouvrir `http://localhost:8080`.

### 4. Administration
```bash
cd admin-web
python -m http.server 8081
```
Puis ouvrir `http://localhost:8081`.

### 5. Application Flutter
```bash
cd mobile-flutter
flutter pub get
flutter run
```
Sur Android Emulator, l’API par défaut est `http://10.0.2.2:8000/api/v1`.

## Compte admin en développement
Après avoir créé un utilisateur via OTP :
```bash
cd backend
python -m app.promote_admin +243XXXXXXXXX
```

## Paiements
`sandbox` fonctionne en développement. Les adaptateurs `mpesa`, `airtel` et `orange` sont prévus mais exigent des identifiants marchands réels.

**Ne jamais placer les secrets Mobile Money dans le code Web ou Flutter.**

## Références design
Voir :
- `docs/visual-reference/01-identite-marque.png`
- `docs/visual-reference/02-design-systeme.png`
- `docs/visual-reference/03-apercu-interface.png`
- `docs/BRAND_UI.md`
