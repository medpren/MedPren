import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiClient {
  ApiClient({this.baseUrl='http://10.0.2.2:8000/api/v1'});
  final String baseUrl;
  final _storage=const FlutterSecureStorage();
  Future<bool> hasToken() async => (await _storage.read(key:'token')) != null;
  Future<Map<String,String>> _headers() async {
    final token=await _storage.read(key:'token');
    return {'Content-Type':'application/json',if(token!=null)'Authorization':'Bearer $token'};
  }
  Future<dynamic> _send(String method,String path,{Object? body}) async {
    final uri=Uri.parse('$baseUrl$path'); final h=await _headers(); late http.Response r;
    switch(method){case 'POST':r=await http.post(uri,headers:h,body:jsonEncode(body));break;case 'PATCH':r=await http.patch(uri,headers:h,body:jsonEncode(body));break;default:r=await http.get(uri,headers:h);}
    final data=r.body.isEmpty?{}:jsonDecode(r.body);
    if(r.statusCode<200||r.statusCode>=300)throw Exception(data is Map?(data['detail']??'HTTP ${r.statusCode}'):'HTTP ${r.statusCode}');
    return data;
  }
  Future<Map<String,dynamic>> requestOtp(String phone) async=>Map<String,dynamic>.from(await _send('POST','/auth/otp/request',body:{'phone':phone}));
  Future<void> verifyOtp(String challengeId,String code) async{final d=Map<String,dynamic>.from(await _send('POST','/auth/otp/verify',body:{'challenge_id':challengeId,'code':code}));await _storage.write(key:'token',value:d['access_token']);}
  Future<Map<String,dynamic>> me() async=>Map<String,dynamic>.from(await _send('GET','/auth/me'));
  Future<void> logout() async=>_storage.delete(key:'token');
  Future<List<dynamic>> products() async=>List<dynamic>.from(await _send('GET','/products'));
  Future<List<dynamic>> myOrders() async=>List<dynamic>.from(await _send('GET','/orders/mine'));
  Future<Map<String,dynamic>> createOrder(Map<String,dynamic> body) async=>Map<String,dynamic>.from(await _send('POST','/orders',body:body));
  Future<Map<String,dynamic>> pay(Map<String,dynamic> body) async=>Map<String,dynamic>.from(await _send('POST','/payments',body:body));
}
