import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'api_client.dart';

const Color orange = Color(0xFFF7934A);
const Color orangeDeep = Color(0xFFFF6B1A);
const Color peach = Color(0xFFFFD8B8);
const Color ink = Color(0xFF1F1F1F);
const Color background = Color(0xFFF7F7F5);
const Color muted = Color(0xFF7A818B);

String valueOf(dynamic map, String key) => (map is Map ? map[key] : null)?.toString() ?? '';
String productAsset(String name) {
  final n = name.toLowerCase();
  if (n.contains('rouge')) return 'assets/products/abreuvoir-rouge.jpg';
  if (n.contains('abreuvoir')) return 'assets/products/abreuvoir-compact.jpg';
  if (n.contains('grande')) return 'assets/products/mangeoire-grande.jpg';
  if (n.contains('mangeoire')) return 'assets/products/mangeoire-moyenne.jpg';
  return 'assets/products/poules-elevage-campagne.jpg';
}

void main() => runApp(const MMedPrenApp());

class MMedPrenApp extends StatelessWidget {
  const MMedPrenApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "M'MEDPREN",
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(seedColor: orange, primary: orange),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE9E5E1)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE9E5E1)),
          ),
        ),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  final api = ApiClient();
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final hasToken = await api.hasToken();
    if (!mounted) return;
    if (hasToken) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MainShell(api: api)));
    } else {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: orange)));
    }
    return LoginPage(api: api);
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key, required this.api});
  final ApiClient api;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? challenge;
  final phone = TextEditingController(text: '+243');
  final code = TextEditingController();
  String message = '';
  bool busy = false;

  Future<void> _submit() async {
    setState(() => busy = true);
    try {
      if (challenge == null) {
        final data = await widget.api.requestOtp(phone.text);
        setState(() {
          challenge = data['challenge_id']?.toString();
          message = data['debug_code'] != null
              ? 'Code développement : ${data['debug_code']}'
              : 'Code envoyé.';
        });
      } else {
        await widget.api.verifyOtp(challenge!, code.text);
        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => MainShell(api: widget.api)),
          );
        }
      }
    } catch (e) {
      setState(() => message = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  SvgPicture.asset('assets/brand/mark.svg', height: 115),
                  const SizedBox(height: 8),
                  const Text(
                    "M'MEDPREN",
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: ink),
                  ),
                  const Text(
                    'Work4Future • Mundu ku Gundi',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: orangeDeep, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 34),
                  Text(
                    challenge == null ? 'Bon retour' : 'Vérification OTP',
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: ink),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    challenge == null
                        ? 'Entrez votre numéro de téléphone pour recevoir un code de vérification.'
                        : 'Entrez le code reçu sur votre téléphone.',
                    style: const TextStyle(color: muted),
                  ),
                  const SizedBox(height: 18),
                  if (challenge == null)
                    TextField(
                      controller: phone,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: 'Numéro de téléphone',
                        prefixIcon: Icon(Icons.phone_outlined),
                      ),
                    )
                  else
                    TextField(
                      controller: code,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Code OTP',
                        prefixIcon: Icon(Icons.lock_outline),
                      ),
                    ),
                  const SizedBox(height: 13),
                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: orangeDeep,
                      padding: const EdgeInsets.all(15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: busy ? null : _submit,
                    child: Text(
                      busy
                          ? 'Veuillez patienter…'
                          : challenge == null
                              ? 'Envoyer le code →'
                              : 'Se connecter →',
                    ),
                  ),
                  if (message.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(message, style: const TextStyle(color: muted)),
                    ),
                  const SizedBox(height: 22),
                  const Row(
                    children: [
                      Expanded(child: Divider()),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: Text('ou continuer avec'),
                      ),
                      Expanded(child: Divider()),
                    ],
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.g_mobiledata),
                    label: const Text('Continuer avec Google'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.apple),
                    label: const Text('Continuer avec Apple'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.api});
  final ApiClient api;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(api: widget.api, onNavigate: (value) => setState(() => index = value)),
      MarketPage(api: widget.api),
      const WorkPage(),
      const BusinessPage(),
      ProfilePage(api: widget.api),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFFFF1E5),
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home, color: orangeDeep),
            label: 'Accueil',
          ),
          NavigationDestination(
            icon: Icon(Icons.shopping_cart_outlined),
            selectedIcon: Icon(Icons.shopping_cart, color: orangeDeep),
            label: 'Marché',
          ),
          NavigationDestination(
            icon: Icon(Icons.work_outline),
            selectedIcon: Icon(Icons.work, color: orangeDeep),
            label: 'Emplois',
          ),
          NavigationDestination(
            icon: Icon(Icons.business_outlined),
            selectedIcon: Icon(Icons.business, color: orangeDeep),
            label: 'Business',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person, color: orangeDeep),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}

class AppHeader extends StatelessWidget {
  const AppHeader({super.key, this.title});
  final String? title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
      child: Row(
        children: [
          SvgPicture.asset('assets/brand/mark.svg', height: 42),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title ?? "M'MEDPREN",
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: ink),
                ),
                if (title == null)
                  const Text(
                    'Work4Future • Mundu ku Gundi',
                    style: TextStyle(color: orangeDeep, fontWeight: FontWeight.w700, fontSize: 10),
                  ),
              ],
            ),
          ),
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          const CircleAvatar(
            backgroundColor: orange,
            child: Text('AF', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.api, required this.onNavigate});
  final ApiClient api;
  final ValueChanged<int> onNavigate;

  Widget _quick(IconData icon, String label, VoidCallback tap) {
    return Expanded(
      child: InkWell(
        onTap: tap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1E5),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: orangeDeep),
              ),
              const SizedBox(height: 5),
              Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _productMini(dynamic product) {
    final name = valueOf(product, 'name');
    return SizedBox(
      width: 165,
      child: Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(productAsset(name), height: 120, width: double.infinity, fit: BoxFit.cover),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${valueOf(product, 'price')} ${valueOf(product, 'currency')}',
                    style: const TextStyle(fontWeight: FontWeight.w900, color: orangeDeep),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        const AppHeader(),
        Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Bonjour,', style: TextStyle(color: muted)),
              const Text(
                'Un avenir meilleur est possible.',
                style: TextStyle(fontSize: 30, height: 1.02, fontWeight: FontWeight.w900, color: ink),
              ),
              const SizedBox(height: 15),
              const TextField(
                decoration: InputDecoration(
                  hintText: 'Rechercher produits, services, emplois…',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  _quick(Icons.shopping_cart_outlined, 'Marché', () => onNavigate(1)),
                  _quick(Icons.groups_outlined, 'Services', () {}),
                  _quick(Icons.work_outline, 'Work4Future', () => onNavigate(2)),
                  _quick(Icons.business_outlined, 'Business', () => onNavigate(3)),
                ],
              ),
              const SizedBox(height: 20),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(
                  children: [
                    Image.asset(
                      'assets/products/work4future-poules-hero.jpg',
                      height: 230,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                    Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [Colors.black.withOpacity(.72), Colors.transparent]),
                        ),
                      ),
                    ),
                    const Positioned(
                      left: 18,
                      bottom: 18,
                      right: 110,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Des idées aujourd’hui.\nUn avenir plus lumineux.',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 25,
                              height: 1.05,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Mundu ku Gundi',
                            style: TextStyle(color: Color(0xFFFFC28F), fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              const Text('Produits en vedette', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: ink)),
              const SizedBox(height: 10),
              FutureBuilder<List<dynamic>>(
                future: api.products(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return const LinearProgressIndicator(color: orange);
                  return SizedBox(
                    height: 218,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: snapshot.data!.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (context, index) => _productMini(snapshot.data![index]),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class MarketPage extends StatefulWidget {
  const MarketPage({super.key, required this.api});
  final ApiClient api;
  @override
  State<MarketPage> createState() => _MarketPageState();
}

class _MarketPageState extends State<MarketPage> {
  late Future<List<dynamic>> products;

  @override
  void initState() {
    super.initState();
    products = widget.api.products();
  }

  void _detail(BuildContext context, dynamic product) {
    final name = valueOf(product, 'name');
    final description = valueOf(product, 'description').isEmpty
        ? "Produit disponible sur M'MEDPREN."
        : valueOf(product, 'description');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Image.asset(productAsset(name), height: 260, width: double.infinity, fit: BoxFit.cover),
            ),
            const SizedBox(height: 14),
            Text(name, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: ink)),
            Text(
              '${valueOf(product, 'price')} ${valueOf(product, 'currency')}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: orangeDeep),
            ),
            const SizedBox(height: 7),
            Text(description, style: const TextStyle(color: muted)),
            const SizedBox(height: 14),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: orangeDeep, minimumSize: const Size.fromHeight(50)),
              onPressed: () => Navigator.pop(context),
              child: const Text('Ajouter au panier'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const AppHeader(title: 'Marché'),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 18),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Rechercher produits, artisanat, services…',
              prefixIcon: Icon(Icons.search),
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 38,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            children: ['Tous', 'Élevage', 'Santé', 'Tech', 'Mode']
                .map(
                  (label) => Padding(
                    padding: const EdgeInsets.only(right: 7),
                    child: Chip(
                      label: Text(label),
                      backgroundColor: label == 'Tous' ? orange : Colors.white,
                      labelStyle: TextStyle(color: label == 'Tous' ? Colors.white : ink),
                    ),
                  ),
                )
                .toList(),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<dynamic>>(
            future: products,
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: orange));
              return GridView.builder(
                padding: const EdgeInsets.all(18),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: .68,
                ),
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final product = snapshot.data![index];
                  final name = valueOf(product, 'name');
                  return Card(
                    clipBehavior: Clip.antiAlias,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    child: InkWell(
                      onTap: () => _detail(context, product),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Image.asset(productAsset(name), width: double.infinity, fit: BoxFit.cover),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  name,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  '${valueOf(product, 'price')} ${valueOf(product, 'currency')}',
                                  style: const TextStyle(color: orangeDeep, fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 2),
                                const Text('★ 4,8 • vendeur vérifié', style: TextStyle(fontSize: 9, color: muted)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class WorkPage extends StatelessWidget {
  const WorkPage({super.key});

  @override
  Widget build(BuildContext context) {
    const jobs = [
      'Assistant marketing — Bukavu • Temps plein',
      'Graphiste — Remote • Freelance',
      'Agent de terrain — Bukavu • CDD',
      'Développeur Web junior — Remote • Stage',
      'Assistant Data — Bukavu • CDD',
    ];
    return ListView(
      children: [
        const AppHeader(title: 'Work4Future'),
        Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Trouver du travail.\nDévelopper ses compétences.',
                style: TextStyle(fontSize: 30, height: 1.05, fontWeight: FontWeight.w900, color: ink),
              ),
              const SizedBox(height: 12),
              const TextField(
                decoration: InputDecoration(
                  hintText: 'Rechercher un emploi, un domaine…',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
              const SizedBox(height: 18),
              ...jobs.map((job) {
                final parts = job.split(' — ');
                return Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: ListTile(
                    leading: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF1E5),
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: const Icon(Icons.work_outline, color: orangeDeep),
                    ),
                    title: Text(parts.first, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(parts.length > 1 ? parts[1] : ''),
                    trailing: const Icon(Icons.bookmark_border),
                  ),
                );
              }),
            ],
          ),
        ),
      ],
    );
  }
}

class BusinessPage extends StatelessWidget {
  const BusinessPage({super.key});

  Widget _stat(String label, String value, String growth) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: muted)),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: ink)),
            Text('↑ $growth', style: const TextStyle(fontSize: 10, color: Color(0xFF118A5B))),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const heights = [35, 62, 45, 78, 55, 88, 72, 96];
    return ListView(
      children: [
        const AppHeader(title: 'Business'),
        Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Analytique Business', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: ink)),
              const Text('Suivre la croissance et mieux décider.', style: TextStyle(color: muted)),
              const SizedBox(height: 17),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.6,
                children: [
                  _stat('Ventes', '1 892 USD', '+12%'),
                  _stat('Commandes', '256', '+18%'),
                  _stat('Clients', '198', '+15%'),
                  _stat('Conversion', '3,6%', '+0,8%'),
                ],
              ),
              const SizedBox(height: 15),
              Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Évolution des ventes', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 180,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: heights
                              .map(
                                (height) => Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 4),
                                    child: Container(
                                      height: height * 1.6,
                                      decoration: BoxDecoration(color: orange, borderRadius: BorderRadius.circular(6)),
                                    ),
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key, required this.api});
  final ApiClient api;
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late Future<Map<String, dynamic>> profile;

  @override
  void initState() {
    super.initState();
    profile = widget.api.me();
  }

  Widget _row(IconData icon, String title, String subtitle) {
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: orangeDeep),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: profile,
      builder: (context, snapshot) {
        final name = snapshot.hasData && valueOf(snapshot.data, 'full_name').isNotEmpty
            ? valueOf(snapshot.data, 'full_name')
            : "Profil M'MEDPREN";
        final phone = snapshot.hasData ? valueOf(snapshot.data, 'phone') : '';
        return ListView(
          children: [
            const AppHeader(title: 'Mon compte'),
            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Card(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Row(
                        children: [
                          const CircleAvatar(
                            radius: 31,
                            backgroundColor: orange,
                            child: Text('AF', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: ink)),
                                Text(phone, style: const TextStyle(color: muted)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _row(Icons.shopping_bag_outlined, 'Mes commandes', 'Historique et suivi'),
                  _row(Icons.storefront_outlined, 'Ma boutique', 'Produits et ventes'),
                  _row(Icons.work_outline, 'Work4Future', 'Candidatures et compétences'),
                  const SizedBox(height: 20),
                  OutlinedButton(
                    onPressed: () async {
                      await widget.api.logout();
                      if (context.mounted) {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (_) => LoginPage(api: widget.api)),
                          (_) => false,
                        );
                      }
                    },
                    child: const Text('Se déconnecter'),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}
