# M'MEDPREN Flutter — interface adaptée

L’application mobile reprend la nouvelle charte :
- orange `#F7934A`
- accent `#FF6B1A`
- pêche `#FFD8B8`
- noir `#1F1F1F`
- fond `#F7F7F5`

Écrans présents :
1. connexion téléphone + OTP
2. accueil
3. Marché connecté à `/api/v1/products`
4. détail produit
5. Work4Future Jobs
6. Business analytics
7. profil

Les visuels Poules Élevage sont inclus dans `assets/products/`.

## Lancer
```bash
flutter pub get
flutter analyze
flutter run
```

Sur Android Emulator, l’API utilise par défaut :
`http://10.0.2.2:8000/api/v1`
