const API_BASE = localStorage.getItem('mmedpren-api') || 'http://localhost:8000/api/v1';
const MPApi = {
  token(){ return localStorage.getItem('mmedpren-token'); },
  headers(){ const h={'Content-Type':'application/json'}; if(this.token())h.Authorization=`Bearer ${this.token()}`; return h; },
  async request(path,opts={}){
    const r=await fetch(API_BASE+path,{...opts,headers:{...this.headers(),...(opts.headers||{})}});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.detail||`HTTP ${r.status}`);
    return data;
  },
  products(q='',category=''){
    const p=new URLSearchParams(); if(q)p.set('q',q); if(category)p.set('category',category);
    return this.request('/products'+(p.toString()?`?${p}`:''));
  },
  product(id){ return this.request(`/products/${id}`); },
  requestOtp(phone){ return this.request('/auth/otp/request',{method:'POST',body:JSON.stringify({phone})}); },
  async verifyOtp(challenge_id,code){ const d=await this.request('/auth/otp/verify',{method:'POST',body:JSON.stringify({challenge_id,code})}); localStorage.setItem('mmedpren-token',d.access_token); return d; },
  me(){ return this.request('/auth/me'); },
  updateMe(body){ return this.request('/auth/me',{method:'PATCH',body:JSON.stringify(body)}); },
  logout(){ localStorage.removeItem('mmedpren-token'); },
  sellerApply(body){ return this.request('/sellers/apply',{method:'POST',body:JSON.stringify(body)}); },
  sellerMe(){ return this.request('/sellers/me'); },
  createProduct(body){ return this.request('/products',{method:'POST',body:JSON.stringify(body)}); },
  updateProduct(id,body){ return this.request(`/products/${id}`,{method:'PATCH',body:JSON.stringify(body)}); },
  createOrder(body){ return this.request('/orders',{method:'POST',body:JSON.stringify(body)}); },
  ordersMine(){ return this.request('/orders/mine'); },
  pay(body){ return this.request('/payments',{method:'POST',body:JSON.stringify(body)}); },
  payment(id){ return this.request(`/payments/${id}`); },
  sandboxSucceed(paymentId){ return this.request(`/payments/${paymentId}/sandbox/succeed`,{method:'POST'}); },
  adminDashboard(){ return this.request('/admin/dashboard'); },
  adminSellers(){ return this.request('/admin/sellers'); },
  adminSellerDecision(id,status){ return this.request(`/admin/sellers/${id}`,{method:'PATCH',body:JSON.stringify({status})}); }
};
window.MPApi=MPApi;
