const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const navItems = [
  ['home','⌂','Accueil'],['market','🛒','Marché'],['services','👥','Services'],['work','💼','Work4Future'],
  ['business','▦','Business'],['impact','↗','Impact'],['profile','◉','Mon compte']
];
const bottomItems=['home','market','work','business','profile'];
const modules=[
  ['market','🛒','Marché','Acheter. Vendre. Grandir.'],['services','👥','Services','Trouver et offrir des compétences.'],
  ['work','💼','Work4Future','Emplois, stages et opportunités.'],['business','▦','Business','Outils pour entrepreneurs.'],
  ['impact','↗','Impact','Personnes. Progrès. Changement.']
];
const demoProducts=[
  {id:'demo-1',name:'Abreuvoir compact pour volailles',category:'Élevage',price:12,currency:'USD',stock_qty:24,seller:'Poules Élevage',image:'assets/products/abreuvoir-compact.jpg',description:'Abreuvoir pratique et robuste, adapté aux petits et moyens élevages.'},
  {id:'demo-2',name:'Mangeoire grande capacité',category:'Élevage',price:28,currency:'USD',stock_qty:18,seller:'Poules Élevage',image:'assets/products/mangeoire-grande.jpg',description:'Mangeoire stable à grande capacité pour réduire les pertes d’aliments.'},
  {id:'demo-3',name:'Mangeoire moyenne croissance',category:'Élevage',price:22,currency:'USD',stock_qty:31,seller:'Poules Élevage',image:'assets/products/mangeoire-moyenne.jpg',description:'Équipement de nourrissage fiable pour accompagner la croissance des poules.'},
  {id:'demo-4',name:'Abreuvoir rouge renforcé',category:'Élevage',price:19,currency:'USD',stock_qty:20,seller:'Poules Élevage',image:'assets/products/abreuvoir-rouge.jpg',description:'Abreuvoir renforcé avec grande base, facile à nettoyer et durable.'}
];
const jobs=[
  ['Assistant marketing','Entreprise partenaire','Bukavu • Temps plein','Nouveau'],
  ['Graphiste','Agence créative','Remote • Freelance','Créatif'],
  ['Agent de terrain','ONG partenaire','Bukavu • CDD','Terrain'],
  ['Développeur Web junior','Work4Future Partner','Remote • Stage','Stage'],
  ['Assistant Data','Impact Lab','Bukavu • CDD','Data']
];
const services=[
  ['💻','Développement & numérique','Sites web, applications, automatisation et accompagnement digital.'],
  ['🎨','Design & communication','Identité visuelle, affiches, réseaux sociaux, photo et vidéo.'],
  ['🧰','Réparation & maintenance','Téléphones, ordinateurs, équipements et installations.'],
  ['🚚','Transport & livraison','Livraison locale, courses et logistique de proximité.'],
  ['🐔','Élevage & agriculture','Équipements, conseils, intrants et services agricoles.'],
  ['📚','Formation & tutorat','Cours, mentorat et formations professionnelles.']
];
const courses=[
  ['IA pratique pour débutants','4 semaines','Work4Future Tech'],['Lancer une petite entreprise','3 semaines','M’MEDPREN Business'],
  ['Marketing digital et vente','2 semaines','Work4Future'],['Développement Web moderne','6 semaines','Work4Future Tech']
];

let current=localStorage.getItem('mmedpren-view')||'home';
let products=[...demoProducts];
let cart=JSON.parse(localStorage.getItem('mmedpren-cart-v3-orange')||'[]');
let apiUser=null;
let marketCategory='Tous';
let deferredPrompt;

function money(p){const n=Number(p.price||0);return `${n.toLocaleString('fr-FR',{maximumFractionDigits:2})} ${p.currency||'USD'}`}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2300)}
function modal(html){$('#modalContent').innerHTML=html;$('#genericModal').classList.add('show');$('#genericModal').setAttribute('aria-hidden','false')}
function closeModal(){$('#genericModal').classList.remove('show');$('#genericModal').setAttribute('aria-hidden','true')}
function saveCart(){localStorage.setItem('mmedpren-cart-v3-orange',JSON.stringify(cart));updateCartBadge()}
function updateCartBadge(){const n=cart.reduce((s,x)=>s+x.qty,0);$('#cartBadge').textContent=n;$('#cartBadge').style.display=n?'grid':'none'}
function productImage(p){
  if(p.image)return p.image;
  const n=(p.name||'').toLowerCase();
  if(n.includes('abreuvoir')&&n.includes('rouge'))return 'assets/products/abreuvoir-rouge.jpg';
  if(n.includes('abreuvoir'))return 'assets/products/abreuvoir-compact.jpg';
  if(n.includes('grande')||n.includes('grand'))return 'assets/products/mangeoire-grande.jpg';
  if(n.includes('mangeoire'))return 'assets/products/mangeoire-moyenne.jpg';
  return 'assets/products/poules-elevage-campagne.jpg';
}
function sellerName(p){return p.seller||p.store_name||'Vendeur M’MEDPREN'}

function renderNav(){
  $('#desktopNav').innerHTML=navItems.map(([id,ico,label])=>`<button class="nav-btn ${current===id?'active':''}" data-view="${id}"><span class="nav-icon">${ico}</span>${label}</button>`).join('');
  $('#bottomNav').innerHTML=bottomItems.map(id=>{const x=navItems.find(n=>n[0]===id);return `<button class="${current===id?'active':''}" data-view="${id}"><span>${x[1]}</span>${x[2]}</button>`}).join('');
  $$('[data-view]').forEach(b=>b.onclick=()=>go(b.dataset.view));
}
function go(id){current=id;localStorage.setItem('mmedpren-view',id);closeSidebar();renderNav();render();window.scrollTo({top:0,behavior:'smooth'})}
function closeSidebar(){$('#sidebar').classList.remove('open');$('#scrim').classList.remove('show')}
function pageMeta(title,kicker='M’MEDPREN'){ $('#pageTitle').textContent=title; $('#pageKicker').textContent=kicker; }

function moduleCards(){return `<div class="module-grid">${modules.map(([id,ico,t,s])=>`<button class="module-card" data-goto="${id}"><span class="module-icon">${ico}</span><b>${t}</b><small>${s}</small></button>`).join('')}</div>`}
function productCards(list=products){
  if(!list.length)return `<div class="panel"><b>Aucun produit trouvé.</b><p class="muted">Essayez une autre recherche ou catégorie.</p></div>`;
  return `<div class="product-grid">${list.map(p=>`<article class="product-card">
    <div class="product-image"><img src="${productImage(p)}" alt="${escapeHtml(p.name)}"><span class="product-badge">${escapeHtml(p.category||'Produit')}</span><button class="favorite">♡</button></div>
    <div class="product-body"><div class="product-meta"><small>${escapeHtml(p.category||'Marché')}</small><span class="rating"><strong>★</strong> 4,8</span></div><h4>${escapeHtml(p.name)}</h4>
    <div class="seller-name"><span>●</span> ${escapeHtml(sellerName(p))} • vendeur vérifié</div>
    <div class="product-foot"><span class="price">${money(p)}</span><button class="add-cart" data-buy="${p.id}">+ Panier</button></div></div>
  </article>`).join('')}</div>`
}
function escapeHtml(s=''){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}

function home(){pageMeta('Accueil');return `<section class="page">
  <div class="hero"><div class="hero-copy"><span class="eyebrow">Work4Future • Mundu ku Gundi</span><h2>Des idées aujourd’hui.<br><em>Un avenir plus lumineux.</em></h2><p>Une plateforme unifiée pour acheter, vendre, trouver du travail, offrir ses compétences, développer son activité et créer de l’impact — tout en un seul endroit.</p><div class="hero-actions"><button class="btn primary" data-goto="market">Explorer le Marché →</button><button class="btn secondary" data-goto="work">Voir les opportunités</button></div></div>
  <div class="hero-visual"><img src="assets/products/work4future-poules-hero.jpg" alt="Entrepreneuriat Work4Future"><div class="hero-note"><b>Mundu ku Gundi</b><small>Des solutions locales pour des communautés plus fortes.</small></div></div></div>
  <div class="section"><div class="section-head"><div><span class="eyebrow">Tout M’MEDPREN</span><h3>Que voulez-vous faire aujourd’hui ?</h3></div></div>${moduleCards()}</div>
  <div class="section"><div class="section-head"><div><span class="eyebrow">Marché</span><h3>Produits réels de notre écosystème</h3></div><button class="link-btn" data-goto="market">Voir tout →</button></div>${productCards(products.slice(0,4))}</div>
  <div class="section banner-grid"><div class="promo"><img src="assets/products/poules-elevage-entrepreneur.jpg" alt="Poules Élevage"><div class="promo-content"><span class="eyebrow" style="color:#ffc28f">Mundu ku Gundi W4F</span><h3>Poules Élevage</h3><p>Élever pour préserver, commercer pour prospérer.</p><button class="btn primary" data-goto="market">Découvrir les équipements</button></div></div><div class="info-card"><span class="eyebrow">Work4Future</span><h3>Apprendre. Travailler. Grandir.</h3><p>Un profil unique pour les emplois, stages, missions freelance, compétences et formations.</p><button class="btn soft" data-goto="work">Explorer Work4Future →</button></div></div>
</section>`}

function market(){pageMeta('Marché','M’MEDPREN MARKET');const cats=['Tous','Élevage','Santé','Tech','Mode','Agriculture','Maison'];const filtered=products.filter(p=>marketCategory==='Tous'||p.category===marketCategory);return `<section class="page">
  <div class="section-head"><div><span class="eyebrow">Acheter • Vendre • Soutenir le local</span><h2>Marché M’MEDPREN</h2></div><button class="btn primary" id="sellBtn">+ Ouvrir une boutique</button></div>
  <div class="market-toolbar"><div class="searchbar"><span>⌕</span><input id="marketSearch" placeholder="Rechercher produits, boutique, catégorie…"></div><button class="btn secondary" id="ordersBtn">Mes commandes</button></div>
  <div class="chips">${cats.map(c=>`<button class="chip ${c===marketCategory?'active':''}" data-category="${c}">${c}</button>`).join('')}</div>
  <div class="section" id="marketGrid">${productCards(filtered)}</div>
  <div class="section banner-grid"><div class="promo"><img src="assets/products/poules-elevage-campagne.jpg" alt="Équipements Poules Élevage"><div class="promo-content"><span class="eyebrow" style="color:#ffc28f">Vendeur local</span><h3>Équipements pour un élevage plus performant.</h3><p>Qualité • Confiance • Performance</p></div></div><div class="info-card"><span class="eyebrow">Livraison</span><h3>Commande → paiement → suivi.</h3><p>Le backend V3 gère déjà les commandes, le paiement sandbox/Mobile Money et le statut de livraison.</p><button class="btn soft" id="cartOpenInline">Voir mon panier →</button></div></div>
</section>`}

function servicesPage(){pageMeta('Services');return `<section class="page"><div class="section-head"><div><span class="eyebrow">Trouver et offrir des compétences</span><h2>Services M’MEDPREN</h2></div><button class="btn primary" id="needBtn">Publier un besoin</button></div><div class="service-grid">${services.map(s=>`<article class="feature-card"><div class="icon">${s[0]}</div><h3>${s[1]}</h3><p>${s[2]}</p><button class="link-btn">Voir les prestataires →</button></article>`).join('')}</div></section>`}

function work(){pageMeta('Work4Future');return `<section class="page">
  <div class="impact-hero"><div><span class="eyebrow">Emplois • Stages • Missions • Formations</span><h2>Trouver du travail.<br>Développer ses compétences.</h2><p>Work4Future relie les personnes à des opportunités concrètes, à des compétences utiles et à des partenaires.</p><div class="hero-actions"><button class="btn primary" id="proProfileBtn">Créer mon profil professionnel</button><button class="btn secondary" id="coursesBtn">Voir les formations</button></div></div><img src="assets/products/work4future-poules-hero.jpg" alt="Work4Future"></div>
  <div class="section"><div class="section-head"><div><span class="eyebrow">Opportunités récentes</span><h3>Emplois Work4Future</h3></div></div><div class="list">${jobs.map(j=>`<div class="list-row"><div class="list-ico">💼</div><div><b>${j[0]}</b><small>${j[1]} • ${j[2]}</small></div><span class="status">${j[3]}</span></div>`).join('')}</div></div>
  <div class="section"><div class="section-head"><div><span class="eyebrow">Work4Future Learn</span><h3>Formations pratiques</h3></div></div><div class="course-grid">${courses.map(c=>`<article class="feature-card"><div class="icon">🎓</div><h3>${c[0]}</h3><p>${c[1]} • ${c[2]}</p><button class="btn soft">Voir le programme</button></article>`).join('')}</div></div>
</section>`}

function business(){pageMeta('Business','M’MEDPREN BUSINESS');return `<section class="page">
  <div class="section-head"><div><span class="eyebrow">Outils pour entrepreneurs</span><h2>Analytique Business</h2></div><div><button class="btn secondary" id="sellerDashBtn">Ma boutique</button> <button class="btn primary" id="newSaleBtn">+ Nouvelle vente</button></div></div>
  <div class="stats"><div class="stat"><span>Ventes totales</span><b>1 892 $</b><em>↑ +12%</em></div><div class="stat"><span>Commandes</span><b>256</b><em>↑ +18%</em></div><div class="stat"><span>Clients</span><b>198</b><em>↑ +15%</em></div><div class="stat"><span>Conversion</span><b>3,6%</b><em>↑ +0,8%</em></div></div>
  <div class="section dashboard-grid"><div class="panel"><h3>Évolution des ventes</h3><div class="bars">${[36,63,48,80,57,89,72,98].map(h=>`<div class="bar" style="height:${h}%"></div>`).join('')}</div></div><div class="panel"><h3>Actions rapides</h3><div class="list"><button class="module-card" id="addProductBtn"><span class="module-icon">▣</span><b>Ajouter un produit</b><small>Catalogue et stock</small></button><button class="module-card"><span class="module-icon">⌑</span><b>Créer une facture</b><small>Vente et client</small></button><button class="module-card"><span class="module-icon">👥</span><b>Clients</b><small>Relation et fidélité</small></button></div></div></div>
  <div class="section panel"><h3>Produits les plus vendus</h3><table class="table"><thead><tr><th>Produit</th><th>Catégorie</th><th>Ventes</th><th>Stock</th></tr></thead><tbody>${products.slice(0,4).map((p,i)=>`<tr><td>${escapeHtml(p.name)}</td><td>${escapeHtml(p.category||'Marché')}</td><td>${72-i*11}</td><td>${p.stock_qty??'-'}</td></tr>`).join('')}</tbody></table></div>
</section>`}

function impact(){pageMeta('Impact','MUNDU KU GUNDI');return `<section class="page">
  <div class="impact-hero"><div><span class="eyebrow">Personnes • Progrès • Changement</span><h2>Créer de la valeur qui reste dans la communauté.</h2><p>Mundu ku Gundi met en avant les entrepreneurs locaux, les projets communautaires, la formation et les initiatives qui renforcent l’économie locale.</p><button class="btn primary" id="impactProjectBtn">Soumettre une initiative</button></div><img src="assets/products/poules-elevage-entrepreneur.jpg" alt="Mundu ku Gundi"></div>
  <div class="section module-grid"><div class="module-card"><span class="module-icon">💡</span><b>Innovation</b><small>De nouvelles idées, des solutions concrètes.</small></div><div class="module-card"><span class="module-icon">👥</span><b>Opportunité</b><small>Personnes, compétences et croissance.</small></div><div class="module-card"><span class="module-icon">↗</span><b>Impact</b><small>Des communautés plus fortes.</small></div><div class="module-card"><span class="module-icon">🐔</span><b>Poules Élevage</b><small>Élevage sain et avenir durable.</small></div><div class="module-card"><span class="module-icon">🤝</span><b>Partenariats</b><small>ONG, entreprises et institutions.</small></div></div>
</section>`}

function profile(){pageMeta('Mon compte');const u=apiUser;return `<section class="page">
  <div class="profile-hero"><div class="avatar-lg">${u?.full_name?.split(' ').map(x=>x[0]).slice(0,2).join('')||'AF'}</div><div><h2>${escapeHtml(u?.full_name||'Votre profil M’MEDPREN')}</h2><p>${escapeHtml(u?.phone||'Connectez-vous pour synchroniser vos données')}</p><div class="pills">${(u?.roles||['client']).map(r=>`<span class="pill">${r}</span>`).join('')}</div></div><button class="btn primary" id="profileAction">${u?'Modifier le profil':'Se connecter'}</button></div>
  <div class="section banner-grid"><div class="info-card"><span class="eyebrow">Mes activités</span><h3>Un seul compte, plusieurs usages.</h3><div class="list"><div class="list-row"><div class="list-ico">🛒</div><div><b>Mes commandes</b><small>Historique, paiements et suivi</small></div><button class="link-btn" id="profileOrders">Voir</button></div><div class="list-row"><div class="list-ico">💼</div><div><b>Work4Future</b><small>Candidatures et compétences</small></div><span class="status">Bientôt</span></div><div class="list-row"><div class="list-ico">▦</div><div><b>Ma boutique</b><small>Produits, commandes et ventes</small></div><button class="link-btn" id="profileSeller">Ouvrir</button></div></div></div><div class="info-card"><span class="eyebrow">Identité M’MEDPREN</span><h3>Personnes. Compétences. Opportunités. Impact.</h3><p>Votre profil accompagne votre parcours entre marché, services, travail, business et impact.</p>${u?`<button class="btn secondary" id="logoutBtn">Se déconnecter</button>`:''}</div></div>
</section>`}

function render(){const pages={home,market,services:servicesPage,work,business,impact,profile};$('#view').innerHTML=(pages[current]||home)();bindDynamic()}

function bindDynamic(){
  $$('[data-goto]').forEach(b=>b.onclick=()=>go(b.dataset.goto));
  $$('[data-buy]').forEach(b=>b.onclick=()=>addToCart(b.dataset.buy));
  $$('.product-card .product-image img').forEach(img=>img.onclick=()=>{const card=img.closest('.product-card');const btn=card.querySelector('[data-buy]');showProduct(btn.dataset.buy)});
  $$('[data-category]').forEach(b=>b.onclick=()=>{marketCategory=b.dataset.category;render()});
  if($('#marketSearch')) $('#marketSearch').oninput=e=>filterMarket(e.target.value);
  if($('#sellBtn')) $('#sellBtn').onclick=openSellerApplication;
  if($('#ordersBtn')) $('#ordersBtn').onclick=openOrders;
  if($('#cartOpenInline')) $('#cartOpenInline').onclick=openCart;
  if($('#needBtn')) $('#needBtn').onclick=()=>modal(`<span class="eyebrow">Services</span><h2>Publier un besoin</h2><label>Service recherché<textarea placeholder="Décrivez précisément votre besoin"></textarea></label><label>Budget indicatif<input placeholder="Ex. 50 USD"></label><label>Ville<input value="Bukavu"></label><button class="btn primary full" onclick="document.getElementById('genericModal').classList.remove('show')">Publier le besoin</button>`);
  if($('#proProfileBtn')) $('#proProfileBtn').onclick=()=>apiUser?toast('Profil professionnel : module Work4Future prêt pour la prochaine API'):openLogin();
  if($('#coursesBtn')) $('#coursesBtn').onclick=()=>toast('Catalogue de formations Work4Future affiché plus bas.');
  if($('#sellerDashBtn')) $('#sellerDashBtn').onclick=openSellerDashboard;
  if($('#addProductBtn')) $('#addProductBtn').onclick=openAddProduct;
  if($('#newSaleBtn')) $('#newSaleBtn').onclick=()=>toast('Point de vente : module UI prêt à connecter.');
  if($('#impactProjectBtn')) $('#impactProjectBtn').onclick=()=>modal(`<span class="eyebrow">Mundu ku Gundi</span><h2>Soumettre une initiative</h2><label>Nom du projet<input placeholder="Nom de l’initiative"></label><label>Objectif<textarea placeholder="Quel changement souhaitez-vous créer ?"></textarea></label><label>Ville<input value="Bukavu"></label><button class="btn primary full">Envoyer</button>`);
  if($('#profileAction')) $('#profileAction').onclick=()=>apiUser?openEditProfile():openLogin();
  if($('#profileOrders')) $('#profileOrders').onclick=openOrders;
  if($('#profileSeller')) $('#profileSeller').onclick=openSellerDashboard;
  if($('#logoutBtn')) $('#logoutBtn').onclick=()=>{MPApi.logout();apiUser=null;toast('Vous êtes déconnecté.');render()};
}

function filterMarket(q){const v=q.toLowerCase().trim();const list=products.filter(p=>(marketCategory==='Tous'||p.category===marketCategory)&&(!v||`${p.name} ${p.category} ${sellerName(p)}`.toLowerCase().includes(v)));$('#marketGrid').innerHTML=productCards(list);$$('[data-buy]').forEach(b=>b.onclick=()=>addToCart(b.dataset.buy))}
function findProduct(id){return products.find(p=>String(p.id)===String(id))}
function addToCart(id){const p=findProduct(id);if(!p)return;const x=cart.find(i=>String(i.id)===String(id));if(x)x.qty++;else cart.push({...p,qty:1});saveCart();toast(`${p.name} ajouté au panier ✓`)}
function showProduct(id){const p=findProduct(id);if(!p)return;modal(`<div class="product-image" style="height:280px;border-radius:18px"><img src="${productImage(p)}" alt="${escapeHtml(p.name)}"></div><span class="eyebrow" style="display:block;margin-top:16px">${escapeHtml(p.category)}</span><h2>${escapeHtml(p.name)}</h2><div class="rating"><strong>★</strong> 4,8 • 32 avis</div><p class="muted">${escapeHtml(p.description||'Produit proposé par un vendeur vérifié sur M’MEDPREN.')}</p><div class="list-row"><div class="list-ico">✓</div><div><b>${escapeHtml(sellerName(p))}</b><small>Vendeur vérifié • Bukavu</small></div><span class="status">Voir la boutique</span></div><div class="section-head" style="margin-top:16px"><h3>${money(p)}</h3><span class="muted">Stock : ${p.stock_qty??'—'}</span></div><button class="btn primary full" id="detailAdd">Ajouter au panier</button><button class="btn outline full" id="detailBuy" style="margin-top:8px">Acheter maintenant</button>`);$('#detailAdd').onclick=()=>{addToCart(id);closeModal()};$('#detailBuy').onclick=()=>{addToCart(id);openCart()}}

function openCart(){
  if(!cart.length)return modal(`<div class="login-brand"><img src="assets/brand/mark.svg"><h2>Votre panier est vide</h2><p>Ajoutez des produits depuis le Marché M’MEDPREN.</p></div><button class="btn primary full" onclick="document.getElementById('genericModal').classList.remove('show')">Continuer mes achats</button>`);
  const total=cart.reduce((s,x)=>s+Number(x.price)*x.qty,0);modal(`<span class="eyebrow">Panier</span><h2>${cart.reduce((s,x)=>s+x.qty,0)} article(s)</h2><div class="list">${cart.map(i=>`<div class="list-row"><div class="list-ico" style="padding:0;overflow:hidden"><img src="${productImage(i)}" style="width:100%;height:100%;object-fit:cover"></div><div><b>${escapeHtml(i.name)}</b><small>${i.qty} × ${money(i)}</small></div><button class="link-btn" data-remove="${i.id}">Retirer</button></div>`).join('')}</div><div class="checkout-summary" style="margin-top:14px"><div class="section-head" style="margin:0"><b>Total estimé</b><h3>${total.toLocaleString('fr-FR')} USD</h3></div><small class="muted">Le serveur recalculera le prix final à partir de PostgreSQL.</small></div><button class="btn primary full" id="checkoutBtn" style="margin-top:12px">Passer la commande →</button>`);$$('[data-remove]').forEach(b=>b.onclick=()=>{cart=cart.filter(x=>String(x.id)!==String(b.dataset.remove));saveCart();openCart()});$('#checkoutBtn').onclick=openCheckout;
}
function openCheckout(){
  if(!MPApi.token()){closeModal();return openLogin()}
  const invalid=cart.some(x=>String(x.id).startsWith('demo-'));if(invalid)return modal(`<span class="eyebrow">Mode démonstration</span><h2>Produits visuels non synchronisés</h2><p>Le backend doit être lancé puis les données de démonstration doivent être chargées avec <b>python -m app.seed</b>. Le Marché remplacera automatiquement les produits visuels par les produits PostgreSQL correspondants.</p><button class="btn primary full" onclick="document.getElementById('genericModal').classList.remove('show')">Compris</button>`);
  modal(`<span class="eyebrow">Commande & paiement</span><h2>Finaliser la commande</h2><label>Nom complet<input id="coName" value="${escapeHtml(apiUser?.full_name||'')}"></label><label>Téléphone<input id="coPhone" value="${escapeHtml(apiUser?.phone||'+243')}"></label><label>Adresse de livraison<textarea id="coAddress" placeholder="Commune, quartier, avenue, repère"></textarea></label><label>Frais de livraison<input id="coFee" type="number" value="0" min="0"></label><label>Mode de paiement<select id="coProvider"><option value="sandbox">Sandbox — test</option><option value="mpesa">M-Pesa</option><option value="airtel">Airtel Money</option><option value="orange">Orange Money</option></select></label><button class="btn primary full" id="placeOrderBtn">Créer la commande et payer</button><p id="coMsg" class="muted"></p>`);
  $('#placeOrderBtn').onclick=async()=>{const msg=$('#coMsg');msg.textContent='Traitement…';try{const order=await MPApi.createOrder({items:cart.map(i=>({product_id:String(i.id),quantity:i.qty})),delivery_name:$('#coName').value,delivery_phone:$('#coPhone').value,delivery_address:$('#coAddress').value,delivery_fee:Number($('#coFee').value||0)});const pay=await MPApi.pay({order_id:order.id,provider:$('#coProvider').value,phone:$('#coPhone').value});if(pay.provider==='sandbox'){await MPApi.sandboxSucceed(pay.id);cart=[];saveCart();modal(`<div class="login-brand"><img src="assets/brand/mark.svg"><h2>Commande confirmée ✓</h2><p>Le paiement sandbox a réussi. La livraison est créée automatiquement.</p></div><button class="btn primary full" id="afterOrder">Voir mes commandes</button>`);$('#afterOrder').onclick=openOrders}else msg.textContent=`Paiement ${pay.provider} initié — statut : ${pay.status}. Confirmez sur votre téléphone.`}catch(e){msg.textContent=e.message}}
}

function openLogin(){
  modal(`<div class="login-brand"><img src="assets/brand/mark.svg"><h2>Bon retour</h2><p>Entrez votre numéro de téléphone pour recevoir un code de vérification.</p></div><label>Numéro de téléphone<input id="loginPhone" value="+243" placeholder="+243 ..."></label><button class="btn primary full" id="requestOtpBtn">Envoyer le code →</button><div id="authStep"></div><p id="authMsg" class="muted"></p>`);
  $('#requestOtpBtn').onclick=async()=>{const msg=$('#authMsg');msg.textContent='Envoi…';try{const d=await MPApi.requestOtp($('#loginPhone').value);$('#requestOtpBtn').style.display='none';$('#authStep').innerHTML=`${d.debug_code?`<div class="checkout-summary" style="margin-top:12px">Code développement : <b>${d.debug_code}</b></div>`:''}<label>Code OTP<input id="loginCode" inputmode="numeric" placeholder="000000"></label><button class="btn primary full" id="verifyOtpBtn">Se connecter</button>`;msg.textContent=`Code valable ${Math.round(d.expires_in/60)} minute(s).`;$('#verifyOtpBtn').onclick=async()=>{try{await MPApi.verifyOtp(d.challenge_id,$('#loginCode').value);apiUser=await MPApi.me();closeModal();toast('Connexion réussie ✓');go('profile')}catch(e){msg.textContent=e.message}}}catch(e){msg.textContent=e.message}}
}
function openEditProfile(){modal(`<span class="eyebrow">Mon profil</span><h2>Modifier mes informations</h2><label>Nom complet<input id="editName" value="${escapeHtml(apiUser?.full_name||'')}"></label><label>E-mail<input id="editEmail" value="${escapeHtml(apiUser?.email||'')}"></label><button class="btn primary full" id="saveProfile">Enregistrer</button><p id="editMsg"></p>`);$('#saveProfile').onclick=async()=>{try{await MPApi.updateMe({full_name:$('#editName').value,email:$('#editEmail').value||null});apiUser=await MPApi.me();closeModal();toast('Profil mis à jour ✓');render()}catch(e){$('#editMsg').textContent=e.message}}}
async function openOrders(){if(!MPApi.token())return openLogin();modal(`<span class="eyebrow">Mes commandes</span><h2>Historique</h2><div id="ordersList"><p class="muted">Chargement…</p></div>`);try{const rows=await MPApi.ordersMine();$('#ordersList').innerHTML=rows.length?`<div class="list">${rows.map(o=>`<div class="list-row"><div class="list-ico">📦</div><div><b>Commande ${o.id.slice(0,8)}</b><small>${o.items.length} article(s) • ${Number(o.total).toLocaleString('fr-FR')} ${o.currency}</small></div><span class="status">${o.status}</span></div>`).join('')}</div>`:'<p class="muted">Aucune commande pour le moment.</p>'}catch(e){$('#ordersList').innerHTML=`<p>${escapeHtml(e.message)}</p>`}}

function openSellerApplication(){if(!MPApi.token())return openLogin();modal(`<span class="eyebrow">Espace vendeur</span><h2>Ouvrir une boutique</h2><p class="muted">Après soumission, un administrateur valide votre profil avant la publication de produits.</p><label>Nom légal<input id="legalName" placeholder="Nom / entreprise"></label><label>Nom de la boutique<input id="businessName" placeholder="Ex. Poules Élevage"></label><label>Ville<input id="sellerCity" value="Bukavu"></label><button class="btn primary full" id="sellerApplyBtn">Soumettre la demande</button><p id="sellerMsg"></p>`);$('#sellerApplyBtn').onclick=async()=>{try{const d=await MPApi.sellerApply({legal_name:$('#legalName').value,business_name:$('#businessName').value,city:$('#sellerCity').value});$('#sellerMsg').textContent=`Demande envoyée — statut : ${d.status}.`;}catch(e){$('#sellerMsg').textContent=e.message}}}
async function openSellerDashboard(){if(!MPApi.token())return openLogin();modal(`<span class="eyebrow">Ma boutique</span><h2>Tableau de bord vendeur</h2><div id="sellerState"><p class="muted">Chargement…</p></div>`);try{const s=await MPApi.sellerMe();$('#sellerState').innerHTML=`<div class="profile-hero"><div class="avatar-lg">${s.business_name.slice(0,2).toUpperCase()}</div><div><h2>${escapeHtml(s.business_name)}</h2><p>${escapeHtml(s.city)} • statut ${s.status}</p><div class="pills"><span class="pill">Vendeur</span><span class="pill">${s.status}</span></div></div></div><div class="stats" style="margin-top:14px"><div class="stat"><span>Produits</span><b>${products.length}</b></div><div class="stat"><span>Commandes</span><b>—</b></div><div class="stat"><span>Ventes</span><b>—</b></div><div class="stat"><span>Boutique</span><b>✓</b></div></div><button class="btn primary full" id="sellerAddProduct" style="margin-top:14px">+ Ajouter un produit</button>`;$('#sellerAddProduct').onclick=openAddProduct}catch(e){$('#sellerState').innerHTML=`<p>${escapeHtml(e.message)}</p><button class="btn primary" id="applyFromDash">Devenir vendeur</button>`;$('#applyFromDash').onclick=openSellerApplication}}
function openAddProduct(){if(!MPApi.token())return openLogin();modal(`<span class="eyebrow">Catalogue vendeur</span><h2>Ajouter un produit</h2><label>Nom<input id="pName" placeholder="Nom du produit"></label><label>Description<textarea id="pDesc"></textarea></label><label>Catégorie<select id="pCat"><option>Élevage</option><option>Santé</option><option>Tech</option><option>Mode</option><option>Agriculture</option><option>Maison</option></select></label><label>Prix<input id="pPrice" type="number" min="0" step="0.01"></label><label>Devise<select id="pCurrency"><option>USD</option><option>CDF</option></select></label><label>Stock<input id="pStock" type="number" min="0" value="1"></label><button class="btn primary full" id="pCreate">Publier</button><p id="pMsg"></p>`);$('#pCreate').onclick=async()=>{try{await MPApi.createProduct({name:$('#pName').value,description:$('#pDesc').value,category:$('#pCat').value,price:Number($('#pPrice').value),currency:$('#pCurrency').value,stock_qty:Number($('#pStock').value)});$('#pMsg').textContent='Produit publié ✓';await hydrateProductsFromApi()}catch(e){$('#pMsg').textContent=e.message}}}

async function hydrateProductsFromApi(){try{const remote=await MPApi.products();if(Array.isArray(remote)&&remote.length){products=remote.map(p=>({...p,price:Number(p.price),seller:p.store_name||'Vendeur M’MEDPREN'}));if(['home','market','business'].includes(current))render()}}catch(e){console.info('API indisponible : catalogue visuel local utilisé.',e.message)}}
async function hydrateUser(){if(!MPApi.token())return;try{apiUser=await MPApi.me()}catch(e){MPApi.logout();apiUser=null}}

$('#modalX').onclick=closeModal;$('#genericModal').onclick=e=>{if(e.target.id==='genericModal')closeModal()};
$('#menuBtn').onclick=()=>{$('#sidebar').classList.add('open');$('#scrim').classList.add('show')};$('#scrim').onclick=closeSidebar;
$('#cartBtn').onclick=openCart;$('#profileBtn').onclick=()=>go('profile');$('#notifBtn').onclick=()=>toast('2 notifications de démonstration.');
$('#globalSearch').onkeydown=e=>{if(e.key==='Enter'){go('market');setTimeout(()=>{if($('#marketSearch')){$('#marketSearch').value=e.target.value;filterMarket(e.target.value)}},50)}};
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e});$('#installBtn').onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null}else toast('Menu du navigateur → Ajouter à l’écran d’accueil')};
$('#assistantFab').onclick=()=>$('#assistantPanel').classList.toggle('show');$('#assistantClose').onclick=()=>$('#assistantPanel').classList.remove('show');$$('.assistant-suggestions button').forEach(b=>b.onclick=()=>{$('#assistantInput').value=b.textContent;$('#assistantInput').focus()});$('#assistantForm').onsubmit=e=>{e.preventDefault();const v=$('#assistantInput').value.trim();if(!v)return;$('#assistantBody').insertAdjacentHTML('beforeend',`<div class="bubble user">${escapeHtml(v)}</div><div class="bubble bot">Je peux maintenant vous orienter vers le Marché, Work4Future, Services ou Business. La recherche IA complète sera branchée sur les API dans une prochaine itération.</div>`);$('#assistantInput').value='';$('#assistantBody').scrollTop=$('#assistantBody').scrollHeight};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./service-worker.js').catch(()=>{}));

(async()=>{renderNav();updateCartBadge();await hydrateUser();render();hydrateProductsFromApi()})();
