const C='mmedpren-platform-v3-orange-1';
const A=[
  './','./index.html','./styles.css','./app.js','./api.js','./manifest.webmanifest',
  './assets/brand/mark.svg','./assets/brand/logo-horizontal.svg',
  './assets/products/abreuvoir-compact.jpg','./assets/products/mangeoire-grande.jpg',
  './assets/products/mangeoire-moyenne.jpg','./assets/products/abreuvoir-rouge.jpg',
  './assets/products/work4future-poules-hero.jpg'
];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(A))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).catch(()=>e.request.mode==='navigate'?caches.match('./index.html'):undefined))));
