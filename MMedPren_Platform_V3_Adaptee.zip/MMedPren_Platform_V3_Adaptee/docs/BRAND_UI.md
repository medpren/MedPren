# Charte UI M'MEDPREN

## Positionnement
**M'MEDPREN — Work4Future • Mundu ku Gundi**

Une plateforme unifiée pour acheter, vendre, trouver du travail, offrir ses compétences, développer son activité et créer de l’impact.

## Couleurs
| Token | Valeur | Usage |
|---|---|---|
| `--orange` | `#F7934A` | marque, boutons, icônes |
| `--orange-2` | `#FF6B1A` | CTA et états actifs |
| `--peach` | `#FFD8B8` | accent chaleureux |
| `--peach-2` | `#FFF1E5` | fonds actifs et cartes |
| `--ink` | `#1F1F1F` | titres, contraste |
| `--bg` | `#F7F7F5` | fond interface |

## Architecture de navigation
### Desktop
1. Accueil
2. Marché
3. Services
4. Work4Future
5. Business
6. Impact
7. Mon compte

### Mobile
1. Accueil
2. Marché
3. Emplois
4. Business
5. Profil

## Langage visuel
- surfaces blanches sur fond gris très clair
- rayons de 12 à 30 px
- orange réservé aux actions, états actifs et éléments de marque
- pêche douce pour les fonds secondaires
- photos réelles pour les produits et projets locaux
- faible densité visuelle et espaces généreux
- titres noirs forts, textes secondaires gris

## Modules
### Marché
Catalogue multi-vendeur, recherche, catégories, produit, panier, checkout, Mobile Money et suivi de commande.

### Services
Mise en relation entre clients et prestataires.

### Work4Future
Emplois, stages, missions, formations et opportunités.

### Business
Outils de gestion et analytics pour vendeurs/PME.

### Mundu ku Gundi / Impact
Initiatives communautaires, entrepreneurs locaux et projets à impact.

## Assets réels intégrés
Les visuels `Poules Élevage` fournis par l’organisation ont été utilisés pour produire les cartes de produits, la bannière d’accueil et la section Impact.
