# Architecture cible — M'MEDPREN SuperApp

## Produits
1. M'MEDPREN Market
2. M'MEDPREN Services
3. Work4Future Jobs
4. Work4Future Learn
5. Work4Future Opportunities
6. Mundu ku Gundi Impact
7. M'MEDPREN Business
8. M'MEDPREN Delivery
9. M'MEDPREN Pay (couche d’intégration)
10. M'MEDPREN AI

## Stack recommandée
- Web/PWA : Next.js / React
- Mobile : Flutter
- API : FastAPI
- DB : PostgreSQL
- Cache/queues : Redis
- Object storage : S3-compatible
- Auth : téléphone + OTP, email, OAuth si nécessaire
- Search : PostgreSQL FTS au début, puis Meilisearch/OpenSearch
- Payments : intégrations officielles Mobile Money / gateway autorisée
- Notifications : push + SMS + email + WhatsApp selon fournisseur
- Analytics : PostHog / Metabase / outils internes
- Infra : conteneurs + Cloud Run / VPS / Kubernetes seulement plus tard

## Services backend
- identity-service
- commerce-service
- marketplace-service
- order-service
- payment-service
- delivery-service
- services-marketplace
- work4future-service
- learning-service
- opportunity-service
- impact-service
- business-service
- notification-service
- ai-orchestrator
- admin-service

## Rôles
- customer
- seller
- service_provider
- learner
- candidate
- recruiter
- delivery_agent
- partner
- business_manager
- admin
- super_admin

## Principes
- mobile-first
- faible bande passante
- progressive enhancement
- données minimales
- audit des paiements
- permissions par rôle
- séparation des modules
- offline partiel pour le catalogue et l’apprentissage
