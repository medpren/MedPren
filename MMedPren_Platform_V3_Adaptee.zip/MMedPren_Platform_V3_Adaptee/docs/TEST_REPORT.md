# Rapport de validation — V3 adaptée

## Contrôles réalisés
- Compilation Python backend : **OK**
- Syntaxe JavaScript PWA : **OK**
- Syntaxe JavaScript Admin : **OK**
- Tests unitaires sécurité OTP/JWT : **OK**
- Test d’intégration commerce complet : **OK**

Commande utilisée dans l’environnement de validation :
```bash
DATABASE_URL=sqlite:// PYTHONPATH=. pytest -q
```
Résultat : **3 tests réussis**.

## Flux couvert par le test d’intégration
1. création admin par OTP
2. création vendeur par OTP
3. demande vendeur
4. validation vendeur par admin
5. création produit
6. vérification du nom de boutique dans le catalogue
7. création client par OTP
8. création commande et recalcul du total côté serveur
9. paiement sandbox
10. confirmation paiement
11. création livreur
12. attribution du rôle livreur
13. affectation de la livraison
14. passage de la livraison à `delivered`

## Base de production
Le test automatisé utilise SQLite pour pouvoir être exécuté sans Docker dans l’environnement de génération. Le projet de déploiement reste configuré pour **PostgreSQL 16** via `docker-compose.yml`.

## Limite actuelle
Le code Flutter a été réécrit selon la nouvelle maquette, mais le runtime de génération ne contient pas le SDK Flutter/Dart ; la validation finale Flutter doit donc être exécutée sur une machine équipée de Flutter avec `flutter analyze` puis `flutter run`.
