# Flux principaux

## Connexion
1. `POST /api/v1/auth/otp/request`
2. SMS/console délivre le code
3. `POST /api/v1/auth/otp/verify`
4. API renvoie JWT
5. Web/Flutter envoie `Authorization: Bearer <token>`

## Vendeur
1. Utilisateur authentifié -> `/sellers/apply`
2. Admin -> `/admin/sellers/{id}` status approved
3. Vendeur -> `POST /products`

## Commande
1. Client charge `/products`
2. `POST /orders`
3. Le backend recalcule les prix et réserve le stock
4. `POST /payments`
5. Opérateur -> webhook backend
6. Paiement success -> commande confirmed
7. Admin assigne livraison
8. Livreur met à jour le statut

## Règle de sécurité essentielle
Le montant d’une commande n’est jamais accepté depuis Flutter/Web : le serveur le recalcule depuis PostgreSQL.
