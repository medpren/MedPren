# Paiements Mobile Money

`PaymentProvider` définit une interface commune. Le client mobile n’appelle jamais directement l’opérateur.

Providers :
- `sandbox` : immédiatement testable
- `mpesa` : adaptateur Vodacom RDC à finaliser avec le contrat/credentials Business fournis au marchand
- `airtel` : adaptateur à finaliser avec l’application créée sur le portail Airtel Africa DRC
- `orange` : adaptateur à finaliser avec le produit Orange Money effectivement activé pour le compte marchand

## Pourquoi les connecteurs live ne sont pas codés avec de faux endpoints
Les URLs, signatures, identifiants et corps de requête dépendent du produit et du compte marchand réellement accordé. Inventer une implémentation serait dangereux pour une plateforme de paiement. Le dépôt contient donc la couche sûre, les webhooks et le cycle de transaction; la dernière étape consiste à mapper la documentation reçue avec vos credentials sandbox/production.
