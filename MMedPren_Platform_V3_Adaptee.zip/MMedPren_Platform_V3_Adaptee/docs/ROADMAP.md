# Roadmap 12 mois

## 0–2 mois — MVP commercial
- Comptes et OTP
- Marketplace multi-vendeurs
- Catalogue, stock, panier
- Commandes
- Paiement à la livraison + 1 intégration Mobile Money
- Zones de livraison
- Dashboard vendeur
- Admin

## 2–4 mois — Services + Work4Future
- Profils professionnels
- Jobs/stages/freelance
- Prestataires de services
- Candidatures
- Notifications

## 4–6 mois — Learn + Business
- Formations
- Suivi de progression
- POS simple
- Factures
- Clients
- Inventaire
- Analytics PME

## 6–9 mois — Mundu ku Gundi
- Initiatives
- Partenaires
- Impact
- Entrepreneurs locaux
- Programmes communautaires

## 9–12 mois — SuperApp avancée
- Assistant IA transversal
- Recommandations
- Recherche intelligente
- Livraison distribuée
- Fidélité
- Expansion multi-ville
