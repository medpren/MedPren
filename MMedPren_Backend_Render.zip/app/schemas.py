from pydantic import BaseModel, Field, model_validator
from decimal import Decimal
from typing import Literal
from app.models import OrderStatus, PaymentStatus, DeliveryStatus, SellerStatus

class OTPRequest(BaseModel): phone: str
class LoginIdentifierRequest(BaseModel): identifier: str = Field(min_length=3,max_length=200)
class OTPRequestOut(BaseModel):
    challenge_id: str
    expires_in: int
    debug_code: str|None=None
    channel: str|None=None
    destination_hint: str|None=None
class OTPVerify(BaseModel): challenge_id: str; code: str = Field(min_length=4,max_length=8)
class TokenOut(BaseModel): access_token: str; token_type: str="bearer"; user: dict
class UserUpdate(BaseModel):
    full_name: str|None=None
    email: str|None=None
    whatsapp_phone: str|None=None
    profile_kind: Literal["personal","business"]|None=None
class SellerApply(BaseModel): legal_name: str; business_name: str; city: str
class SellerUpdate(BaseModel): legal_name: str|None=None; business_name: str|None=None; city: str|None=None; store_name: str|None=None; store_description: str|None=None
class SellerOut(BaseModel): id:str; business_name:str; city:str; status:SellerStatus; store_id:str|None=None

class ProductCreate(BaseModel):
    name:str
    description:str|None=None
    category:str
    price:Decimal=Field(gt=0)
    currency:str="USD"
    stock_qty:int=Field(ge=0)
    min_order_qty:int=Field(default=1,ge=1,le=10000)
    max_order_qty:int=Field(default=100,ge=1,le=10000)
    @model_validator(mode="after")
    def validate_qty(self):
        if self.max_order_qty < self.min_order_qty:
            raise ValueError("max_order_qty must be greater than or equal to min_order_qty")
        return self

class ProductUpdate(BaseModel):
    name:str|None=None
    description:str|None=None
    category:str|None=None
    price:Decimal|None=Field(default=None,gt=0)
    currency:str|None=None
    stock_qty:int|None=Field(default=None,ge=0)
    min_order_qty:int|None=Field(default=None,ge=1,le=10000)
    max_order_qty:int|None=Field(default=None,ge=1,le=10000)
    is_active:bool|None=None
    @model_validator(mode="after")
    def validate_qty(self):
        if self.min_order_qty is not None and self.max_order_qty is not None and self.max_order_qty < self.min_order_qty:
            raise ValueError("max_order_qty must be greater than or equal to min_order_qty")
        return self

class ProductOut(BaseModel):
    id:str; store_id:str; store_name:str|None=None; name:str; slug:str; description:str|None; category:str; price:Decimal; currency:str; stock_qty:int
    min_order_qty:int=1; max_order_qty:int=100; image_url:str|None=None; is_active:bool; moderation_status:str="pending"

class OrderItemIn(BaseModel): product_id:str; quantity:int=Field(gt=0,le=10000)
class OrderCreate(BaseModel): items:list[OrderItemIn]; delivery_name:str; delivery_phone:str; delivery_address:str; delivery_fee:Decimal=Field(default=0,ge=0)
class OrderItemOut(BaseModel): product_id:str|None; product_name:str; unit_price:Decimal; quantity:int; line_total:Decimal
class OrderOut(BaseModel): id:str; status:OrderStatus; currency:str; subtotal:Decimal; delivery_fee:Decimal; total:Decimal; delivery_name:str; delivery_phone:str; delivery_address:str; items:list[OrderItemOut]
class PaymentCreate(BaseModel): order_id:str; provider:Literal["sandbox","mpesa","airtel","orange"]; phone:str
class PaymentOut(BaseModel): id:str; order_id:str; provider:str; amount:Decimal; currency:str; status:PaymentStatus; provider_reference:str|None=None
class PaymentWebhook(BaseModel): provider_reference:str; status:Literal["success","failed","pending"]; payload:dict={}
class DeliveryAssign(BaseModel): courier_id:str
class DeliveryStatusUpdate(BaseModel): status:DeliveryStatus
class AdminSellerDecision(BaseModel): status:Literal["approved","suspended"]
class AdminProductDecision(BaseModel): status:Literal["approved","suspended","pending"]
class AdminOrderCancel(BaseModel): reason:str=Field(min_length=3,max_length=1000)

class AdvertisementCreate(BaseModel):
    title: str = Field(min_length=2,max_length=180)
    body: str|None = None
    link_url: str|None = None
    is_active: bool = True
    sort_order: int = 0
class AdvertisementUpdate(BaseModel):
    title: str|None = Field(default=None,min_length=2,max_length=180)
    body: str|None = None
    link_url: str|None = None
    is_active: bool|None = None
    sort_order: int|None = None

class ChatStart(BaseModel):
    seller_id: str
    subject: str|None = Field(default=None,max_length=220)
class ChatMessageCreate(BaseModel):
    body: str = Field(min_length=1,max_length=5000)
class SupportStart(BaseModel):
    subject: str|None = Field(default="Service client M’MEDPREN",max_length=220)
class AssistantMessage(BaseModel):
    message: str = Field(min_length=1,max_length=2000)
    current_view: str|None = Field(default=None,max_length=64)

class PushSubscriptionIn(BaseModel):
    endpoint: str = Field(min_length=10,max_length=4000)
    p256dh: str = Field(min_length=10,max_length=1000)
    auth: str = Field(min_length=5,max_length=500)
    user_agent: str|None = Field(default=None,max_length=1000)
class PushSubscriptionDelete(BaseModel):
    endpoint: str = Field(min_length=10,max_length=4000)


# Work4Future
class WorkProfileUpdate(BaseModel):
    headline: str|None = Field(default=None,max_length=180)
    skills: str|None = Field(default=None,max_length=5000)
    city: str|None = Field(default=None,max_length=120)
    bio: str|None = Field(default=None,max_length=8000)
    experience: str|None = Field(default=None,max_length=12000)
    education: str|None = Field(default=None,max_length=8000)
    availability: str|None = Field(default=None,max_length=100)

class WorkOpportunityCreate(BaseModel):
    kind: Literal["job","internship","mission","scholarship"] = "job"
    title: str = Field(min_length=2,max_length=220)
    organization: str = Field(min_length=2,max_length=220)
    location: str|None = Field(default=None,max_length=160)
    work_mode: str|None = Field(default=None,max_length=64)
    contract_type: str|None = Field(default=None,max_length=80)
    salary_text: str|None = Field(default=None,max_length=120)
    description: str = Field(min_length=5,max_length=30000)
    requirements: str|None = Field(default=None,max_length=20000)
    application_url: str|None = Field(default=None,max_length=2000)
    contact_email: str|None = Field(default=None,max_length=200)
    deadline_at: str|None = None
    is_active: bool = True
    is_featured: bool = False

class WorkOpportunityUpdate(BaseModel):
    kind: Literal["job","internship","mission","scholarship"]|None = None
    title: str|None = Field(default=None,min_length=2,max_length=220)
    organization: str|None = Field(default=None,min_length=2,max_length=220)
    location: str|None = Field(default=None,max_length=160)
    work_mode: str|None = Field(default=None,max_length=64)
    contract_type: str|None = Field(default=None,max_length=80)
    salary_text: str|None = Field(default=None,max_length=120)
    description: str|None = Field(default=None,min_length=5,max_length=30000)
    requirements: str|None = Field(default=None,max_length=20000)
    application_url: str|None = Field(default=None,max_length=2000)
    contact_email: str|None = Field(default=None,max_length=200)
    deadline_at: str|None = None
    is_active: bool|None = None
    is_featured: bool|None = None

class WorkApplicationCreate(BaseModel):
    motivation: str|None = Field(default=None,max_length=10000)

class WorkApplicationDecision(BaseModel):
    status: Literal["submitted","reviewing","shortlisted","rejected","accepted"]
    admin_note: str|None = Field(default=None,max_length=5000)

class WorkTrainingCreate(BaseModel):
    title: str = Field(min_length=2,max_length=220)
    provider: str = Field(min_length=2,max_length=220)
    category: str|None = Field(default=None,max_length=100)
    mode: str|None = Field(default=None,max_length=64)
    location: str|None = Field(default=None,max_length=160)
    level: str|None = Field(default=None,max_length=80)
    duration_text: str|None = Field(default=None,max_length=100)
    fee_text: str|None = Field(default=None,max_length=100)
    description: str = Field(min_length=5,max_length=30000)
    prerequisites: str|None = Field(default=None,max_length=20000)
    external_url: str|None = Field(default=None,max_length=2000)
    start_at: str|None = None
    deadline_at: str|None = None
    capacity: int|None = Field(default=None,ge=1,le=1000000)
    is_active: bool = True
    is_featured: bool = False

class WorkTrainingUpdate(BaseModel):
    title: str|None = Field(default=None,min_length=2,max_length=220)
    provider: str|None = Field(default=None,min_length=2,max_length=220)
    category: str|None = Field(default=None,max_length=100)
    mode: str|None = Field(default=None,max_length=64)
    location: str|None = Field(default=None,max_length=160)
    level: str|None = Field(default=None,max_length=80)
    duration_text: str|None = Field(default=None,max_length=100)
    fee_text: str|None = Field(default=None,max_length=100)
    description: str|None = Field(default=None,min_length=5,max_length=30000)
    prerequisites: str|None = Field(default=None,max_length=20000)
    external_url: str|None = Field(default=None,max_length=2000)
    start_at: str|None = None
    deadline_at: str|None = None
    capacity: int|None = Field(default=None,ge=1,le=1000000)
    is_active: bool|None = None
    is_featured: bool|None = None

class WorkEnrollmentCreate(BaseModel):
    note: str|None = Field(default=None,max_length=5000)

class WorkEnrollmentDecision(BaseModel):
    status: Literal["registered","confirmed","completed","cancelled"]
    admin_note: str|None = Field(default=None,max_length=5000)
