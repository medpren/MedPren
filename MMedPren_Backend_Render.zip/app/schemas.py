from pydantic import BaseModel, Field
from decimal import Decimal
from typing import Literal
from app.models import OrderStatus, PaymentStatus, DeliveryStatus, SellerStatus

class OTPRequest(BaseModel): phone: str
class OTPRequestOut(BaseModel): challenge_id: str; expires_in: int; debug_code: str|None=None
class OTPVerify(BaseModel): challenge_id: str; code: str = Field(min_length=4,max_length=8)
class TokenOut(BaseModel): access_token: str; token_type: str="bearer"; user: dict
class UserUpdate(BaseModel): full_name: str|None=None; email: str|None=None
class SellerApply(BaseModel): legal_name: str; business_name: str; city: str
class SellerUpdate(BaseModel): legal_name: str|None=None; business_name: str|None=None; city: str|None=None; store_name: str|None=None; store_description: str|None=None
class SellerOut(BaseModel): id:str; business_name:str; city:str; status:SellerStatus; store_id:str|None=None
class ProductCreate(BaseModel): name:str; description:str|None=None; category:str; price:Decimal=Field(gt=0); currency:str="USD"; stock_qty:int=Field(ge=0)
class ProductUpdate(BaseModel): name:str|None=None; description:str|None=None; category:str|None=None; price:Decimal|None=Field(default=None,gt=0); currency:str|None=None; stock_qty:int|None=Field(default=None,ge=0); is_active:bool|None=None
class ProductOut(BaseModel): id:str; store_id:str; store_name:str|None=None; name:str; slug:str; description:str|None; category:str; price:Decimal; currency:str; stock_qty:int; image_url:str|None=None; is_active:bool; moderation_status:str="pending"
class OrderItemIn(BaseModel): product_id:str; quantity:int=Field(gt=0,le=100)
class OrderCreate(BaseModel): items:list[OrderItemIn]; delivery_name:str; delivery_phone:str; delivery_address:str; delivery_fee:Decimal=Field(default=0,ge=0)
class OrderItemOut(BaseModel): product_id:str|None; product_name:str; unit_price:Decimal; quantity:int; line_total:Decimal
class OrderOut(BaseModel): id:str; status:OrderStatus; currency:str; subtotal:Decimal; delivery_fee:Decimal; total:Decimal; delivery_name:str; delivery_phone:str; delivery_address:str; items:list[OrderItemOut]
class PaymentCreate(BaseModel): order_id:str; provider:Literal["sandbox","mpesa","airtel","orange"]; phone:str
class PaymentOut(BaseModel): id:str; order_id:str; provider:str; amount:Decimal; currency:str; status:PaymentStatus; provider_reference:str|None=None
class PaymentWebhook(BaseModel): provider_reference:str; status:Literal["success","failed","pending"]; payload:dict={}
class DeliveryAssign(BaseModel): courier_id:str
class DeliveryStatusUpdate(BaseModel): status:DeliveryStatus
class AdminSellerDecision(BaseModel): status:Literal["approved","suspended"]
class AdminProductDecision(BaseModel): status:Literal["approved","suspended","pending"]

class AdvertisementCreate(BaseModel):
    title: str = Field(min_length=2,max_length=180)
    body: str|None = None
    link_url: str|None = None
    is_active: bool = True
    sort_order: int = 0
class AdvertisementUpdate(BaseModel):
    title: str|None = Field(default=None,min_length=2,max_length=180)
    body: str|None = None
    link_url: str|None = None
    is_active: bool|None = None
    sort_order: int|None = None

class ChatStart(BaseModel):
    seller_id: str
    subject: str|None = Field(default=None,max_length=220)
class ChatMessageCreate(BaseModel):
    body: str = Field(min_length=1,max_length=5000)


class SupportStart(BaseModel):
    subject: str|None = Field(default="Service client M’MEDPREN",max_length=220)

class AssistantMessage(BaseModel):
    message: str = Field(min_length=1,max_length=2000)
    current_view: str|None = Field(default=None,max_length=64)
