from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import admin, auth, deliveries, orders, payments, products, sellers, ads, chats, notifications, assistant, work, share

app = FastAPI(title=settings.app_name,version="0.4.0",description="Shared API for M'MEDPREN Web/PWA and Flutter")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for router in [auth.router,sellers.router,products.router,orders.router,payments.router,deliveries.router,admin.router,ads.router,chats.router,notifications.router,assistant.router,work.router,work.admin_router]:
    app.include_router(router,prefix="/api/v1")
app.include_router(share.router)

@app.get("/health")
def health():
    return {"status":"ok","service":"mmedpren-api","version":"0.4.0","image_storage":"configured" if settings.cloudinary_url else "not_configured",
            "assistant_provider":"gemini" if settings.gemini_api_key else "local",
            "push_notifications":"configured" if settings.push_configured else "not_configured",
            "features":["product_moderation","managed_ads","persistent_chat","owner_store","persistent_notifications","web_push","human_support","smart_assistant","admin_order_supervision","profile_images","private_contacts","order_limits","admin_account_directory","safe_destructive_actions","removable_image_selection","flexible_image_uploads","admin_user_deletion","work4future_profiles","work4future_opportunities","work4future_trainings","work4future_applications","social_sharing","rich_share_previews","share_deep_links","work4future_images","owner_author_editing"]}
