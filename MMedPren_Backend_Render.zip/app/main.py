from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import admin, auth, deliveries, orders, payments, products, sellers, ads, chats, notifications, assistant

app = FastAPI(title=settings.app_name,version="0.3.5",description="Shared API for M'MEDPREN Web/PWA and Flutter")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for router in [auth.router,sellers.router,products.router,orders.router,payments.router,deliveries.router,admin.router,ads.router,chats.router,notifications.router,assistant.router]:
    app.include_router(router,prefix="/api/v1")

@app.get("/health")
def health():
    return {"status":"ok","service":"mmedpren-api","version":"0.3.5","image_storage":"configured" if settings.cloudinary_url else "not_configured",
            "features":["product_moderation","managed_ads","persistent_chat","owner_store","persistent_notifications","human_support","smart_assistant"]}
