from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import auth, sellers, products, orders, payments, deliveries, admin

app=FastAPI(title=settings.app_name,version="0.3.1",description="Shared API for M'MEDPREN Web/PWA and Flutter")
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_list,allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
for r in [auth.router,sellers.router,products.router,orders.router,payments.router,deliveries.router,admin.router]: app.include_router(r,prefix="/api/v1")
@app.get("/health")
def health(): return {"status":"ok","service":"mmedpren-api","version":"0.3.1"}
