import base64, hashlib, hmac, json, secrets, time
from app.config import settings

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))

def generate_otp():
    return f"{secrets.randbelow(1000000):06d}"

def otp_hash(code: str):
    return hmac.new(settings.secret_key.encode(), code.encode(), hashlib.sha256).hexdigest()

def verify_otp(code: str, hashed: str):
    return hmac.compare_digest(otp_hash(code), hashed)

def create_access_token(user_id: str, roles: list[str]):
    header={"alg":"HS256","typ":"JWT"}
    payload={"sub":user_id,"roles":roles,"exp":int(time.time())+settings.access_token_expire_minutes*60}
    head=_b64(json.dumps(header,separators=(",",":")).encode())
    body=_b64(json.dumps(payload,separators=(",",":")).encode())
    sig=_b64(hmac.new(settings.secret_key.encode(),f"{head}.{body}".encode(),hashlib.sha256).digest())
    return f"{head}.{body}.{sig}"

def decode_token(token: str):
    try:
        head,body,sig=token.split(".")
        expected=_b64(hmac.new(settings.secret_key.encode(),f"{head}.{body}".encode(),hashlib.sha256).digest())
        if not hmac.compare_digest(sig,expected): raise ValueError("bad signature")
        payload=json.loads(_unb64(body))
        if int(payload.get("exp",0)) < int(time.time()): raise ValueError("expired")
        return payload
    except Exception as exc:
        raise ValueError("Invalid token") from exc

def hash_password(password: str) -> str:
    """Hash a password with stdlib scrypt. Format is self-describing for future upgrades."""
    if not isinstance(password, str) or len(password) < 10:
        raise ValueError("Password must contain at least 10 characters")
    salt=secrets.token_bytes(16)
    n,r,p=2**14,8,1
    derived=hashlib.scrypt(password.encode('utf-8'),salt=salt,n=n,r=r,p=p,dklen=32)
    return f"scrypt${n}${r}${p}${_b64(salt)}${_b64(derived)}"


def verify_password(password: str, encoded: str | None) -> bool:
    if not encoded or not encoded.startswith('scrypt$'):
        return False
    try:
        _,ns,rs,ps,salt_s,hash_s=encoded.split('$',5)
        derived=hashlib.scrypt(password.encode('utf-8'),salt=_unb64(salt_s),n=int(ns),r=int(rs),p=int(ps),dklen=len(_unb64(hash_s)))
        return hmac.compare_digest(derived,_unb64(hash_s))
    except Exception:
        return False
