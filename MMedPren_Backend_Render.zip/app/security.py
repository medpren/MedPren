import base64, hashlib, hmac, json, secrets, time
from app.config import settings

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def _unb64(data: str) -> bytes:
    return base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))

def generate_otp():
    return f"{secrets.randbelow(1000000):06d}"

def otp_hash(code: str):
    return hmac.new(settings.secret_key.encode(), code.encode(), hashlib.sha256).hexdigest()

def verify_otp(code: str, hashed: str):
    return hmac.compare_digest(otp_hash(code), hashed)

def create_access_token(user_id: str, roles: list[str]):
    header={"alg":"HS256","typ":"JWT"}
    payload={"sub":user_id,"roles":roles,"exp":int(time.time())+settings.access_token_expire_minutes*60}
    head=_b64(json.dumps(header,separators=(",",":")).encode())
    body=_b64(json.dumps(payload,separators=(",",":")).encode())
    sig=_b64(hmac.new(settings.secret_key.encode(),f"{head}.{body}".encode(),hashlib.sha256).digest())
    return f"{head}.{body}.{sig}"

def decode_token(token: str):
    try:
        head,body,sig=token.split(".")
        expected=_b64(hmac.new(settings.secret_key.encode(),f"{head}.{body}".encode(),hashlib.sha256).digest())
        if not hmac.compare_digest(sig,expected): raise ValueError("bad signature")
        payload=json.loads(_unb64(body))
        if int(payload.get("exp",0)) < int(time.time()): raise ValueError("expired")
        return payload
    except Exception as exc:
        raise ValueError("Invalid token") from exc
