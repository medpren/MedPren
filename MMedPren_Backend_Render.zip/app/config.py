from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator

class Settings(BaseSettings):
    app_name: str = "M'MEDPREN API"
    environment: str = "development"
    secret_key: str = "change-me"
    access_token_expire_minutes: int = 10080
    database_url: str = "postgresql+psycopg://mmedpren:mmedpren@localhost:5432/mmedpren"
    redis_url: str = "redis://localhost:6379/0"
    cors_origins: str = "http://localhost:8080"
    otp_ttl_seconds: int = 300
    otp_max_attempts: int = 5
    otp_request_cooldown_seconds: int = 60
    otp_provider: str = "console"
    otp_http_url: str = ""
    otp_http_token: str = ""
    public_api_base_url: str = "http://localhost:8000"
    cloudinary_url: str = ""
    cloudinary_folder: str = "mmedpren/products"
    image_max_bytes: int = 8 * 1024 * 1024
    mpesa_base_url: str = ""
    mpesa_api_key: str = ""
    mpesa_public_key: str = ""
    mpesa_service_provider_code: str = ""
    airtel_base_url: str = ""
    airtel_client_id: str = ""
    airtel_client_secret: str = ""
    airtel_country: str = "CD"
    airtel_currency: str = "USD"
    orange_base_url: str = ""
    orange_client_id: str = ""
    orange_client_secret: str = ""
    orange_merchant_key: str = ""
    @field_validator("database_url", mode="before")
    @classmethod
    def normalize_database_url(cls, value):
        if isinstance(value, str):
            if value.startswith("postgres://"):
                return "postgresql+psycopg://" + value[len("postgres://"):]
            if value.startswith("postgresql://"):
                return "postgresql+psycopg://" + value[len("postgresql://"):]
        return value

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    @property
    def cors_list(self): return [x.strip() for x in self.cors_origins.split(',') if x.strip()]

settings = Settings()
