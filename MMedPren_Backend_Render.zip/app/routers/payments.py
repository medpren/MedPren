import json
from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Payment, PaymentStatus, Order, OrderStatus, User, OrderItem, Product, Store, SellerProfile
from app.schemas import PaymentCreate, PaymentWebhook
from app.deps import current_user
from app.services.payments.providers import get_payment_provider
from app.config import settings
from app.utils import normalize_phone
from app.services.notifications import add_notification, notify_admins, notify_many

router=APIRouter(prefix="/payments",tags=["payments"])

def _seller_users_for_order(db, order_id):
    rows=(db.query(SellerProfile.user_id).join(Store,Store.seller_id==SellerProfile.id).join(Product,Product.store_id==Store.id).join(OrderItem,OrderItem.product_id==Product.id).filter(OrderItem.order_id==order_id).distinct().all())
    return [r[0] for r in rows]
def out(p): return {"id":p.id,"order_id":p.order_id,"provider":p.provider,"amount":p.amount,"currency":p.currency,"status":p.status,"provider_reference":p.provider_reference}
@router.post("")
def initiate(body:PaymentCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    order=db.get(Order,body.order_id)
    if not order or order.customer_id!=user.id: raise HTTPException(404,"Order not found")
    if order.status==OrderStatus.CANCELLED: raise HTTPException(409,"Order cancelled")
    payment=Payment(order_id=order.id,provider=body.provider,phone=normalize_phone(body.phone),amount=order.total,currency=order.currency,status=PaymentStatus.CREATED)
    db.add(payment); db.flush()
    provider=get_payment_provider(body.provider)
    result=provider.collect(phone=payment.phone,amount=payment.amount,currency=payment.currency,external_id=payment.id,callback_url=f"{settings.public_api_base_url}/payments/webhooks/{body.provider}")
    payment.provider_reference=result.reference; payment.status=PaymentStatus(result.status); payment.raw_response=json.dumps(result.raw)
    notify_admins(db,"payment_initiated","Paiement initié",f"Paiement {payment.provider} de {payment.amount} {payment.currency} pour la commande {order.id[:8]}.","payment",payment.id)
    notify_many(db,_seller_users_for_order(db,order.id),"payment_initiated","Paiement de commande initié",f"Commande {order.id[:8]} • {payment.amount} {payment.currency} • {payment.provider}.","payment",payment.id)
    db.commit(); db.refresh(payment); return out(payment)
@router.get("/{payment_id}")
def status(payment_id:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    p=db.get(Payment,payment_id)
    if not p or p.order.customer_id!=user.id: raise HTTPException(404,"Payment not found")
    return out(p)
@router.post("/webhooks/{provider}")
def webhook(provider:str,body:PaymentWebhook,db:Session=Depends(get_db)):
    # Production: validate each provider's signature/token before accepting this payload.
    p=db.query(Payment).filter(Payment.provider==provider,Payment.provider_reference==body.provider_reference).first()
    if not p: raise HTTPException(404,"Payment not found")
    p.status=PaymentStatus(body.status); p.raw_response=json.dumps(body.payload)
    if p.status==PaymentStatus.SUCCESS and p.order.status==OrderStatus.PENDING: p.order.status=OrderStatus.CONFIRMED
    title="Paiement confirmé" if p.status==PaymentStatus.SUCCESS else "Statut de paiement mis à jour"
    add_notification(db,p.order.customer_id,"payment_status",title,f"Commande {p.order_id[:8]} • statut {p.status.value}.","payment",p.id)
    notify_many(db,_seller_users_for_order(db,p.order_id),"payment_status",title,f"Commande {p.order_id[:8]} • {p.amount} {p.currency} • {p.status.value}.","payment",p.id)
    notify_admins(db,"payment_status",title,f"Commande {p.order_id[:8]} • {p.provider} • {p.status.value}.","payment",p.id)
    db.commit(); return {"ok":True}

@router.post("/{payment_id}/sandbox/succeed")
def sandbox_succeed(payment_id:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if settings.environment != "development": raise HTTPException(404,"Not found")
    p=db.get(Payment,payment_id)
    if not p or p.order.customer_id!=user.id or p.provider!="sandbox": raise HTTPException(404,"Payment not found")
    p.status=PaymentStatus.SUCCESS
    if p.order.status==OrderStatus.PENDING: p.order.status=OrderStatus.CONFIRMED
    add_notification(db,p.order.customer_id,"payment_status","Paiement confirmé",f"Le paiement de la commande {p.order_id[:8]} est confirmé.","payment",p.id)
    notify_many(db,_seller_users_for_order(db,p.order_id),"payment_status","Paiement confirmé",f"Commande {p.order_id[:8]} • {p.amount} {p.currency}.","payment",p.id)
    notify_admins(db,"payment_status","Paiement sandbox confirmé",f"Commande {p.order_id[:8]} • {p.amount} {p.currency}.","payment",p.id)
    db.commit(); return out(p)
