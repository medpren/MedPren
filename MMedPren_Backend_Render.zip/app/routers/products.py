from __future__ import annotations

import re

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import require_role
from app.models import Product, Role, SellerProfile, SellerStatus, User
from app.schemas import ProductCreate, ProductUpdate
from app.services.image_storage import (
    ImageStorageError,
    ImageStorageNotConfigured,
    delete_image,
    detect_image_mime,
    upload_image,
)
from app.config import settings
from app.utils import slugify

router = APIRouter(prefix="/products", tags=["products"])


def out(p: Product):
    return {
        "id": p.id,
        "store_id": p.store_id,
        "store_name": p.store.name if p.store else None,
        "name": p.name,
        "slug": p.slug,
        "description": p.description,
        "category": p.category,
        "price": p.price,
        "currency": p.currency,
        "stock_qty": p.stock_qty,
        "image_url": p.image_url,
        "is_active": p.is_active,
    }


def _seller_for_user(user: User, db: Session) -> SellerProfile:
    seller = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not seller or not seller.store:
        raise HTTPException(404, "Seller profile missing")
    return seller


def _owned_product(product_id: str, user: User, db: Session) -> tuple[SellerProfile, Product]:
    seller = _seller_for_user(user, db)
    product = db.get(Product, product_id)
    if not product or product.store_id != seller.store.id:
        raise HTTPException(404, "Product not found")
    return seller, product


def _safe_filename(filename: str | None, mime: str) -> str:
    ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}[mime]
    stem = re.sub(r"[^a-zA-Z0-9_-]+", "-", (filename or "product").rsplit(".", 1)[0]).strip("-")
    return f"{stem or 'product'}{ext}"


@router.get("")
def list_products(
    q: str | None = None,
    category: str | None = None,
    skip: int = 0,
    limit: int = Query(50, le=100),
    db: Session = Depends(get_db),
):
    qs = db.query(Product).filter(Product.is_active == True)
    if q:
        qs = qs.filter(or_(Product.name.ilike(f"%{q}%"), Product.description.ilike(f"%{q}%")))
    if category:
        qs = qs.filter(Product.category == category)
    return [out(p) for p in qs.order_by(Product.created_at.desc()).offset(skip).limit(limit).all()]


@router.get("/{product_id}")
def get_product(product_id: str, db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p or not p.is_active:
        raise HTTPException(404, "Product not found")
    return out(p)


@router.post("")
def create_product(
    body: ProductCreate,
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    seller = _seller_for_user(user, db)
    if seller.status != SellerStatus.APPROVED:
        raise HTTPException(403, "Seller must be approved")
    p = Product(
        store_id=seller.store.id,
        name=body.name,
        slug=f"{slugify(body.name)}-{seller.id[:4]}-{abs(hash(body.name)) % 9999}",
        description=body.description,
        category=body.category,
        price=body.price,
        currency=body.currency.upper(),
        stock_qty=body.stock_qty,
    )
    db.add(p)
    db.commit()
    db.refresh(p)
    return out(p)


@router.patch("/{product_id}")
def update_product(
    product_id: str,
    body: ProductUpdate,
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    seller, p = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED:
        raise HTTPException(403, "Seller must be approved")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    db.commit()
    db.refresh(p)
    return out(p)


@router.post("/{product_id}/image")
async def upload_product_image(
    product_id: str,
    file: UploadFile = File(...),
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    seller, product = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED:
        raise HTTPException(403, "Seller must be approved")

    data = await file.read(settings.image_max_bytes + 1)
    await file.close()
    if not data:
        raise HTTPException(422, "Image file is empty")
    if len(data) > settings.image_max_bytes:
        raise HTTPException(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            f"Image too large. Maximum size is {settings.image_max_bytes // (1024 * 1024)} MB.",
        )

    detected_mime = detect_image_mime(data)
    if detected_mime not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(415, "Only JPEG, PNG and WebP images are accepted")

    old_public_id = product.image_public_id
    try:
        stored = await upload_image(
            data,
            _safe_filename(file.filename, detected_mime),
            detected_mime,
        )
    except ImageStorageNotConfigured as exc:
        raise HTTPException(503, str(exc)) from exc
    except ImageStorageError as exc:
        raise HTTPException(502, str(exc)) from exc

    product.image_url = stored["url"]
    product.image_public_id = stored["public_id"]
    db.commit()
    db.refresh(product)

    if old_public_id and old_public_id != product.image_public_id:
        await delete_image(old_public_id)

    return {"ok": True, "image_url": product.image_url, "product": out(product)}


@router.delete("/{product_id}/image")
async def delete_product_image(
    product_id: str,
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    seller, product = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED:
        raise HTTPException(403, "Seller must be approved")
    old_public_id = product.image_public_id
    product.image_url = None
    product.image_public_id = None
    db.commit()
    await delete_image(old_public_id)
    return {"ok": True, "image_url": None}
