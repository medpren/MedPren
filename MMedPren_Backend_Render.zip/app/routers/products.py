from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.db import get_db
from app.models import Product, SellerProfile, SellerStatus, User, Role
from app.schemas import ProductCreate, ProductUpdate
from app.deps import require_role
from app.utils import slugify

router=APIRouter(prefix="/products",tags=["products"])
def out(p):
    return {"id":p.id,"store_id":p.store_id,"store_name":p.store.name if p.store else None,"name":p.name,"slug":p.slug,"description":p.description,"category":p.category,"price":p.price,"currency":p.currency,"stock_qty":p.stock_qty,"is_active":p.is_active}
@router.get("")
def list_products(q:str|None=None,category:str|None=None,skip:int=0,limit:int=Query(50,le=100),db:Session=Depends(get_db)):
    qs=db.query(Product).filter(Product.is_active==True)
    if q: qs=qs.filter(or_(Product.name.ilike(f"%{q}%"),Product.description.ilike(f"%{q}%")))
    if category: qs=qs.filter(Product.category==category)
    return [out(p) for p in qs.order_by(Product.created_at.desc()).offset(skip).limit(limit).all()]
@router.get("/{product_id}")
def get_product(product_id:str,db:Session=Depends(get_db)):
    p=db.get(Product,product_id)
    if not p or not p.is_active: raise HTTPException(404,"Product not found")
    return out(p)
@router.post("")
def create_product(body:ProductCreate,user:User=Depends(require_role(Role.SELLER)),db:Session=Depends(get_db)):
    seller=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()
    if not seller or seller.status!=SellerStatus.APPROVED: raise HTTPException(403,"Seller must be approved")
    p=Product(store_id=seller.store.id,name=body.name,slug=f"{slugify(body.name)}-{seller.id[:4]}-{abs(hash(body.name))%9999}",description=body.description,category=body.category,price=body.price,currency=body.currency.upper(),stock_qty=body.stock_qty)
    db.add(p); db.commit(); db.refresh(p); return out(p)
@router.patch("/{product_id}")
def update_product(product_id:str,body:ProductUpdate,user:User=Depends(require_role(Role.SELLER)),db:Session=Depends(get_db)):
    seller=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first(); p=db.get(Product,product_id)
    if not p or not seller or p.store_id!=seller.store.id: raise HTTPException(404,"Product not found")
    for k,v in body.model_dump(exclude_unset=True).items(): setattr(p,k,v)
    db.commit(); return out(p)
