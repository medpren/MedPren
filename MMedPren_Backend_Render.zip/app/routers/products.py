from __future__ import annotations
import re
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.deps import require_role
from app.models import Product, Role, SellerProfile, SellerStatus, Store, User
from app.schemas import ProductCreate, ProductUpdate
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, detect_image_mime, resolve_image_mime, safe_upload_filename, upload_image
from app.utils import slugify
from app.services.notifications import notify_admins

router = APIRouter(prefix="/products", tags=["products"])


def out(p: Product):
    seller = p.store.seller if p.store else None
    seller_status = seller.status.value if seller and hasattr(seller.status, "value") else (str(seller.status) if seller else None)
    store_active = bool(p.store and p.store.is_active)
    approved = (p.moderation_status or "pending") == "approved"
    effective_active = bool(p.is_active and approved and store_active and seller and seller.status == SellerStatus.APPROVED)
    return {
        "id": p.id, "store_id": p.store_id, "store_name": p.store.name if p.store else None,
        "seller_id": seller.id if seller else None, "seller_name": seller.business_name if seller else None,
        "name": p.name, "slug": p.slug, "description": p.description, "category": p.category,
        "price": p.price, "currency": p.currency, "stock_qty": p.stock_qty,
        "min_order_qty": p.min_order_qty, "max_order_qty": p.max_order_qty,
        "effective_max_order_qty": min(p.max_order_qty, p.stock_qty) if p.stock_qty > 0 else 0,
        "image_url": p.image_url, "is_active": p.is_active, "moderation_status": p.moderation_status,
        "seller_status": seller_status, "store_active": store_active, "effective_active": effective_active,
        "effective_status": "active" if effective_active else (
            "pending_approval" if p.moderation_status == "pending" else
            "seller_suspended" if seller and seller.status == SellerStatus.SUSPENDED else "suspended"
        ),
    }


def _public_query(db: Session):
    return (db.query(Product).join(Product.store).join(Store.seller).filter(
        Product.is_active == True,
        Product.moderation_status == "approved",
        Store.is_active == True,
        SellerProfile.status == SellerStatus.APPROVED,
    ))


def _seller_for_user(user: User, db: Session) -> SellerProfile:
    seller = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not seller or not seller.store: raise HTTPException(404, "Seller profile missing")
    return seller


def _owned_product(product_id: str, user: User, db: Session) -> tuple[SellerProfile, Product]:
    seller = _seller_for_user(user, db)
    product = db.get(Product, product_id)
    if not product or product.store_id != seller.store.id: raise HTTPException(404, "Product not found")
    return seller, product


def _safe_filename(filename: str | None, mime: str) -> str:
    ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}[mime]
    stem = re.sub(r"[^a-zA-Z0-9_-]+", "-", (filename or "product").rsplit(".", 1)[0]).strip("-")
    return f"{stem or 'product'}{ext}"

@router.get("")
def list_products(q: str | None = None, category: str | None = None, skip: int = 0, limit: int = Query(50, le=100), db: Session = Depends(get_db)):
    qs = _public_query(db)
    if q: qs = qs.filter(or_(Product.name.ilike(f"%{q}%"), Product.description.ilike(f"%{q}%")))
    if category: qs = qs.filter(Product.category == category)
    return [out(p) for p in qs.order_by(Product.created_at.desc()).offset(skip).limit(limit).all()]

@router.get("/mine")
def my_products(user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    seller = _seller_for_user(user, db)
    return [out(p) for p in db.query(Product).filter(Product.store_id == seller.store.id).order_by(Product.created_at.desc()).all()]

@router.get("/{product_id}")
def get_product(product_id: str, db: Session = Depends(get_db)):
    p = _public_query(db).filter(Product.id == product_id).first()
    if not p: raise HTTPException(404, "Product not found")
    return out(p)

@router.post("")
def create_product(body: ProductCreate, user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    seller = _seller_for_user(user, db)
    if seller.status != SellerStatus.APPROVED or not seller.store.is_active: raise HTTPException(403, "Seller must be approved")
    p = Product(store_id=seller.store.id, name=body.name, slug=f"{slugify(body.name)}-{seller.id[:4]}-{abs(hash(body.name)) % 9999}",
                description=body.description, category=body.category, price=body.price, currency=body.currency.upper(), stock_qty=body.stock_qty,
                min_order_qty=body.min_order_qty, max_order_qty=body.max_order_qty, is_active=True, moderation_status="pending")
    db.add(p); db.flush(); notify_admins(db,"product_pending","Produit à valider",f"{seller.business_name} a soumis « {p.name} » pour publication.","product",p.id)
    db.commit(); db.refresh(p); return out(p)

@router.patch("/{product_id}")
def update_product(product_id: str, body: ProductUpdate, user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    seller, p = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED or not seller.store.is_active: raise HTTPException(403, "Seller must be approved")
    data = body.model_dump(exclude_unset=True)
    proposed_min = data.get("min_order_qty", p.min_order_qty)
    proposed_max = data.get("max_order_qty", p.max_order_qty)
    if proposed_max < proposed_min: raise HTTPException(422, "Maximum order quantity must be >= minimum order quantity")
    for k, v in data.items():
        if k == "currency" and isinstance(v, str): v = v.upper()
        setattr(p, k, v)
    if set(data) & {"name","description","category","price","currency","min_order_qty","max_order_qty"}:
        p.moderation_status = "pending"
        p.is_active = True
    if set(data) & {"name","description","category","price","currency","min_order_qty","max_order_qty"}: notify_admins(db,"product_pending","Produit modifié à revalider",f"{seller.business_name} a modifié « {p.name} ».","product",p.id)
    db.commit(); db.refresh(p); return out(p)

@router.post("/{product_id}/image")
async def upload_product_image(product_id: str, file: UploadFile = File(...), user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    seller, product = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED or not seller.store.is_active: raise HTTPException(403, "Seller must be approved")
    data = await file.read(settings.image_max_bytes + 1); await file.close()
    if not data: raise HTTPException(422, "Image file is empty")
    if len(data) > settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, f"Image too large. Maximum size is {settings.image_max_bytes // (1024 * 1024)} MB.")
    detected_mime = resolve_image_mime(data, file.content_type, file.filename)
    if not detected_mime: raise HTTPException(415, "Le fichier sélectionné ne semble pas être une image compatible")
    old_public_id = product.image_public_id
    try: stored = await upload_image(data, _safe_filename(file.filename, detected_mime), detected_mime)
    except ImageStorageNotConfigured as exc: raise HTTPException(503, str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502, str(exc)) from exc
    product.image_url = stored["url"]; product.image_public_id = stored["public_id"]
    product.moderation_status = "pending"; product.is_active = True
    notify_admins(db,"product_pending","Photo produit à revalider",f"{seller.business_name} a modifié la photo de « {product.name} ».","product",product.id)
    db.commit(); db.refresh(product)
    if old_public_id and old_public_id != product.image_public_id: await delete_image(old_public_id)
    return {"ok": True, "image_url": product.image_url, "product": out(product), "message":"Image uploaded; product awaits admin approval"}

@router.delete("/{product_id}/image")
async def delete_product_image(product_id: str, user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    seller, product = _owned_product(product_id, user, db)
    if seller.status != SellerStatus.APPROVED or not seller.store.is_active: raise HTTPException(403, "Seller must be approved")
    old_public_id = product.image_public_id; product.image_url = None; product.image_public_id = None; product.moderation_status="pending"
    db.commit(); await delete_image(old_public_id); return {"ok": True, "image_url": None}
