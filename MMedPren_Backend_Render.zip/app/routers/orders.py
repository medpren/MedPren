from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, Product, Order, OrderItem, Delivery, Role, OrderStatus
from app.schemas import OrderCreate
from app.deps import current_user, require_role

router=APIRouter(prefix="/orders",tags=["orders"])
def serialize(o): return {"id":o.id,"status":o.status,"currency":o.currency,"subtotal":o.subtotal,"delivery_fee":o.delivery_fee,"total":o.total,"delivery_name":o.delivery_name,"delivery_phone":o.delivery_phone,"delivery_address":o.delivery_address,"items":[{"product_id":i.product_id,"product_name":i.product_name,"unit_price":i.unit_price,"quantity":i.quantity,"line_total":i.line_total} for i in o.items]}
@router.post("")
def create(body:OrderCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not body.items: raise HTTPException(422,"Order requires items")
    ids=[i.product_id for i in body.items]; products={p.id:p for p in db.query(Product).filter(Product.id.in_(ids),Product.is_active==True).all()}
    if len(products)!=len(set(ids)): raise HTTPException(422,"One or more products are unavailable")
    currencies={products[i.product_id].currency for i in body.items}
    if len(currencies)!=1: raise HTTPException(422,"Mixed currencies are not supported")
    subtotal=Decimal('0'); order=Order(customer_id=user.id,currency=currencies.pop(),delivery_fee=body.delivery_fee,delivery_name=body.delivery_name,delivery_phone=body.delivery_phone,delivery_address=body.delivery_address)
    db.add(order); db.flush()
    for item in body.items:
        p=products[item.product_id]
        if p.stock_qty < item.quantity: raise HTTPException(409,f"Insufficient stock for {p.name}")
        line=p.price*item.quantity; subtotal+=line; p.stock_qty-=item.quantity
        db.add(OrderItem(order_id=order.id,product_id=p.id,product_name=p.name,unit_price=p.price,quantity=item.quantity,line_total=line))
    order.subtotal=subtotal; order.total=subtotal+body.delivery_fee; db.add(Delivery(order_id=order.id)); db.commit(); db.refresh(order); return serialize(order)
@router.get("/mine")
def mine(user:User=Depends(current_user),db:Session=Depends(get_db)): return [serialize(o) for o in db.query(Order).filter(Order.customer_id==user.id).order_by(Order.created_at.desc()).all()]
@router.get("/{order_id}")
def get(order_id:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    o=db.get(Order,order_id)
    if not o or (o.customer_id!=user.id and 'admin' not in {r.role.value for r in user.roles}): raise HTTPException(404,"Order not found")
    return serialize(o)
