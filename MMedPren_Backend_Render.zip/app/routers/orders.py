from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, Product, Order, OrderItem, Delivery, Role, OrderStatus, Store, SellerProfile, SellerStatus
from app.schemas import OrderCreate
from app.deps import current_user
from app.services.notifications import add_notification, notify_admins, notify_many

router=APIRouter(prefix="/orders",tags=["orders"])

def serialize(o):
    return {"id":o.id,"status":o.status,"currency":o.currency,"subtotal":o.subtotal,"delivery_fee":o.delivery_fee,"total":o.total,"delivery_name":o.delivery_name,"delivery_phone":o.delivery_phone,"delivery_address":o.delivery_address,"created_at":o.created_at,"items":[{"product_id":i.product_id,"product_name":i.product_name,"unit_price":i.unit_price,"quantity":i.quantity,"line_total":i.line_total} for i in o.items]}

@router.post("")
def create(body:OrderCreate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not body.items: raise HTTPException(422,"Order requires items")
    ids=[i.product_id for i in body.items]
    products={p.id:p for p in db.query(Product).join(Product.store).join(Store.seller).filter(
        Product.id.in_(ids),Product.is_active==True,Product.moderation_status=="approved",Store.is_active==True,SellerProfile.status==SellerStatus.APPROVED).all()}
    if len(products)!=len(set(ids)): raise HTTPException(422,"One or more products are unavailable")
    currencies={products[i.product_id].currency for i in body.items}
    if len(currencies)!=1: raise HTTPException(422,"Mixed currencies are not supported")
    subtotal=Decimal('0'); order=Order(customer_id=user.id,currency=currencies.pop(),delivery_fee=body.delivery_fee,delivery_name=body.delivery_name,delivery_phone=body.delivery_phone,delivery_address=body.delivery_address)
    db.add(order); db.flush(); seller_user_ids=set(); seller_names=set()
    for item in body.items:
        p=products[item.product_id]
        if p.stock_qty < item.quantity: raise HTTPException(409,f"Insufficient stock for {p.name}")
        line=p.price*item.quantity; subtotal+=line; p.stock_qty-=item.quantity
        db.add(OrderItem(order_id=order.id,product_id=p.id,product_name=p.name,unit_price=p.price,quantity=item.quantity,line_total=line))
        if p.store and p.store.seller:
            seller_user_ids.add(p.store.seller.user_id); seller_names.add(p.store.name)
    order.subtotal=subtotal; order.total=subtotal+body.delivery_fee; db.add(Delivery(order_id=order.id))
    short=order.id[:8]
    notify_many(db,seller_user_ids,"order_created","Nouvelle commande initiée",f"Commande {short} • {order.total} {order.currency}. Ouvrez votre espace vendeur pour la suivre.","order",order.id)
    notify_admins(db,"order_created","Nouvelle commande sur M’MEDPREN",f"Commande {short} initiée auprès de {', '.join(sorted(seller_names)) or 'vendeur M’MEDPREN'} • {order.total} {order.currency}.","order",order.id)
    add_notification(db,user.id,"order_created","Commande créée",f"Votre commande {short} a été créée. Vous pouvez suivre son évolution dans Mes commandes.","order",order.id)
    db.commit(); db.refresh(order); return serialize(order)

@router.get("/mine")
def mine(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return [serialize(o) for o in db.query(Order).filter(Order.customer_id==user.id).order_by(Order.created_at.desc()).all()]

@router.get("/{order_id}")
def get(order_id:str,user:User=Depends(current_user),db:Session=Depends(get_db)):
    o=db.get(Order,order_id)
    if not o or (o.customer_id!=user.id and 'admin' not in {r.role.value for r in user.roles}): raise HTTPException(404,"Order not found")
    return serialize(o)
