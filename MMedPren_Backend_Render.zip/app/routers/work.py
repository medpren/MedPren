from datetime import datetime, timezone
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.config import settings
from app.db import get_db
from app.deps import current_user, require_role, role_names
from app.models import (
    Role, User, WorkProfile, WorkOpportunity, WorkApplication,
    WorkTraining, WorkEnrollment,
)
from app.schemas import (
    WorkProfileUpdate, WorkOpportunityCreate, WorkOpportunityUpdate,
    WorkApplicationCreate, WorkApplicationDecision,
    WorkTrainingCreate, WorkTrainingUpdate,
    WorkEnrollmentCreate, WorkEnrollmentDecision,
)
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, resolve_image_mime, safe_upload_filename, upload_image
from app.services.notifications import add_notification, notify_admins

router = APIRouter(prefix="/work", tags=["work4future"])
admin_router = APIRouter(prefix="/admin/work", tags=["admin-work4future"])


def _dt(value: str | None):
    if value is None or value == "":
        return None
    try:
        v = value.strip().replace("Z", "+00:00")
        out = datetime.fromisoformat(v)
        if out.tzinfo is None:
            out = out.replace(tzinfo=timezone.utc)
        return out
    except Exception as exc:
        raise HTTPException(422, "Date invalide. Utilisez une date ISO valide.") from exc


def _expired(deadline):
    if not deadline:
        return False
    d = deadline if deadline.tzinfo else deadline.replace(tzinfo=timezone.utc)
    return d < datetime.now(timezone.utc)


def _profile_out(p: WorkProfile | None):
    if not p:
        return None
    return {
        "id": p.id, "user_id": p.user_id, "headline": p.headline, "skills": p.skills,
        "city": p.city, "bio": p.bio, "experience": p.experience, "education": p.education,
        "availability": p.availability, "created_at": p.created_at, "updated_at": p.updated_at,
    }


def _opp_out(o: WorkOpportunity):
    return {
        "id": o.id, "kind": o.kind, "title": o.title, "organization": o.organization,
        "location": o.location, "work_mode": o.work_mode, "contract_type": o.contract_type,
        "salary_text": o.salary_text, "description": o.description, "requirements": o.requirements,
        "application_url": o.application_url, "contact_email": o.contact_email,
        "image_url": o.image_url, "created_by_id": o.created_by_id,
        "deadline_at": o.deadline_at, "is_active": o.is_active, "is_featured": o.is_featured,
        "is_expired": _expired(o.deadline_at), "created_at": o.created_at, "updated_at": o.updated_at,
    }


def _training_out(t: WorkTraining, enrolled_count: int | None = None):
    out = {
        "id": t.id, "title": t.title, "provider": t.provider, "category": t.category,
        "mode": t.mode, "location": t.location, "level": t.level, "duration_text": t.duration_text,
        "fee_text": t.fee_text, "description": t.description, "prerequisites": t.prerequisites,
        "external_url": t.external_url, "image_url": t.image_url, "created_by_id": t.created_by_id,
        "start_at": t.start_at, "deadline_at": t.deadline_at,
        "capacity": t.capacity, "is_active": t.is_active, "is_featured": t.is_featured,
        "is_expired": _expired(t.deadline_at), "created_at": t.created_at, "updated_at": t.updated_at,
    }
    if enrolled_count is not None:
        out["enrolled_count"] = enrolled_count
        out["places_left"] = max(0, t.capacity - enrolled_count) if t.capacity else None
    return out


def _application_out(a: WorkApplication, db: Session, include_user=False):
    o = db.get(WorkOpportunity, a.opportunity_id)
    out = {
        "id": a.id, "opportunity_id": a.opportunity_id, "user_id": a.user_id,
        "motivation": a.motivation, "status": a.status, "admin_note": a.admin_note,
        "created_at": a.created_at, "updated_at": a.updated_at,
        "opportunity": _opp_out(o) if o else None,
    }
    if include_user:
        u = db.get(User, a.user_id)
        p = db.query(WorkProfile).filter(WorkProfile.user_id == a.user_id).first()
        out["user"] = {
            "id": u.id if u else a.user_id,
            "full_name": u.full_name if u else None,
            "phone": u.phone if u else None,
            "whatsapp_phone": u.whatsapp_phone if u else None,
            "email": u.email if u else None,
            "profile_image_url": u.profile_image_url if u else None,
            "work_profile": _profile_out(p),
        }
    return out


def _enrollment_out(e: WorkEnrollment, db: Session, include_user=False):
    t = db.get(WorkTraining, e.training_id)
    out = {
        "id": e.id, "training_id": e.training_id, "user_id": e.user_id,
        "status": e.status, "note": e.note, "admin_note": e.admin_note,
        "created_at": e.created_at, "updated_at": e.updated_at,
        "training": _training_out(t) if t else None,
    }
    if include_user:
        u = db.get(User, e.user_id)
        p = db.query(WorkProfile).filter(WorkProfile.user_id == e.user_id).first()
        out["user"] = {
            "id": u.id if u else e.user_id,
            "full_name": u.full_name if u else None,
            "phone": u.phone if u else None,
            "whatsapp_phone": u.whatsapp_phone if u else None,
            "email": u.email if u else None,
            "profile_image_url": u.profile_image_url if u else None,
            "work_profile": _profile_out(p),
        }
    return out


@router.get("/opportunities")
def list_opportunities(
    q: str = "", kind: str = "", location: str = "", db: Session = Depends(get_db)
):
    query = db.query(WorkOpportunity).filter(WorkOpportunity.is_active == True)  # noqa: E712
    if kind and kind != "all":
        query = query.filter(WorkOpportunity.kind == kind)
    if location:
        query = query.filter(WorkOpportunity.location.ilike(f"%{location.strip()}%"))
    if q.strip():
        term = f"%{q.strip()}%"
        query = query.filter(or_(
            WorkOpportunity.title.ilike(term), WorkOpportunity.organization.ilike(term),
            WorkOpportunity.description.ilike(term), WorkOpportunity.requirements.ilike(term),
            WorkOpportunity.location.ilike(term),
        ))
    rows = query.order_by(WorkOpportunity.is_featured.desc(), WorkOpportunity.created_at.desc()).all()
    return [_opp_out(x) for x in rows]


@router.get("/opportunities/{opportunity_id}")
def get_opportunity(opportunity_id: str, db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not o.is_active:
        raise HTTPException(404, "Opportunité introuvable")
    return _opp_out(o)


@router.get("/trainings")
def list_trainings(q: str = "", category: str = "", db: Session = Depends(get_db)):
    query = db.query(WorkTraining).filter(WorkTraining.is_active == True)  # noqa: E712
    if category and category != "all":
        query = query.filter(WorkTraining.category == category)
    if q.strip():
        term = f"%{q.strip()}%"
        query = query.filter(or_(
            WorkTraining.title.ilike(term), WorkTraining.provider.ilike(term),
            WorkTraining.description.ilike(term), WorkTraining.category.ilike(term),
            WorkTraining.location.ilike(term),
        ))
    rows = query.order_by(WorkTraining.is_featured.desc(), WorkTraining.created_at.desc()).all()
    result = []
    for t in rows:
        count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
        result.append(_training_out(t, count))
    return result


@router.get("/trainings/{training_id}")
def get_training(training_id: str, db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not t.is_active:
        raise HTTPException(404, "Formation introuvable")
    count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
    return _training_out(t, count)


@router.get("/profile")
def my_profile(user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = db.query(WorkProfile).filter(WorkProfile.user_id == user.id).first()
    return {"profile": _profile_out(p), "user": {"full_name": user.full_name, "phone": user.phone, "email": user.email, "whatsapp_phone": user.whatsapp_phone}}


@router.put("/profile")
def save_profile(body: WorkProfileUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = db.query(WorkProfile).filter(WorkProfile.user_id == user.id).first()
    if not p:
        p = WorkProfile(user_id=user.id)
        db.add(p)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v.strip() if isinstance(v, str) else v)
    db.commit(); db.refresh(p)
    return {"ok": True, "profile": _profile_out(p)}


@router.get("/profiles/{user_id}")
def public_profile(user_id: str, db: Session = Depends(get_db)):
    p = db.query(WorkProfile).filter(WorkProfile.user_id == user_id).first()
    u = db.get(User, user_id)
    if not p or not u or not u.is_active or not (p.headline or p.skills or p.bio):
        raise HTTPException(404, "Profil professionnel introuvable")
    return {
        "user_id": u.id, "full_name": u.full_name, "profile_image_url": u.profile_image_url,
        "profile": _profile_out(p),
    }


def _can_edit_work(created_by_id: str | None, user: User) -> bool:
    return bool(created_by_id and created_by_id == user.id) or Role.ADMIN.value in role_names(user)


async def _save_work_image(obj, file: UploadFile, db: Session, folder: str, stem: str):
    data = await file.read(settings.image_max_bytes + 1); await file.close()
    if not data:
        raise HTTPException(422, "Image vide")
    if len(data) > settings.image_max_bytes:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "Image trop volumineuse")
    mime = resolve_image_mime(data, file.content_type, file.filename)
    if not mime:
        raise HTTPException(415, "Le fichier sélectionné ne semble pas être une image compatible")
    old = obj.image_public_id
    try:
        stored = await upload_image(data, safe_upload_filename(file.filename, mime, stem), mime, folder=folder)
    except ImageStorageNotConfigured as exc:
        raise HTTPException(503, str(exc)) from exc
    except ImageStorageError as exc:
        raise HTTPException(502, str(exc)) from exc
    obj.image_url = stored["url"]; obj.image_public_id = stored["public_id"]
    db.commit(); db.refresh(obj)
    if old and old != obj.image_public_id:
        await delete_image(old)
    return obj


@router.patch("/opportunities/{opportunity_id}")
def author_update_opportunity(opportunity_id: str, body: WorkOpportunityUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not _can_edit_work(o.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette opportunité")
    data = body.model_dump(exclude_unset=True)
    if "deadline_at" in data: data["deadline_at"] = _dt(data["deadline_at"])
    for k, v in data.items(): setattr(o, k, v)
    db.commit(); db.refresh(o); return _opp_out(o)


@router.post("/opportunities/{opportunity_id}/image")
async def author_opportunity_image(opportunity_id: str, file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not _can_edit_work(o.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette opportunité")
    o = await _save_work_image(o, file, db, "mmedpren/work/opportunities", "opportunite")
    return {"ok": True, "opportunity": _opp_out(o)}


@router.delete("/opportunities/{opportunity_id}/image")
async def author_delete_opportunity_image(opportunity_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not _can_edit_work(o.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette opportunité")
    old = o.image_public_id; o.image_url = None; o.image_public_id = None; db.commit(); await delete_image(old)
    return {"ok": True, "opportunity": _opp_out(o)}


@router.patch("/trainings/{training_id}")
def author_update_training(training_id: str, body: WorkTrainingUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not _can_edit_work(t.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette formation")
    data = body.model_dump(exclude_unset=True)
    if "start_at" in data: data["start_at"] = _dt(data["start_at"])
    if "deadline_at" in data: data["deadline_at"] = _dt(data["deadline_at"])
    for k, v in data.items(): setattr(t, k, v)
    db.commit(); db.refresh(t)
    count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
    return _training_out(t, count)


@router.post("/trainings/{training_id}/image")
async def author_training_image(training_id: str, file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not _can_edit_work(t.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette formation")
    t = await _save_work_image(t, file, db, "mmedpren/work/trainings", "formation")
    count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
    return {"ok": True, "training": _training_out(t, count)}


@router.delete("/trainings/{training_id}/image")
async def author_delete_training_image(training_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not _can_edit_work(t.created_by_id, user):
        raise HTTPException(403, "Vous ne pouvez pas modifier cette formation")
    old = t.image_public_id; t.image_url = None; t.image_public_id = None; db.commit(); await delete_image(old)
    count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
    return {"ok": True, "training": _training_out(t, count)}


@router.post("/opportunities/{opportunity_id}/apply")
def apply(opportunity_id: str, body: WorkApplicationCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not o.is_active:
        raise HTTPException(404, "Opportunité introuvable")
    if _expired(o.deadline_at):
        raise HTTPException(409, "La date limite de cette opportunité est dépassée")
    existing = db.query(WorkApplication).filter(WorkApplication.opportunity_id == o.id, WorkApplication.user_id == user.id).first()
    if existing:
        raise HTTPException(409, "Vous avez déjà candidaté à cette opportunité")
    profile = db.query(WorkProfile).filter(WorkProfile.user_id == user.id).first()
    if not profile or not (profile.headline or profile.skills):
        raise HTTPException(409, "Complétez d’abord votre profil professionnel Work4Future")
    a = WorkApplication(opportunity_id=o.id, user_id=user.id, motivation=(body.motivation or "").strip() or None)
    db.add(a)
    notify_admins(db, "work_application", "Nouvelle candidature Work4Future", f"{user.full_name or user.phone} a candidaté à « {o.title} ».", "work_application", a.id)
    db.commit(); db.refresh(a)
    return {"ok": True, "application": _application_out(a, db)}


@router.get("/applications")
def my_applications(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(WorkApplication).filter(WorkApplication.user_id == user.id).order_by(WorkApplication.created_at.desc()).all()
    return [_application_out(x, db) for x in rows]


@router.post("/trainings/{training_id}/enroll")
def enroll(training_id: str, body: WorkEnrollmentCreate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not t.is_active:
        raise HTTPException(404, "Formation introuvable")
    if _expired(t.deadline_at):
        raise HTTPException(409, "Les inscriptions à cette formation sont closes")
    existing = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.user_id == user.id).first()
    if existing and existing.status != "cancelled":
        raise HTTPException(409, "Vous êtes déjà inscrit à cette formation")
    current_count = db.query(WorkEnrollment).filter(WorkEnrollment.training_id == t.id, WorkEnrollment.status != "cancelled").count()
    if t.capacity and current_count >= t.capacity:
        raise HTTPException(409, "Cette formation est complète")
    if existing:
        existing.status = "registered"; existing.note = (body.note or "").strip() or None; existing.admin_note = None
        e = existing
    else:
        e = WorkEnrollment(training_id=t.id, user_id=user.id, note=(body.note or "").strip() or None)
        db.add(e)
    notify_admins(db, "work_enrollment", "Nouvelle inscription Work4Future", f"{user.full_name or user.phone} s’est inscrit à « {t.title} ».", "work_enrollment", e.id)
    db.commit(); db.refresh(e)
    return {"ok": True, "enrollment": _enrollment_out(e, db)}


@router.get("/enrollments")
def my_enrollments(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(WorkEnrollment).filter(WorkEnrollment.user_id == user.id).order_by(WorkEnrollment.created_at.desc()).all()
    return [_enrollment_out(x, db) for x in rows]


@router.delete("/enrollments/{enrollment_id}")
def cancel_my_enrollment(enrollment_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    e = db.get(WorkEnrollment, enrollment_id)
    if not e or e.user_id != user.id:
        raise HTTPException(404, "Inscription introuvable")
    if e.status == "completed":
        raise HTTPException(409, "Une formation terminée ne peut pas être annulée")
    e.status = "cancelled"
    db.commit()
    return {"ok": True}


@admin_router.get("/summary")
def admin_summary(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return {
        "opportunities": db.query(WorkOpportunity).count(),
        "active_opportunities": db.query(WorkOpportunity).filter(WorkOpportunity.is_active == True).count(),  # noqa: E712
        "applications": db.query(WorkApplication).count(),
        "pending_applications": db.query(WorkApplication).filter(WorkApplication.status.in_(["submitted", "reviewing"])).count(),
        "trainings": db.query(WorkTraining).count(),
        "enrollments": db.query(WorkEnrollment).filter(WorkEnrollment.status != "cancelled").count(),
    }


@admin_router.get("/opportunities")
def admin_opportunities(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [_opp_out(x) for x in db.query(WorkOpportunity).order_by(WorkOpportunity.created_at.desc()).all()]


@admin_router.post("/opportunities")
def admin_create_opportunity(body: WorkOpportunityCreate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    data = body.model_dump()
    data["deadline_at"] = _dt(data.pop("deadline_at", None))
    o = WorkOpportunity(**data, created_by_id=admin.id)
    db.add(o); db.commit(); db.refresh(o)
    return _opp_out(o)


@admin_router.patch("/opportunities/{opportunity_id}")
def admin_update_opportunity(opportunity_id: str, body: WorkOpportunityUpdate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o: raise HTTPException(404, "Opportunité introuvable")
    data = body.model_dump(exclude_unset=True)
    if "deadline_at" in data: data["deadline_at"] = _dt(data["deadline_at"])
    for k, v in data.items(): setattr(o, k, v)
    db.commit(); db.refresh(o); return _opp_out(o)


@admin_router.delete("/opportunities/{opportunity_id}")
async def admin_delete_opportunity(opportunity_id: str, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o: raise HTTPException(404, "Opportunité introuvable")
    old = o.image_public_id; db.delete(o); db.commit(); await delete_image(old); return {"ok": True}


@admin_router.get("/applications")
def admin_applications(status: str = Query(default=""), admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    q = db.query(WorkApplication)
    if status: q = q.filter(WorkApplication.status == status)
    return [_application_out(x, db, True) for x in q.order_by(WorkApplication.created_at.desc()).all()]


@admin_router.patch("/applications/{application_id}")
def admin_application_decision(application_id: str, body: WorkApplicationDecision, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    a = db.get(WorkApplication, application_id)
    if not a: raise HTTPException(404, "Candidature introuvable")
    a.status = body.status; a.admin_note = (body.admin_note or "").strip() or None
    o = db.get(WorkOpportunity, a.opportunity_id)
    label = {"submitted":"reçue", "reviewing":"en cours d’étude", "shortlisted":"présélectionnée", "rejected":"non retenue", "accepted":"acceptée"}.get(a.status, a.status)
    add_notification(db, a.user_id, "work_application_status", "Mise à jour de votre candidature", f"Votre candidature à « {o.title if o else 'une opportunité'} » est {label}.", "work_application", a.id)
    db.commit(); db.refresh(a); return _application_out(a, db, True)


@admin_router.get("/trainings")
def admin_trainings(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    rows = db.query(WorkTraining).order_by(WorkTraining.created_at.desc()).all()
    result=[]
    for t in rows:
        count=db.query(WorkEnrollment).filter(WorkEnrollment.training_id==t.id,WorkEnrollment.status!="cancelled").count()
        result.append(_training_out(t,count))
    return result


@admin_router.post("/trainings")
def admin_create_training(body: WorkTrainingCreate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    data = body.model_dump()
    data["start_at"] = _dt(data.pop("start_at", None)); data["deadline_at"] = _dt(data.pop("deadline_at", None))
    t = WorkTraining(**data, created_by_id=admin.id)
    db.add(t); db.commit(); db.refresh(t); return _training_out(t, 0)


@admin_router.patch("/trainings/{training_id}")
def admin_update_training(training_id: str, body: WorkTrainingUpdate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t: raise HTTPException(404, "Formation introuvable")
    data = body.model_dump(exclude_unset=True)
    if "start_at" in data: data["start_at"] = _dt(data["start_at"])
    if "deadline_at" in data: data["deadline_at"] = _dt(data["deadline_at"])
    for k, v in data.items(): setattr(t, k, v)
    db.commit(); db.refresh(t)
    count=db.query(WorkEnrollment).filter(WorkEnrollment.training_id==t.id,WorkEnrollment.status!="cancelled").count()
    return _training_out(t,count)


@admin_router.delete("/trainings/{training_id}")
async def admin_delete_training(training_id: str, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t: raise HTTPException(404, "Formation introuvable")
    old = t.image_public_id; db.delete(t); db.commit(); await delete_image(old); return {"ok": True}


@admin_router.get("/enrollments")
def admin_enrollments(status: str = Query(default=""), admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    q = db.query(WorkEnrollment)
    if status: q = q.filter(WorkEnrollment.status == status)
    return [_enrollment_out(x, db, True) for x in q.order_by(WorkEnrollment.created_at.desc()).all()]


@admin_router.patch("/enrollments/{enrollment_id}")
def admin_enrollment_decision(enrollment_id: str, body: WorkEnrollmentDecision, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    e = db.get(WorkEnrollment, enrollment_id)
    if not e: raise HTTPException(404, "Inscription introuvable")
    e.status = body.status; e.admin_note = (body.admin_note or "").strip() or None
    t = db.get(WorkTraining, e.training_id)
    label = {"registered":"enregistrée", "confirmed":"confirmée", "completed":"terminée", "cancelled":"annulée"}.get(e.status, e.status)
    add_notification(db, e.user_id, "work_training_status", "Mise à jour de votre formation", f"Votre inscription à « {t.title if t else 'une formation'} » est {label}.", "work_enrollment", e.id)
    db.commit(); db.refresh(e); return _enrollment_out(e, db, True)
