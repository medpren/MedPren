from __future__ import annotations

from html import escape
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.config import settings
from app.db import get_db
from app.models import Product, SellerProfile, SellerStatus, Store, User, WorkOpportunity, WorkProfile, WorkTraining

router = APIRouter(prefix="/share", tags=["social-share"])


def _front_url(kind: str, entity_id: str) -> str:
    base = (settings.frontend_url or "https://medpren.github.io/MedPren/").rstrip("/") + "/"
    return base + "?" + urlencode({"share": kind, "id": entity_id})


def _plain(value, limit=240):
    txt = " ".join(str(value or "").replace("\n", " ").split())
    return txt[:limit] + ("…" if len(txt) > limit else "")


def _page(*, title: str, description: str, canonical: str, app_url: str, image: str | None = None, body_html: str = "") -> HTMLResponse:
    t, d, c, a = map(escape, (title, description, canonical, app_url))
    image_meta = ""
    if image and str(image).startswith("https://"):
        im = escape(str(image), quote=True)
        image_meta = f'<meta property="og:image" content="{im}"><meta name="twitter:image" content="{im}">'
    html = f'''<!doctype html><html lang="fr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{t} — M’MEDPREN</title><meta name="description" content="{d}">
<link rel="canonical" href="{c}">
<meta property="og:type" content="website"><meta property="og:site_name" content="M’MEDPREN"><meta property="og:title" content="{t}"><meta property="og:description" content="{d}"><meta property="og:url" content="{c}">{image_meta}
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{t}"><meta name="twitter:description" content="{d}">
<style>body{{font-family:Inter,system-ui,-apple-system,sans-serif;margin:0;background:#f8f7f5;color:#241d19}}main{{max-width:820px;margin:auto;padding:28px 16px 60px}}.card{{background:#fff;border:1px solid #ece5df;border-radius:24px;overflow:hidden;box-shadow:0 14px 45px #39291d12}}.hero{{width:100%;max-height:520px;object-fit:contain;background:#fff7ef}}.pad{{padding:22px}}h1{{font-size:clamp(28px,6vw,48px);line-height:1.05;margin:8px 0 12px}}p{{line-height:1.6;color:#665d57}}.eyebrow{{font-size:12px;font-weight:900;color:#d96e27;text-transform:uppercase;letter-spacing:.08em}}.btn{{display:inline-block;background:#f7934a;color:#fff;text-decoration:none;font-weight:850;padding:13px 18px;border-radius:13px;margin-top:10px}}.meta{{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}}.chip{{padding:6px 9px;border-radius:999px;background:#f5f1ed;font-size:12px;font-weight:750}}.shop{{margin-top:18px;padding:16px;border-radius:16px;background:#fff8f1}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-top:12px}}.mini{{border:1px solid #eee5de;border-radius:14px;padding:10px;background:#fff}}.mini img{{width:100%;height:110px;object-fit:cover;border-radius:10px}}.mini b{{display:block;margin-top:8px;font-size:13px}}@media(max-width:520px){{main{{padding:12px 10px 40px}}.pad{{padding:16px}}}}</style>
</head><body><main><div class="card">{body_html}<div class="pad"><a class="btn" href="{a}">Ouvrir dans M’MEDPREN →</a></div></div></main></body></html>'''
    return HTMLResponse(html)


def _public_product(db: Session, product_id: str) -> Product:
    p = (db.query(Product).join(Product.store).join(Store.seller).filter(
        Product.id == product_id, Product.is_active == True, Product.moderation_status == "approved",  # noqa: E712
        Store.is_active == True, SellerProfile.status == SellerStatus.APPROVED,  # noqa: E712
    ).first())
    if not p:
        raise HTTPException(404, "Produit introuvable")
    return p


@router.get("/product/{product_id}", response_class=HTMLResponse)
def share_product(product_id: str, request: Request, db: Session = Depends(get_db)):
    p = _public_product(db, product_id)
    store = p.store
    others = (db.query(Product).filter(Product.store_id == store.id, Product.is_active == True, Product.moderation_status == "approved")  # noqa: E712
              .order_by(Product.created_at.desc()).limit(12).all())
    image = p.image_url or store.logo_url
    desc = _plain(p.description or f"{p.name} disponible chez {store.name} sur M’MEDPREN.")
    products_html = "".join(
        f'<div class="mini">{f"<img src={chr(34)}{escape(x.image_url, quote=True)}{chr(34)} alt={chr(34)}{escape(x.name, quote=True)}{chr(34)}>" if x.image_url else ""}<b>{escape(x.name)}</b><span>{escape(str(x.price))} {escape(x.currency)}</span></div>'
        for x in others
    )
    body = f'''{f'<img class="hero" src="{escape(image, quote=True)}" alt="{escape(p.name, quote=True)}">' if image else ''}<div class="pad"><span class="eyebrow">{escape(p.category)}</span><h1>{escape(p.name)}</h1><div class="meta"><span class="chip">{escape(str(p.price))} {escape(p.currency)}</span><span class="chip">Stock : {p.stock_qty}</span><span class="chip">Min {p.min_order_qty} • Max {p.max_order_qty}</span></div><p>{escape(p.description or 'Produit proposé sur M’MEDPREN.')}</p><div class="shop"><b>🏪 {escape(store.name)}</b><p>{escape(store.description or '')}</p><small>{escape(store.seller.city if store.seller else '')}</small><div class="grid">{products_html}</div></div></div>'''
    return _page(title=f"{p.name} — {store.name}", description=desc, canonical=str(request.url), app_url=_front_url("product", p.id), image=image, body_html=body)


@router.get("/opportunity/{opportunity_id}", response_class=HTMLResponse)
def share_opportunity(opportunity_id: str, request: Request, db: Session = Depends(get_db)):
    o = db.get(WorkOpportunity, opportunity_id)
    if not o or not o.is_active:
        raise HTTPException(404, "Opportunité introuvable")
    desc = _plain(o.description)
    body = f'''{f'<img class="hero" src="{escape(o.image_url, quote=True)}" alt="{escape(o.title, quote=True)}">' if o.image_url else ''}<div class="pad"><span class="eyebrow">Work4Future • {escape(o.kind)}</span><h1>{escape(o.title)}</h1><h3>{escape(o.organization)}</h3><div class="meta">{f'<span class="chip">📍 {escape(o.location)}</span>' if o.location else ''}{f'<span class="chip">{escape(o.work_mode)}</span>' if o.work_mode else ''}{f'<span class="chip">{escape(o.contract_type)}</span>' if o.contract_type else ''}{f'<span class="chip">{escape(o.salary_text)}</span>' if o.salary_text else ''}</div><p>{escape(o.description)}</p>{f'<div class="shop"><b>Profil / exigences</b><p>{escape(o.requirements)}</p></div>' if o.requirements else ''}</div>'''
    return _page(title=f"{o.title} — {o.organization}", description=desc, canonical=str(request.url), app_url=_front_url("opportunity", o.id), image=o.image_url, body_html=body)


@router.get("/training/{training_id}", response_class=HTMLResponse)
def share_training(training_id: str, request: Request, db: Session = Depends(get_db)):
    t = db.get(WorkTraining, training_id)
    if not t or not t.is_active:
        raise HTTPException(404, "Formation introuvable")
    desc = _plain(t.description)
    body = f'''{f'<img class="hero" src="{escape(t.image_url, quote=True)}" alt="{escape(t.title, quote=True)}">' if t.image_url else ''}<div class="pad"><span class="eyebrow">Work4Future Learn</span><h1>{escape(t.title)}</h1><h3>{escape(t.provider)}</h3><div class="meta">{f'<span class="chip">📍 {escape(t.location)}</span>' if t.location else ''}{f'<span class="chip">{escape(t.mode)}</span>' if t.mode else ''}{f'<span class="chip">{escape(t.level)}</span>' if t.level else ''}{f'<span class="chip">⏱ {escape(t.duration_text)}</span>' if t.duration_text else ''}{f'<span class="chip">{escape(t.fee_text)}</span>' if t.fee_text else ''}</div><p>{escape(t.description)}</p>{f'<div class="shop"><b>Prérequis</b><p>{escape(t.prerequisites)}</p></div>' if t.prerequisites else ''}</div>'''
    return _page(title=f"{t.title} — {t.provider}", description=desc, canonical=str(request.url), app_url=_front_url("training", t.id), image=t.image_url, body_html=body)


@router.get("/profile/{user_id}", response_class=HTMLResponse)
def share_profile(user_id: str, request: Request, db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    p = db.query(WorkProfile).filter(WorkProfile.user_id == user_id).first()
    if not u or not u.is_active or not p or not (p.headline or p.skills or p.bio):
        raise HTTPException(404, "Profil professionnel introuvable")
    title = f"{u.full_name or 'Profil Work4Future'} — {p.headline or 'Compétences'}"
    desc = _plain(p.bio or p.skills or p.headline)
    body = f'''{f'<img class="hero" src="{escape(u.profile_image_url, quote=True)}" alt="{escape(u.full_name or "Profil", quote=True)}">' if u.profile_image_url else ''}<div class="pad"><span class="eyebrow">Work4Future • Compétences</span><h1>{escape(u.full_name or 'Profil professionnel')}</h1><h3>{escape(p.headline or '')}</h3>{f'<div class="shop"><b>Compétences</b><p>{escape(p.skills)}</p></div>' if p.skills else ''}{f'<p>{escape(p.bio)}</p>' if p.bio else ''}{f'<div class="meta"><span class="chip">📍 {escape(p.city)}</span></div>' if p.city else ''}</div>'''
    return _page(title=title, description=desc, canonical=str(request.url), app_url=_front_url("profile", user_id), image=u.profile_image_url, body_html=body)
