from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import (
    User,
    UserRole,
    Role,
    SellerProfile,
    SellerStatus,
    Delivery,
    Product,
    Order,
    Payment,
)
from app.schemas import AdminSellerDecision, AdminProductDecision, DeliveryAssign, SellerUpdate
from app.deps import require_role, role_names
from app.services.image_storage import delete_image

router = APIRouter(prefix="/admin", tags=["admin"])


def _seller_out(s: SellerProfile):
    return {
        "id": s.id,
        "user_id": s.user_id,
        "business_name": s.business_name,
        "legal_name": s.legal_name,
        "city": s.city,
        "status": s.status,
        "store_id": s.store.id if s.store else None,
        "store_name": s.store.name if s.store else None,
        "store_description": s.store.description if s.store else None,
        "store_active": s.store.is_active if s.store else False,
        "products_count": len(s.store.products) if s.store else 0,
    }


def _product_out(p: Product):
    seller = p.store.seller if p.store else None
    effective_active = bool(
        p.is_active
        and p.store
        and p.store.is_active
        and seller
        and seller.status == SellerStatus.APPROVED
    )
    return {
        "id": p.id,
        "name": p.name,
        "category": p.category,
        "price": p.price,
        "currency": p.currency,
        "stock_qty": p.stock_qty,
        "image_url": p.image_url,
        "is_active": p.is_active,
        "effective_active": effective_active,
        "effective_status": "active" if effective_active else (
            "seller_suspended" if seller and seller.status == SellerStatus.SUSPENDED else "suspended"
        ),
        "store_id": p.store_id,
        "store_name": p.store.name if p.store else None,
        "seller_id": seller.id if seller else None,
        "seller_name": seller.business_name if seller else None,
        "seller_status": seller.status if seller else None,
    }


def _apply_seller_update(s: SellerProfile, body: SellerUpdate):
    if not s.store:
        raise HTTPException(404, "Store not found")
    data = body.model_dump(exclude_unset=True)
    for field in ("legal_name", "business_name", "city", "store_name"):
        if field in data and data[field] is not None:
            value = data[field].strip()
            if len(value) < 2:
                raise HTTPException(422, f"{field} is too short")
            data[field] = value
    if "legal_name" in data and data["legal_name"] is not None:
        s.legal_name = data["legal_name"]
    if "business_name" in data and data["business_name"] is not None:
        s.business_name = data["business_name"]
    if "city" in data and data["city"] is not None:
        s.city = data["city"]
    if "store_name" in data and data["store_name"] is not None:
        s.store.name = data["store_name"]
    if "store_description" in data:
        desc = data["store_description"]
        s.store.description = desc.strip() if isinstance(desc, str) and desc.strip() else None



@router.get("/dashboard")
def dashboard(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return {
        "users": db.query(User).count(),
        "sellers": db.query(SellerProfile).count(),
        "products": db.query(Product).count(),
        "orders": db.query(Order).count(),
        "payments": db.query(Payment).count(),
        "pending_sellers": db.query(SellerProfile).filter(SellerProfile.status == SellerStatus.PENDING).count(),
        "suspended_sellers": db.query(SellerProfile).filter(SellerProfile.status == SellerStatus.SUSPENDED).count(),
        "suspended_products": db.query(Product).filter(Product.is_active == False).count(),
    }


@router.get("/sellers")
def sellers(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [_seller_out(s) for s in db.query(SellerProfile).order_by(SellerProfile.created_at.desc()).all()]


@router.patch("/sellers/{seller_id}/profile")
def update_seller_profile(
    seller_id: str,
    body: SellerUpdate,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    s = db.get(SellerProfile, seller_id)
    if not s:
        raise HTTPException(404, "Seller not found")
    _apply_seller_update(s, body)
    db.commit()
    db.refresh(s)
    return {"ok": True, "seller": _seller_out(s)}


@router.patch("/sellers/{seller_id}")
def seller_decision(
    seller_id: str,
    body: AdminSellerDecision,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    s = db.get(SellerProfile, seller_id)
    if not s:
        raise HTTPException(404, "Seller not found")
    s.status = SellerStatus(body.status)
    if s.store:
        # Store-level availability suspends every product without destroying each
        # product's own active/inactive setting. Re-approval restores only the
        # products that had not been individually suspended.
        s.store.is_active = s.status == SellerStatus.APPROVED
    db.commit()
    db.refresh(s)
    return {
        "ok": True,
        "status": s.status,
        "store_active": s.store.is_active if s.store else False,
        "products_effectively_suspended": len(s.store.products) if s.store and s.status == SellerStatus.SUSPENDED else 0,
    }


@router.delete("/sellers/{seller_id}")
async def delete_seller(
    seller_id: str,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    s = db.get(SellerProfile, seller_id)
    if not s:
        raise HTTPException(404, "Seller not found")

    public_ids = [p.image_public_id for p in (s.store.products if s.store else []) if p.image_public_id]
    seller_user_id = s.user_id

    # Delete only the seller identity/store/catalogue. The underlying user stays
    # in place so customer orders and the account itself are preserved.
    role = (
        db.query(UserRole)
        .filter(UserRole.user_id == seller_user_id, UserRole.role == Role.SELLER)
        .first()
    )
    if role:
        db.delete(role)
    db.delete(s)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(409, "Seller cannot be deleted until database migration 0003 is applied")

    for public_id in public_ids:
        await delete_image(public_id)
    return {"ok": True, "deleted_seller_id": seller_id, "user_preserved": True}


@router.get("/products")
def products(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [_product_out(p) for p in db.query(Product).order_by(Product.created_at.desc()).all()]


@router.patch("/products/{product_id}")
def product_decision(
    product_id: str,
    body: AdminProductDecision,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")
    p.is_active = body.status == "active"
    db.commit()
    db.refresh(p)
    return {"ok": True, "product": _product_out(p)}


@router.delete("/products/{product_id}")
async def delete_product(
    product_id: str,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")
    public_id = p.image_public_id
    db.delete(p)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(409, "Product cannot be deleted until database migration 0003 is applied")
    await delete_image(public_id)
    return {"ok": True, "deleted_product_id": product_id}


@router.post("/users/{user_id}/roles/{role}")
def add_role(
    user_id: str,
    role: Role,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    if role.value not in role_names(u):
        db.add(UserRole(user_id=u.id, role=role))
        db.commit()
    return {"ok": True}


@router.patch("/deliveries/{delivery_id}/assign")
def assign(
    delivery_id: str,
    body: DeliveryAssign,
    admin: User = Depends(require_role(Role.ADMIN)),
    db: Session = Depends(get_db),
):
    d = db.get(Delivery, delivery_id)
    courier = db.get(User, body.courier_id)
    if not d:
        raise HTTPException(404, "Delivery not found")
    if not courier or Role.COURIER.value not in role_names(courier):
        raise HTTPException(422, "Courier role required")
    d.courier_id = courier.id
    from app.models import DeliveryStatus
    d.status = DeliveryStatus.ASSIGNED
    db.commit()
    return {"ok": True}
