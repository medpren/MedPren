from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, UserRole, Role, SellerProfile, SellerStatus, Delivery, Product, Order, Payment
from app.schemas import AdminSellerDecision, DeliveryAssign
from app.deps import require_role, role_names

router=APIRouter(prefix="/admin",tags=["admin"])
@router.get("/dashboard")
def dashboard(admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    return {"users":db.query(User).count(),"sellers":db.query(SellerProfile).count(),"products":db.query(Product).count(),"orders":db.query(Order).count(),"payments":db.query(Payment).count(),"pending_sellers":db.query(SellerProfile).filter(SellerProfile.status==SellerStatus.PENDING).count()}
@router.get("/sellers")
def sellers(admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    return [{"id":s.id,"user_id":s.user_id,"business_name":s.business_name,"legal_name":s.legal_name,"city":s.city,"status":s.status,"store_id":s.store.id if s.store else None} for s in db.query(SellerProfile).order_by(SellerProfile.created_at.desc()).all()]
@router.patch("/sellers/{seller_id}")
def seller_decision(seller_id:str,body:AdminSellerDecision,admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    s=db.get(SellerProfile,seller_id)
    if not s: raise HTTPException(404,"Seller not found")
    s.status=SellerStatus(body.status); db.commit(); return {"ok":True,"status":s.status}
@router.post("/users/{user_id}/roles/{role}")
def add_role(user_id:str,role:Role,admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    u=db.get(User,user_id)
    if not u: raise HTTPException(404,"User not found")
    if role.value not in role_names(u): db.add(UserRole(user_id=u.id,role=role)); db.commit()
    return {"ok":True}
@router.patch("/deliveries/{delivery_id}/assign")
def assign(delivery_id:str,body:DeliveryAssign,admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    d=db.get(Delivery,delivery_id); courier=db.get(User,body.courier_id)
    if not d: raise HTTPException(404,"Delivery not found")
    if not courier or Role.COURIER.value not in role_names(courier): raise HTTPException(422,"Courier role required")
    d.courier_id=courier.id; from app.models import DeliveryStatus; d.status=DeliveryStatus.ASSIGNED; db.commit(); return {"ok":True}
