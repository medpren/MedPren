from datetime import datetime, timezone
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.models import (User, UserIdentity, UserRole, Role, SellerProfile, SellerStatus, Delivery, DeliveryStatus,
                        Product, Order, OrderStatus, Payment, PaymentStatus, Conversation, ChatMessage, OTPChallenge, Notification, PushSubscription)
from app.schemas import (AdminSellerDecision, AdminProductDecision, AdminOrderCancel,
                         DeliveryAssign, SellerUpdate, ProductUpdate)
from app.deps import require_role, role_names
from app.services.image_storage import (ImageStorageError, ImageStorageNotConfigured, delete_image,
                                        detect_image_mime, resolve_image_mime, safe_upload_filename, upload_image)
from app.services.notifications import add_notification, notify_admins, notify_many
from app.utils import normalize_phone

router = APIRouter(prefix="/admin", tags=["admin"])

def _seller_out(s: SellerProfile):
    return {
        "id": s.id, "user_id": s.user_id, "business_name": s.business_name, "legal_name": s.legal_name,
        "city": s.city, "status": s.status, "store_id": s.store.id if s.store else None,
        "store_name": s.store.name if s.store else None, "store_description": s.store.description if s.store else None,
        "store_logo_url": s.store.logo_url if s.store else None,
        "store_active": s.store.is_active if s.store else False, "products_count": len(s.store.products) if s.store else 0,
    }

def _product_out(p: Product):
    seller = p.store.seller if p.store else None
    effective_active = bool(p.is_active and p.moderation_status == "approved" and p.store and p.store.is_active and seller and seller.status == SellerStatus.APPROVED)
    return {
        "id": p.id, "name": p.name, "description": p.description, "category": p.category, "price": p.price,
        "currency": p.currency, "stock_qty": p.stock_qty, "min_order_qty": p.min_order_qty, "max_order_qty": p.max_order_qty,
        "effective_max_order_qty": min(p.max_order_qty,p.stock_qty) if p.stock_qty>0 else 0,
        "image_url": p.image_url, "is_active": p.is_active,
        "moderation_status": p.moderation_status, "effective_active": effective_active,
        "effective_status": "active" if effective_active else ("pending_approval" if p.moderation_status == "pending" else "seller_suspended" if seller and seller.status == SellerStatus.SUSPENDED else "suspended"),
        "store_id": p.store_id, "store_name": p.store.name if p.store else None,
        "seller_id": seller.id if seller else None, "seller_name": seller.business_name if seller else None,
        "seller_status": seller.status if seller else None,
    }

def _apply_seller_update(s: SellerProfile, body: SellerUpdate):
    if not s.store: raise HTTPException(404, "Store not found")
    data = body.model_dump(exclude_unset=True)
    for field in ("legal_name", "business_name", "city", "store_name"):
        if field in data and data[field] is not None:
            value = data[field].strip()
            if len(value) < 2: raise HTTPException(422, f"{field} is too short")
            data[field] = value
    if data.get("legal_name") is not None: s.legal_name = data["legal_name"]
    if data.get("business_name") is not None: s.business_name = data["business_name"]
    if data.get("city") is not None: s.city = data["city"]
    if data.get("store_name") is not None: s.store.name = data["store_name"]
    if "store_description" in data:
        desc = data["store_description"]; s.store.description = desc.strip() if isinstance(desc, str) and desc.strip() else None

def _user_private_out(u: User, db: Session):
    roles=sorted(role_names(u))
    seller=db.query(SellerProfile).filter(SellerProfile.user_id==u.id).first()
    orders=db.query(Order).filter(Order.customer_id==u.id).order_by(Order.created_at.desc()).all()
    active_orders=[o for o in orders if o.status!=OrderStatus.CANCELLED]
    totals_by_currency={}
    for o in active_orders:
        code=(o.currency or "USD").upper()
        totals_by_currency[code]=round(totals_by_currency.get(code,0.0)+float(o.total or 0),2)
    customer_conversations=db.query(Conversation).filter(Conversation.customer_id==u.id).count()
    seller_conversations=db.query(Conversation).filter(Conversation.seller_id==seller.id).count() if seller else 0
    messages_sent=db.query(ChatMessage).filter(ChatMessage.sender_id==u.id).count()
    seller_info=None
    if seller:
        seller_info={
            "id":seller.id,"business_name":seller.business_name,"legal_name":seller.legal_name,"city":seller.city,
            "status":seller.status,"created_at":seller.created_at,
            "store_id":seller.store.id if seller.store else None,"store_name":seller.store.name if seller.store else None,
            "store_active":seller.store.is_active if seller.store else False,
            "products_count":len(seller.store.products) if seller.store else 0,
        }
    identities=db.query(UserIdentity).filter(UserIdentity.user_id==u.id).order_by(UserIdentity.kind,UserIdentity.created_at).all()
    identity_rows=[{"kind":x.kind,"value":x.value if x.kind in ("phone","email") else x.kind,"verified":x.is_verified,"primary":x.is_primary} for x in identities]
    account_type=("admin" if Role.ADMIN.value in roles else "seller" if seller else "client")
    if seller and Role.CUSTOMER.value in roles: account_type="seller_client"
    return {
        "id":u.id,"full_name":u.full_name,"login_phone":u.phone,"whatsapp_phone":u.whatsapp_phone,
        "email":u.email,"profile_kind":u.profile_kind,"profile_image_url":u.profile_image_url,
        "roles":roles,"account_type":account_type,"is_active":u.is_active,"created_at":u.created_at,
        "identities":identity_rows,"password_enabled":bool(u.password_hash),
        "seller":seller_info,
        "orders_count":len(orders),"active_orders_count":len(active_orders),
        "cancelled_orders_count":len(orders)-len(active_orders),
        "total_order_value_by_currency":totals_by_currency,
        "last_order_at":orders[0].created_at if orders else None,
        "customer_conversations_count":customer_conversations,
        "seller_conversations_count":seller_conversations,
        "messages_sent_count":messages_sent,
    }

def _order_out(o: Order, db: Session):
    customer=db.get(User,o.customer_id)
    seller_names=set(); seller_user_ids=set(); items=[]
    for i in o.items:
        p=db.get(Product,i.product_id) if i.product_id else None
        store_name=p.store.name if p and p.store else None
        seller=p.store.seller if p and p.store else None
        if store_name: seller_names.add(store_name)
        if seller: seller_user_ids.add(seller.user_id)
        items.append({"product_id":i.product_id,"product_name":i.product_name,"unit_price":i.unit_price,
                      "quantity":i.quantity,"line_total":i.line_total,"store_name":store_name})
    success_payments=[p for p in o.payments if p.status==PaymentStatus.SUCCESS]
    real_success=[p for p in success_payments if p.provider!="sandbox"]
    return {"id":o.id,"status":o.status,"currency":o.currency,"subtotal":o.subtotal,"delivery_fee":o.delivery_fee,
            "total":o.total,"delivery_name":o.delivery_name,"delivery_phone":o.delivery_phone,"delivery_address":o.delivery_address,
            "created_at":o.created_at,"cancelled_at":o.cancelled_at,"cancellation_reason":o.cancellation_reason,
            "customer":{"id":customer.id,"name":customer.full_name,"phone":customer.phone,"whatsapp_phone":customer.whatsapp_phone,"email":customer.email} if customer else None,
            "stores":sorted(seller_names),"seller_user_ids":list(seller_user_ids),"items":items,
            "payments":[{"id":p.id,"provider":p.provider,"status":p.status,"amount":p.amount,"currency":p.currency} for p in o.payments],
            "refund_required":bool(real_success)}

@router.get("/dashboard")
def dashboard(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return {
        "users": db.query(User).count(), "sellers": db.query(SellerProfile).count(), "products": db.query(Product).count(),
        "orders": db.query(Order).count(), "payments": db.query(Payment).count(),
        "pending_sellers": db.query(SellerProfile).filter(SellerProfile.status == SellerStatus.PENDING).count(),
        "suspended_sellers": db.query(SellerProfile).filter(SellerProfile.status == SellerStatus.SUSPENDED).count(),
        "pending_products": db.query(Product).filter(Product.moderation_status == "pending").count(),
        "suspended_products": db.query(Product).filter(Product.moderation_status == "suspended").count(),
        "cancelled_orders": db.query(Order).filter(Order.status == OrderStatus.CANCELLED).count(),
    }

@router.get("/users")
def users(admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    return [_user_private_out(u,db) for u in db.query(User).order_by(User.created_at.desc()).all()]

@router.delete("/users/{user_id}")
async def delete_user_account(user_id: str, admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    target=db.get(User,user_id)
    if not target: raise HTTPException(404,"Utilisateur introuvable")
    if target.id==admin.id: raise HTTPException(403,"Vous ne pouvez pas supprimer le compte administrateur actuellement connecté")
    if settings.owner_phone:
        try:
            if target.phone==normalize_phone(settings.owner_phone):
                raise HTTPException(403,"Le compte propriétaire principal M’MEDPREN est protégé")
        except ValueError:
            pass
    # Commercial history is intentionally preserved. Test/mistaken accounts without orders can be erased.
    order_count=db.query(Order).filter(Order.customer_id==target.id).count()
    courier_count=db.query(Delivery).filter(Delivery.courier_id==target.id).count()
    if order_count or courier_count:
        raise HTTPException(409,f"Ce compte possède un historique commercial ({order_count} commande(s), {courier_count} livraison(s)). Il ne peut pas être supprimé définitivement sans détruire la traçabilité.")

    public_ids=[]
    if target.profile_image_public_id: public_ids.append(target.profile_image_public_id)
    seller=db.query(SellerProfile).filter(SellerProfile.user_id==target.id).first()
    if seller:
        if seller.store:
            if seller.store.logo_public_id: public_ids.append(seller.store.logo_public_id)
            public_ids.extend([p.image_public_id for p in seller.store.products if p.image_public_id])
        db.delete(seller)
        db.flush()

    # Preserve readable chat/order audit trails while removing the account identity.
    db.query(Conversation).filter(Conversation.customer_id==target.id).update({Conversation.customer_id:None},synchronize_session=False)
    db.query(Conversation).filter(Conversation.created_by_id==target.id).update({Conversation.created_by_id:None},synchronize_session=False)
    db.query(ChatMessage).filter(ChatMessage.sender_id==target.id).update({ChatMessage.sender_id:None},synchronize_session=False)
    db.query(Order).filter(Order.cancelled_by_id==target.id).update({Order.cancelled_by_id:None},synchronize_session=False)
    db.query(Notification).filter(Notification.user_id==target.id).delete(synchronize_session=False)
    db.query(PushSubscription).filter(PushSubscription.user_id==target.id).delete(synchronize_session=False)
    db.query(OTPChallenge).filter(OTPChallenge.phone==target.phone).delete(synchronize_session=False)
    db.delete(target)
    try:
        db.commit()
    except Exception as exc:
        db.rollback(); raise HTTPException(409,"Suppression impossible : ce compte est encore lié à des données protégées") from exc
    for public_id in public_ids:
        await delete_image(public_id)
    return {"ok":True,"deleted_user_id":user_id,"deleted_phone":target.phone,"commercial_history_preserved":True}

@router.get("/sellers")
def sellers(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [_seller_out(s) for s in db.query(SellerProfile).order_by(SellerProfile.created_at.desc()).all()]

@router.patch("/sellers/{seller_id}/profile")
def update_seller_profile(seller_id: str, body: SellerUpdate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    s = db.get(SellerProfile, seller_id)
    if not s: raise HTTPException(404, "Seller not found")
    _apply_seller_update(s, body); db.commit(); db.refresh(s); return {"ok": True, "seller": _seller_out(s)}

@router.patch("/sellers/{seller_id}")
def seller_decision(seller_id: str, body: AdminSellerDecision, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    s = db.get(SellerProfile, seller_id)
    if not s: raise HTTPException(404, "Seller not found")
    s.status = SellerStatus(body.status)
    if s.store: s.store.is_active = s.status == SellerStatus.APPROVED
    add_notification(db,s.user_id,"seller_status","Statut de votre boutique",f"Votre boutique « {s.store.name if s.store else s.business_name} » est maintenant {s.status.value}.","seller",s.id)
    db.commit(); db.refresh(s)
    return {"ok": True, "status": s.status, "store_active": s.store.is_active if s.store else False,
            "products_effectively_suspended": len(s.store.products) if s.store and s.status == SellerStatus.SUSPENDED else 0}

@router.delete("/sellers/{seller_id}")
async def delete_seller(seller_id: str, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    s = db.get(SellerProfile, seller_id)
    if not s: raise HTTPException(404, "Seller not found")
    public_ids = [p.image_public_id for p in (s.store.products if s.store else []) if p.image_public_id]
    if s.store and s.store.logo_public_id: public_ids.append(s.store.logo_public_id)
    seller_user_id = s.user_id
    role = db.query(UserRole).filter(UserRole.user_id == seller_user_id, UserRole.role == Role.SELLER).first()
    if role: db.delete(role)
    db.delete(s)
    try: db.commit()
    except Exception:
        db.rollback(); raise HTTPException(409, "Seller cannot be deleted until the latest database migration is applied")
    for public_id in public_ids: await delete_image(public_id)
    return {"ok": True, "deleted_seller_id": seller_id, "user_preserved": True}

@router.get("/products")
def products(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [_product_out(p) for p in db.query(Product).order_by(Product.created_at.desc()).all()]

@router.patch("/products/{product_id}/profile")
def admin_update_product(product_id: str, body: ProductUpdate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p: raise HTTPException(404, "Product not found")
    data = body.model_dump(exclude_unset=True)
    proposed_min=data.get("min_order_qty",p.min_order_qty); proposed_max=data.get("max_order_qty",p.max_order_qty)
    if proposed_max < proposed_min: raise HTTPException(422,"Maximum order quantity must be >= minimum order quantity")
    for k, v in data.items():
        if k == "currency" and isinstance(v, str): v = v.upper()
        setattr(p, k, v)
    db.commit(); db.refresh(p); return {"ok": True, "product": _product_out(p)}

@router.post("/products/{product_id}/image")
async def admin_upload_product_image(product_id:str,file:UploadFile=File(...),admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    p=db.get(Product,product_id)
    if not p: raise HTTPException(404,"Product not found")
    data=await file.read(settings.image_max_bytes+1); await file.close()
    if not data: raise HTTPException(422,"Image file is empty")
    if len(data)>settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,"Image too large")
    mime=resolve_image_mime(data,file.content_type,file.filename)
    if not mime: raise HTTPException(415,"Le fichier sélectionné ne semble pas être une image compatible")
    old=p.image_public_id
    try: stored=await upload_image(data,safe_upload_filename(file.filename,mime,"produit"),mime)
    except ImageStorageNotConfigured as exc: raise HTTPException(503,str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502,str(exc)) from exc
    p.image_url=stored["url"]; p.image_public_id=stored["public_id"]
    db.commit(); db.refresh(p)
    if old and old!=p.image_public_id: await delete_image(old)
    return {"ok":True,"product":_product_out(p)}

@router.delete("/products/{product_id}/image")
async def admin_delete_product_image(product_id:str,admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    p=db.get(Product,product_id)
    if not p: raise HTTPException(404,"Product not found")
    old=p.image_public_id; p.image_url=None; p.image_public_id=None; db.commit(); await delete_image(old)
    return {"ok":True,"product":_product_out(p)}

@router.patch("/products/{product_id}")
def product_decision(product_id: str, body: AdminProductDecision, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p: raise HTTPException(404, "Product not found")
    p.moderation_status = body.status; p.is_active = body.status != "suspended"
    if p.store and p.store.seller:
        label={"approved":"approuvé et publié","suspended":"suspendu","pending":"en attente de validation"}.get(body.status,body.status)
        add_notification(db,p.store.seller.user_id,"product_status","Statut d’un produit",f"Votre produit « {p.name} » est {label}.","product",p.id)
    db.commit(); db.refresh(p); return {"ok": True, "product": _product_out(p)}

@router.delete("/products/{product_id}")
async def delete_product(product_id: str, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p: raise HTTPException(404, "Product not found")
    public_id = p.image_public_id; db.delete(p)
    try: db.commit()
    except Exception:
        db.rollback(); raise HTTPException(409, "Product cannot be deleted until the latest database migration is applied")
    await delete_image(public_id); return {"ok": True, "deleted_product_id": product_id}

@router.get("/orders")
def admin_orders(admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    return [_order_out(o,db) for o in db.query(Order).order_by(Order.created_at.desc()).limit(500).all()]

@router.post("/orders/{order_id}/cancel")
def cancel_order(order_id:str,body:AdminOrderCancel,admin:User=Depends(require_role(Role.ADMIN)),db:Session=Depends(get_db)):
    o=db.get(Order,order_id)
    if not o: raise HTTPException(404,"Order not found")
    if o.status==OrderStatus.CANCELLED: return {"ok":True,"order":_order_out(o,db),"already_cancelled":True}
    if o.status==OrderStatus.DELIVERED: raise HTTPException(409,"A delivered order cannot be cancelled")
    seller_users=set()
    for item in o.items:
        p=db.get(Product,item.product_id) if item.product_id else None
        if p:
            p.stock_qty += item.quantity
            if p.store and p.store.seller: seller_users.add(p.store.seller.user_id)
    o.status=OrderStatus.CANCELLED; o.cancelled_at=datetime.now(timezone.utc); o.cancelled_by_id=admin.id; o.cancellation_reason=body.reason.strip()
    if o.delivery: o.delivery.status=DeliveryStatus.FAILED
    refund_required=False
    for pay in o.payments:
        if pay.status==PaymentStatus.SUCCESS:
            if pay.provider=="sandbox": pay.status=PaymentStatus.REFUNDED
            else: refund_required=True
    short=o.id[:8]
    add_notification(db,o.customer_id,"order_cancelled","Commande annulée",f"La commande {short} a été annulée par l’administration. Motif : {o.cancellation_reason}","order",o.id)
    notify_many(db,seller_users,"order_cancelled","Commande annulée",f"La commande {short} a été annulée par l’administration. Le stock a été restauré.","order",o.id)
    notify_admins(db,"order_cancelled","Commande annulée par un administrateur",f"Commande {short} • {o.cancellation_reason}"+(" • remboursement externe à traiter" if refund_required else ""),"order",o.id,exclude_user_id=admin.id)
    db.commit(); db.refresh(o)
    return {"ok":True,"order":_order_out(o,db),"refund_required":refund_required}

@router.post("/users/{user_id}/roles/{role}")
def add_role(user_id: str, role: Role, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    u = db.get(User, user_id)
    if not u: raise HTTPException(404, "User not found")
    if role.value not in role_names(u): db.add(UserRole(user_id=u.id, role=role)); db.commit()
    return {"ok": True}

@router.patch("/deliveries/{delivery_id}/assign")
def assign(delivery_id: str, body: DeliveryAssign, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    d = db.get(Delivery, delivery_id); courier = db.get(User, body.courier_id)
    if not d: raise HTTPException(404, "Delivery not found")
    if not courier or Role.COURIER.value not in role_names(courier): raise HTTPException(422, "Courier role required")
    d.courier_id = courier.id; d.status = DeliveryStatus.ASSIGNED; db.commit(); return {"ok": True}
