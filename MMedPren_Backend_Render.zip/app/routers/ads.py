from __future__ import annotations
import re
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.deps import require_role
from app.models import Advertisement, Role, User
from app.schemas import AdvertisementCreate, AdvertisementUpdate
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, detect_image_mime, upload_image

router = APIRouter(tags=["advertisements"])

def out(a: Advertisement):
    return {"id":a.id,"title":a.title,"body":a.body,"image_url":a.image_url,"link_url":a.link_url,
            "is_active":a.is_active,"sort_order":a.sort_order,"created_at":a.created_at}

def _safe_filename(filename: str|None, mime: str):
    ext={"image/jpeg":".jpg","image/png":".png","image/webp":".webp"}[mime]
    stem=re.sub(r"[^a-zA-Z0-9_-]+","-",(filename or "advert").rsplit(".",1)[0]).strip("-")
    return f"{stem or 'advert'}{ext}"

@router.get("/ads")
def public_ads(db: Session = Depends(get_db)):
    return [out(a) for a in db.query(Advertisement).filter(Advertisement.is_active == True).order_by(Advertisement.sort_order.asc(),Advertisement.created_at.desc()).all()]

@router.get("/admin/ads")
def admin_ads(admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    return [out(a) for a in db.query(Advertisement).order_by(Advertisement.sort_order.asc(),Advertisement.created_at.desc()).all()]

@router.post("/admin/ads")
def create_ad(body: AdvertisementCreate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    a=Advertisement(**body.model_dump()); db.add(a); db.commit(); db.refresh(a); return out(a)

@router.patch("/admin/ads/{ad_id}")
def update_ad(ad_id: str, body: AdvertisementUpdate, admin: User = Depends(require_role(Role.ADMIN)), db: Session = Depends(get_db)):
    a=db.get(Advertisement,ad_id)
    if not a: raise HTTPException(404,"Advertisement not found")
    for k,v in body.model_dump(exclude_unset=True).items(): setattr(a,k,v)
    db.commit(); db.refresh(a); return out(a)

@router.post("/admin/ads/{ad_id}/image")
async def upload_ad_image(ad_id: str, file: UploadFile=File(...), admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    a=db.get(Advertisement,ad_id)
    if not a: raise HTTPException(404,"Advertisement not found")
    data=await file.read(settings.image_max_bytes+1); await file.close()
    if not data: raise HTTPException(422,"Image file is empty")
    if len(data)>settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,"Image too large")
    mime=detect_image_mime(data)
    if mime not in {"image/jpeg","image/png","image/webp"}: raise HTTPException(415,"Only JPEG, PNG and WebP images are accepted")
    old=a.image_public_id
    try: stored=await upload_image(data,_safe_filename(file.filename,mime),mime,folder="mmedpren/ads")
    except ImageStorageNotConfigured as exc: raise HTTPException(503,str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502,str(exc)) from exc
    a.image_url=stored["url"]; a.image_public_id=stored["public_id"]; db.commit(); db.refresh(a)
    if old and old!=a.image_public_id: await delete_image(old)
    return out(a)


@router.delete("/admin/ads/{ad_id}/image")
async def delete_ad_image(ad_id: str, admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    a=db.get(Advertisement,ad_id)
    if not a: raise HTTPException(404,"Advertisement not found")
    public_id=a.image_public_id
    a.image_url=None; a.image_public_id=None
    db.commit(); db.refresh(a)
    await delete_image(public_id)
    return {"ok":True,"advertisement":out(a)}

@router.delete("/admin/ads/{ad_id}")
async def delete_ad(ad_id: str, admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    a=db.get(Advertisement,ad_id)
    if not a: raise HTTPException(404,"Advertisement not found")
    public_id=a.image_public_id; db.delete(a); db.commit(); await delete_image(public_id); return {"ok":True}
