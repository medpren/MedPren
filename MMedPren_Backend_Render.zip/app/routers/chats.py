from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import current_user, require_role, role_names
from app.models import ChatMessage, Conversation, Role, SellerProfile, User
from app.schemas import ChatMessageCreate, ChatStart, SupportStart
from app.services.notifications import add_notification, notify_admins

router=APIRouter(tags=["chats"])

def seller_for_user(db,user): return db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()

def convo_out(c: Conversation, db: Session):
    last=db.query(ChatMessage).filter(ChatMessage.conversation_id==c.id).order_by(ChatMessage.created_at.desc()).first()
    return {"id":c.id,"kind":c.kind,"seller_id":c.seller_id,"seller_name":c.seller_name,"customer_id":c.customer_id,
            "customer_name":c.customer_name,"subject":c.subject,"updated_at":c.updated_at,
            "last_message": last.body if last else None,"last_message_at":last.created_at if last else None}

def can_access(c: Conversation, user: User, db: Session):
    if Role.ADMIN.value in role_names(user): return True
    s=seller_for_user(db,user)
    if s and c.seller_id==s.id: return True
    return c.customer_id==user.id

def notify_conversation_started(db: Session, c: Conversation, actor: User):
    if c.kind=="customer_seller" and c.seller_id:
        s=db.get(SellerProfile,c.seller_id)
        if s:
            add_notification(db,s.user_id,"chat_started","Nouveau chat client",f"{c.customer_name or 'Un client'} souhaite discuter avec votre boutique. Sujet : {c.subject or 'Produit / commande'}.","conversation",c.id)
        notify_admins(db,"chat_started","Nouveau chat client-vendeur",f"{c.customer_name or 'Client'} ↔ {c.seller_name} • {c.subject or 'Nouvelle conversation'}.","conversation",c.id,exclude_user_id=actor.id)
    elif c.kind=="support":
        notify_admins(db,"support_started","Nouveau recours au service client",f"{c.customer_name or 'Utilisateur'} demande l’aide du service client humain. Sujet : {c.subject or 'Assistance'}.","conversation",c.id,exclude_user_id=actor.id)

@router.post("/chats/customer-seller")
def start_customer_seller(body: ChatStart, user: User=Depends(current_user), db: Session=Depends(get_db)):
    s=db.get(SellerProfile,body.seller_id)
    if not s or not s.store: raise HTTPException(404,"Seller not found")
    c=db.query(Conversation).filter(Conversation.kind=="customer_seller",Conversation.seller_id==s.id,Conversation.customer_id==user.id).first()
    created=False
    if not c:
        c=Conversation(kind="customer_seller",seller_id=s.id,seller_name=s.business_name,customer_id=user.id,
                       customer_name=user.full_name or user.phone,subject=body.subject,created_by_id=user.id)
        db.add(c); db.flush(); created=True
    elif body.subject and not c.subject:
        c.subject=body.subject
    if created: notify_conversation_started(db,c,user)
    db.commit(); db.refresh(c); return convo_out(c,db)

@router.post("/chats/admin-seller")
def start_admin_seller(body: ChatStart, admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    s=db.get(SellerProfile,body.seller_id)
    if not s: raise HTTPException(404,"Seller not found")
    c=db.query(Conversation).filter(Conversation.kind=="admin_seller",Conversation.seller_id==s.id).first()
    if not c:
        c=Conversation(kind="admin_seller",seller_id=s.id,seller_name=s.business_name,customer_id=None,customer_name="Administration M’MEDPREN",subject=body.subject or "Administration",created_by_id=admin.id)
        db.add(c); db.flush()
        add_notification(db,s.user_id,"admin_chat","Message de l’administration",f"L’administration M’MEDPREN a ouvert une conversation avec votre boutique.","conversation",c.id)
    db.commit(); db.refresh(c); return convo_out(c,db)

@router.post("/chats/support")
def start_support(body: SupportStart, user: User=Depends(current_user), db: Session=Depends(get_db)):
    c=db.query(Conversation).filter(Conversation.kind=="support",Conversation.customer_id==user.id).first()
    created=False
    if not c:
        c=Conversation(kind="support",seller_id=None,seller_name="Service client M’MEDPREN",customer_id=user.id,customer_name=user.full_name or user.phone,subject=body.subject or "Service client M’MEDPREN",created_by_id=user.id)
        db.add(c); db.flush(); created=True
    elif body.subject: c.subject=body.subject
    if created: notify_conversation_started(db,c,user)
    db.commit(); db.refresh(c); return convo_out(c,db)

@router.get("/chats")
def my_chats(user: User=Depends(current_user), db: Session=Depends(get_db)):
    if Role.ADMIN.value in role_names(user):
        rows=db.query(Conversation).order_by(Conversation.updated_at.desc()).all()
    else:
        s=seller_for_user(db,user); q=db.query(Conversation)
        if s: rows=q.filter((Conversation.seller_id==s.id)|(Conversation.customer_id==user.id)).order_by(Conversation.updated_at.desc()).all()
        else: rows=q.filter(Conversation.customer_id==user.id).order_by(Conversation.updated_at.desc()).all()
    return [convo_out(c,db) for c in rows]

@router.get("/admin/chats")
def all_chats(admin: User=Depends(require_role(Role.ADMIN)), db: Session=Depends(get_db)):
    return [convo_out(c,db) for c in db.query(Conversation).order_by(Conversation.updated_at.desc()).all()]

@router.get("/chats/{conversation_id}/messages")
def messages(conversation_id: str, user: User=Depends(current_user), db: Session=Depends(get_db)):
    c=db.get(Conversation,conversation_id)
    if not c: raise HTTPException(404,"Conversation not found")
    if not can_access(c,user,db): raise HTTPException(403,"Conversation access denied")
    rows=db.query(ChatMessage).filter(ChatMessage.conversation_id==c.id).order_by(ChatMessage.created_at.asc()).limit(500).all()
    return [{"id":m.id,"conversation_id":m.conversation_id,"sender_id":m.sender_id,"sender_role":m.sender_role,"body":m.body,"created_at":m.created_at} for m in rows]

@router.post("/chats/{conversation_id}/messages")
def send_message(conversation_id: str, body: ChatMessageCreate, user: User=Depends(current_user), db: Session=Depends(get_db)):
    c=db.get(Conversation,conversation_id)
    if not c: raise HTTPException(404,"Conversation not found")
    if not can_access(c,user,db): raise HTTPException(403,"Conversation access denied")
    roles=role_names(user); s=seller_for_user(db,user)
    if Role.ADMIN.value in roles: sender_role="admin"
    elif Role.SELLER.value in roles and s and s.id==c.seller_id: sender_role="seller"
    else: sender_role="customer"
    m=ChatMessage(conversation_id=c.id,sender_id=user.id,sender_role=sender_role,body=body.body.strip())
    c.updated_at=datetime.now(timezone.utc); db.add(m); db.flush()
    preview=(body.body.strip()[:150] + ('…' if len(body.body.strip())>150 else ''))
    if c.kind=="support":
        if sender_role=="admin":
            add_notification(db,c.customer_id,"support_reply","Réponse du service client",preview,"conversation",c.id)
        else:
            notify_admins(db,"support_message","Nouveau message au service client",f"{c.customer_name or 'Utilisateur'} : {preview}","conversation",c.id,exclude_user_id=user.id)
    elif c.kind=="admin_seller":
        if sender_role=="admin" and c.seller_id:
            target=db.get(SellerProfile,c.seller_id); add_notification(db,target.user_id if target else None,"admin_chat","Nouveau message de l’administration",preview,"conversation",c.id)
        elif sender_role=="seller":
            notify_admins(db,"seller_message","Réponse d’un vendeur",f"{c.seller_name} : {preview}","conversation",c.id,exclude_user_id=user.id)
    else:
        if sender_role=="customer" and c.seller_id:
            target=db.get(SellerProfile,c.seller_id); add_notification(db,target.user_id if target else None,"chat_message","Nouveau message client",f"{c.customer_name or 'Client'} : {preview}","conversation",c.id)
        elif sender_role=="seller":
            add_notification(db,c.customer_id,"chat_message","Nouveau message du vendeur",f"{c.seller_name} : {preview}","conversation",c.id)
        notify_admins(db,"chat_message","Activité chat client-vendeur",f"{c.customer_name or 'Client'} ↔ {c.seller_name} : {preview}","conversation",c.id,exclude_user_id=user.id)
    db.commit(); db.refresh(m)
    return {"id":m.id,"conversation_id":m.conversation_id,"sender_id":m.sender_id,"sender_role":m.sender_role,"body":m.body,"created_at":m.created_at}
