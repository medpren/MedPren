from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, UserRole, Role, SellerProfile, Store, SellerStatus
from app.schemas import SellerApply
from app.deps import current_user, require_role, role_names
from app.utils import slugify

router=APIRouter(prefix="/sellers",tags=["sellers"])
@router.post("/apply")
def apply(body:SellerApply,user:User=Depends(current_user),db:Session=Depends(get_db)):
    existing=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()
    if existing: raise HTTPException(409,"Seller profile already exists")
    seller=SellerProfile(user_id=user.id,legal_name=body.legal_name,business_name=body.business_name,city=body.city)
    db.add(seller); db.flush(); db.add(Store(seller_id=seller.id,name=body.business_name,slug=f"{slugify(body.business_name)}-{seller.id[:6]}"))
    if Role.SELLER.value not in role_names(user): db.add(UserRole(user_id=user.id,role=Role.SELLER))
    db.commit(); return {"id":seller.id,"status":seller.status,"message":"Seller application submitted for admin approval"}
@router.get("/me")
def my_seller(user:User=Depends(require_role(Role.SELLER)),db:Session=Depends(get_db)):
    s=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()
    if not s: raise HTTPException(404,"Seller profile missing")
    return {"id":s.id,"business_name":s.business_name,"city":s.city,"status":s.status,"store_id":s.store.id if s.store else None}
