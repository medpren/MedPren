from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import User, UserRole, Role, SellerProfile, Store
from app.schemas import SellerApply, SellerUpdate
from app.deps import current_user, require_role, role_names
from app.utils import slugify
from app.services.notifications import notify_admins

router = APIRouter(prefix="/sellers", tags=["sellers"])


def _serialize_seller(s: SellerProfile):
    return {
        "id": s.id,
        "legal_name": s.legal_name,
        "business_name": s.business_name,
        "city": s.city,
        "status": s.status,
        "store_id": s.store.id if s.store else None,
        "store": {
            "id": s.store.id,
            "name": s.store.name,
            "description": s.store.description,
            "is_active": s.store.is_active,
        } if s.store else None,
    }


@router.post("/apply")
def apply(body: SellerApply, user: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if existing:
        raise HTTPException(409, "Seller profile already exists")
    seller = SellerProfile(
        user_id=user.id,
        legal_name=body.legal_name.strip(),
        business_name=body.business_name.strip(),
        city=body.city.strip(),
    )
    db.add(seller)
    db.flush()
    db.add(
        Store(
            seller_id=seller.id,
            name=body.business_name.strip(),
            slug=f"{slugify(body.business_name)}-{seller.id[:6]}",
        )
    )
    if Role.SELLER.value not in role_names(user):
        db.add(UserRole(user_id=user.id, role=Role.SELLER))
    notify_admins(db,"seller_application","Nouvelle demande vendeur",f"{seller.business_name} ({seller.city}) demande l’ouverture d’une boutique.","seller",seller.id)
    db.commit()
    db.refresh(seller)
    return {**_serialize_seller(seller), "message": "Seller application submitted for admin approval"}


@router.get("/me")
def my_seller(user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    s = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not s:
        raise HTTPException(404, "Seller profile missing")
    return _serialize_seller(s)


@router.patch("/me")
def update_my_seller(
    body: SellerUpdate,
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    s = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not s or not s.store:
        raise HTTPException(404, "Seller profile missing")

    data = body.model_dump(exclude_unset=True)
    for field in ("legal_name", "business_name", "city", "store_name"):
        if field in data and data[field] is not None:
            value = data[field].strip()
            if len(value) < 2:
                raise HTTPException(422, f"{field} is too short")
            data[field] = value

    if "legal_name" in data and data["legal_name"] is not None:
        s.legal_name = data["legal_name"]
    if "business_name" in data and data["business_name"] is not None:
        s.business_name = data["business_name"]
    if "city" in data and data["city"] is not None:
        s.city = data["city"]
    if "store_name" in data and data["store_name"] is not None:
        s.store.name = data["store_name"]
    if "store_description" in data:
        desc = data["store_description"]
        s.store.description = desc.strip() if isinstance(desc, str) and desc.strip() else None

    db.commit()
    db.refresh(s)
    return _serialize_seller(s)
