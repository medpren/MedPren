from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import User, UserRole, Role, SellerProfile, Store
from app.schemas import SellerApply, SellerUpdate
from app.deps import current_user, require_role, role_names
from app.utils import slugify
from app.services.notifications import notify_admins
from app.config import settings
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, detect_image_mime, resolve_image_mime, safe_upload_filename, upload_image

router = APIRouter(prefix="/sellers", tags=["sellers"])


def _serialize_seller(s: SellerProfile):
    return {
        "id": s.id,
        "legal_name": s.legal_name,
        "business_name": s.business_name,
        "city": s.city,
        "status": s.status,
        "store_id": s.store.id if s.store else None,
        "store": {
            "id": s.store.id,
            "name": s.store.name,
            "description": s.store.description,
            "logo_url": s.store.logo_url,
            "is_active": s.store.is_active,
        } if s.store else None,
    }


@router.post("/apply")
def apply(body: SellerApply, user: User = Depends(current_user), db: Session = Depends(get_db)):
    existing = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if existing:
        raise HTTPException(409, "Seller profile already exists")
    seller = SellerProfile(
        user_id=user.id,
        legal_name=body.legal_name.strip(),
        business_name=body.business_name.strip(),
        city=body.city.strip(),
    )
    db.add(seller)
    db.flush()
    db.add(
        Store(
            seller_id=seller.id,
            name=body.business_name.strip(),
            slug=f"{slugify(body.business_name)}-{seller.id[:6]}",
        )
    )
    if Role.SELLER.value not in role_names(user):
        db.add(UserRole(user_id=user.id, role=Role.SELLER))
    notify_admins(db,"seller_application","Nouvelle demande vendeur",f"{seller.business_name} ({seller.city}) demande l’ouverture d’une boutique.","seller",seller.id)
    db.commit()
    db.refresh(seller)
    return {**_serialize_seller(seller), "message": "Seller application submitted for admin approval"}


@router.get("/me")
def my_seller(user: User = Depends(require_role(Role.SELLER)), db: Session = Depends(get_db)):
    s = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not s:
        raise HTTPException(404, "Seller profile missing")
    return _serialize_seller(s)


@router.patch("/me")
def update_my_seller(
    body: SellerUpdate,
    user: User = Depends(require_role(Role.SELLER)),
    db: Session = Depends(get_db),
):
    s = db.query(SellerProfile).filter(SellerProfile.user_id == user.id).first()
    if not s or not s.store:
        raise HTTPException(404, "Seller profile missing")

    data = body.model_dump(exclude_unset=True)
    for field in ("legal_name", "business_name", "city", "store_name"):
        if field in data and data[field] is not None:
            value = data[field].strip()
            if len(value) < 2:
                raise HTTPException(422, f"{field} is too short")
            data[field] = value

    if "legal_name" in data and data["legal_name"] is not None:
        s.legal_name = data["legal_name"]
    if "business_name" in data and data["business_name"] is not None:
        s.business_name = data["business_name"]
    if "city" in data and data["city"] is not None:
        s.city = data["city"]
    if "store_name" in data and data["store_name"] is not None:
        s.store.name = data["store_name"]
    if "store_description" in data:
        desc = data["store_description"]
        s.store.description = desc.strip() if isinstance(desc, str) and desc.strip() else None

    db.commit()
    db.refresh(s)
    return _serialize_seller(s)


@router.post("/me/logo")
async def upload_store_logo(file: UploadFile=File(...), user: User=Depends(require_role(Role.SELLER)), db: Session=Depends(get_db)):
    s=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()
    if not s or not s.store: raise HTTPException(404,"Seller profile missing")
    data=await file.read(settings.image_max_bytes+1); await file.close()
    if not data: raise HTTPException(422,"Image file is empty")
    if len(data)>settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,"Image too large")
    mime=resolve_image_mime(data,file.content_type,file.filename)
    if not mime: raise HTTPException(415,"Le fichier sélectionné ne semble pas être une image compatible")
    old=s.store.logo_public_id
    try: stored=await upload_image(data,safe_upload_filename(file.filename,mime,"boutique"),mime,folder="mmedpren/stores")
    except ImageStorageNotConfigured as exc: raise HTTPException(503,str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502,str(exc)) from exc
    s.store.logo_url=stored["url"]; s.store.logo_public_id=stored["public_id"]
    db.commit(); db.refresh(s)
    if old and old!=s.store.logo_public_id: await delete_image(old)
    return {"ok":True,"seller":_serialize_seller(s)}

@router.delete("/me/logo")
async def remove_store_logo(user: User=Depends(require_role(Role.SELLER)), db: Session=Depends(get_db)):
    s=db.query(SellerProfile).filter(SellerProfile.user_id==user.id).first()
    if not s or not s.store: raise HTTPException(404,"Seller profile missing")
    old=s.store.logo_public_id; s.store.logo_url=None; s.store.logo_public_id=None; db.commit(); await delete_image(old)
    return {"ok":True}
