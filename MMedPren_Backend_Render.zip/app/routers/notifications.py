from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.deps import current_user
from app.models import Notification, PushSubscription, User
from app.schemas import PushSubscriptionIn, PushSubscriptionDelete

router=APIRouter(prefix="/notifications",tags=["notifications"])

def out(n: Notification):
    return {"id":n.id,"kind":n.kind,"title":n.title,"body":n.body,"entity_type":n.entity_type,"entity_id":n.entity_id,"is_read":n.is_read,"created_at":n.created_at}

@router.get("")
def list_notifications(unread_only: bool=False, limit: int=Query(100,ge=1,le=200), user: User=Depends(current_user), db: Session=Depends(get_db)):
    q=db.query(Notification).filter(Notification.user_id==user.id)
    if unread_only: q=q.filter(Notification.is_read==False)
    return [out(n) for n in q.order_by(Notification.created_at.desc()).limit(limit).all()]

@router.get("/unread-count")
def unread_count(user: User=Depends(current_user), db: Session=Depends(get_db)):
    return {"count":db.query(Notification).filter(Notification.user_id==user.id,Notification.is_read==False).count()}

@router.patch("/{notification_id}/read")
def mark_read(notification_id: str, user: User=Depends(current_user), db: Session=Depends(get_db)):
    n=db.get(Notification,notification_id)
    if not n or n.user_id!=user.id: raise HTTPException(404,"Notification not found")
    n.is_read=True; db.commit(); return {"ok":True}

@router.post("/read-all")
def mark_all_read(user: User=Depends(current_user), db: Session=Depends(get_db)):
    db.query(Notification).filter(Notification.user_id==user.id,Notification.is_read==False).update({Notification.is_read:True},synchronize_session=False)
    db.commit(); return {"ok":True}

@router.get("/push-config")
def push_config(user: User=Depends(current_user)):
    return {"enabled":settings.push_configured,"public_key":settings.vapid_public_key if settings.push_configured else None}

@router.post("/push-subscriptions")
def subscribe_push(body:PushSubscriptionIn,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if not settings.push_configured: raise HTTPException(503,"Push notifications are not configured on the server")
    row=db.query(PushSubscription).filter(PushSubscription.endpoint==body.endpoint).first()
    if not row:
        row=PushSubscription(user_id=user.id,endpoint=body.endpoint,p256dh=body.p256dh,auth=body.auth,user_agent=body.user_agent)
        db.add(row)
    else:
        row.user_id=user.id; row.p256dh=body.p256dh; row.auth=body.auth; row.user_agent=body.user_agent
    db.commit(); return {"ok":True}

@router.delete("/push-subscriptions")
def unsubscribe_push(body:PushSubscriptionDelete,user:User=Depends(current_user),db:Session=Depends(get_db)):
    row=db.query(PushSubscription).filter(PushSubscription.endpoint==body.endpoint,PushSubscription.user_id==user.id).first()
    if row: db.delete(row); db.commit()
    return {"ok":True}
