from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.db import get_db
from app.deps import current_user
from app.models import Notification, User

router=APIRouter(prefix="/notifications",tags=["notifications"])

def out(n: Notification):
    return {"id":n.id,"kind":n.kind,"title":n.title,"body":n.body,"entity_type":n.entity_type,"entity_id":n.entity_id,"is_read":n.is_read,"created_at":n.created_at}

@router.get("")
def list_notifications(unread_only: bool=False, limit: int=Query(100,ge=1,le=200), user: User=Depends(current_user), db: Session=Depends(get_db)):
    q=db.query(Notification).filter(Notification.user_id==user.id)
    if unread_only: q=q.filter(Notification.is_read==False)
    return [out(n) for n in q.order_by(Notification.created_at.desc()).limit(limit).all()]

@router.get("/unread-count")
def unread_count(user: User=Depends(current_user), db: Session=Depends(get_db)):
    return {"count":db.query(Notification).filter(Notification.user_id==user.id,Notification.is_read==False).count()}

@router.patch("/{notification_id}/read")
def mark_read(notification_id: str, user: User=Depends(current_user), db: Session=Depends(get_db)):
    n=db.get(Notification,notification_id)
    if not n or n.user_id!=user.id: raise HTTPException(404,"Notification not found")
    n.is_read=True; db.commit(); return {"ok":True}

@router.post("/read-all")
def mark_all_read(user: User=Depends(current_user), db: Session=Depends(get_db)):
    db.query(Notification).filter(Notification.user_id==user.id,Notification.is_read==False).update({Notification.is_read:True},synchronize_session=False)
    db.commit(); return {"ok":True}
