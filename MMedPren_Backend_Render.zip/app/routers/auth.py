from datetime import datetime, timedelta, timezone
import re
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session
from app.db import get_db
from app.config import settings
from app.models import OTPChallenge, User, UserRole, Role
from app.schemas import OTPRequest, LoginIdentifierRequest, OTPRequestOut, OTPVerify, TokenOut, UserUpdate
from app.security import generate_otp, otp_hash, verify_otp, create_access_token
from app.services.otp import get_otp_provider
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, detect_image_mime, resolve_image_mime, safe_upload_filename, upload_image
from app.utils import normalize_phone
from app.deps import current_user, role_names

router=APIRouter(prefix="/auth",tags=["auth"])

def _user_out(user: User):
    return {
        "id":user.id,"phone":user.phone,"full_name":user.full_name,"email":user.email,
        "whatsapp_phone":user.whatsapp_phone,"profile_kind":user.profile_kind,
        "profile_image_url":user.profile_image_url,"roles":sorted(role_names(user))
    }

def _safe_filename(filename: str|None, mime: str):
    ext={"image/jpeg":".jpg","image/png":".png","image/webp":".webp"}[mime]
    stem=re.sub(r"[^a-zA-Z0-9_-]+","-",(filename or "profil").rsplit(".",1)[0]).strip("-")
    return f"{stem or 'profil'}{ext}"

def _mask_phone(phone: str) -> str:
    if len(phone) <= 6:
        return phone
    return phone[:4] + "•" * max(3, len(phone)-7) + phone[-3:]

def _create_phone_challenge(phone: str, db: Session):
    phone=normalize_phone(phone)
    latest=db.query(OTPChallenge).filter(OTPChallenge.phone==phone).order_by(OTPChallenge.created_at.desc()).first()
    if latest:
        created=latest.created_at if latest.created_at.tzinfo else latest.created_at.replace(tzinfo=timezone.utc)
        if (datetime.now(timezone.utc)-created).total_seconds() < settings.otp_request_cooldown_seconds:
            raise HTTPException(429,"Please wait before requesting another OTP")
    code=generate_otp()
    ch=OTPChallenge(phone=phone,code_hash=otp_hash(code),expires_at=datetime.now(timezone.utc)+timedelta(seconds=settings.otp_ttl_seconds))
    db.add(ch); db.commit(); db.refresh(ch); get_otp_provider().send(phone,code)
    return OTPRequestOut(challenge_id=ch.id,expires_in=settings.otp_ttl_seconds,debug_code=code if settings.environment=="development" else None,channel="phone",destination_hint=_mask_phone(phone))

@router.post("/login/request",response_model=OTPRequestOut)
def request_login(body:LoginIdentifierRequest,db:Session=Depends(get_db)):
    identifier=body.identifier.strip()
    if "@" in identifier:
        email=identifier.lower()
        user=db.query(User).filter(User.email==email,User.is_active==True).first()
        if not user:
            raise HTTPException(404,"Aucun compte actif n'est associé à cette adresse e-mail")
        return _create_phone_challenge(user.phone,db)
    return _create_phone_challenge(identifier,db)

@router.post("/otp/request",response_model=OTPRequestOut)
def request_otp(body:OTPRequest,db:Session=Depends(get_db)):
    return _create_phone_challenge(body.phone,db)

@router.post("/otp/verify",response_model=TokenOut)
def verify(body:OTPVerify,db:Session=Depends(get_db)):
    ch=db.get(OTPChallenge,body.challenge_id)
    if not ch or ch.consumed_at: raise HTTPException(400,"Invalid challenge")
    expires_at=ch.expires_at if ch.expires_at.tzinfo else ch.expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc): raise HTTPException(400,"OTP expired")
    if ch.attempts>=settings.otp_max_attempts: raise HTTPException(429,"Too many attempts")
    if not verify_otp(body.code,ch.code_hash):
        ch.attempts+=1; db.commit(); raise HTTPException(400,"Invalid OTP")
    ch.consumed_at=datetime.now(timezone.utc)
    user=db.query(User).filter(User.phone==ch.phone).first()
    if not user:
        user=User(phone=ch.phone); db.add(user); db.flush(); db.add(UserRole(user_id=user.id,role=Role.CUSTOMER))
    db.commit(); db.refresh(user)
    token=create_access_token(user.id,sorted(role_names(user)))
    return {"access_token":token,"user":_user_out(user)}

@router.get("/me")
def me(user:User=Depends(current_user)): return _user_out(user)

@router.patch("/me")
def update_me(body:UserUpdate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if body.full_name is not None: user.full_name=body.full_name.strip() or None
    if body.email is not None:
        email=body.email.strip().lower() or None
        if email:
            existing=db.query(User).filter(User.email==email,User.id!=user.id).first()
            if existing: raise HTTPException(409,"Email already used")
        user.email=email
    if body.whatsapp_phone is not None:
        raw=body.whatsapp_phone.strip()
        user.whatsapp_phone=normalize_phone(raw) if raw else None
    if body.profile_kind is not None: user.profile_kind=body.profile_kind
    db.commit(); db.refresh(user); return {"ok":True,"user":_user_out(user)}

@router.post("/me/image")
async def upload_profile_image(file: UploadFile=File(...),user:User=Depends(current_user),db:Session=Depends(get_db)):
    data=await file.read(settings.image_max_bytes+1); await file.close()
    if not data: raise HTTPException(422,"Image file is empty")
    if len(data)>settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,"Image too large")
    mime=resolve_image_mime(data,file.content_type,file.filename)
    if not mime: raise HTTPException(415,"Le fichier sélectionné ne semble pas être une image compatible")
    old=user.profile_image_public_id
    try: stored=await upload_image(data,safe_upload_filename(file.filename,mime,"profil"),mime,folder="mmedpren/profiles")
    except ImageStorageNotConfigured as exc: raise HTTPException(503,str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502,str(exc)) from exc
    user.profile_image_url=stored["url"]; user.profile_image_public_id=stored["public_id"]
    db.commit(); db.refresh(user)
    if old and old!=user.profile_image_public_id: await delete_image(old)
    return {"ok":True,"profile_image_url":user.profile_image_url,"user":_user_out(user)}

@router.delete("/me/image")
async def remove_profile_image(user:User=Depends(current_user),db:Session=Depends(get_db)):
    old=user.profile_image_public_id; user.profile_image_url=None; user.profile_image_public_id=None; db.commit(); await delete_image(old)
    return {"ok":True}
