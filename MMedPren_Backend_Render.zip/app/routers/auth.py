from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.config import settings
from app.models import OTPChallenge, User, UserRole, Role
from app.schemas import OTPRequest, OTPRequestOut, OTPVerify, TokenOut, UserUpdate
from app.security import generate_otp, otp_hash, verify_otp, create_access_token
from app.services.otp import get_otp_provider
from app.utils import normalize_phone
from app.deps import current_user, role_names

router=APIRouter(prefix="/auth",tags=["auth"])
@router.post("/otp/request",response_model=OTPRequestOut)
def request_otp(body:OTPRequest,db:Session=Depends(get_db)):
    phone=normalize_phone(body.phone)
    latest=db.query(OTPChallenge).filter(OTPChallenge.phone==phone).order_by(OTPChallenge.created_at.desc()).first()
    if latest:
        created=latest.created_at if latest.created_at.tzinfo else latest.created_at.replace(tzinfo=timezone.utc)
        if (datetime.now(timezone.utc)-created).total_seconds() < settings.otp_request_cooldown_seconds:
            raise HTTPException(429,"Please wait before requesting another OTP")
    code=generate_otp()
    ch=OTPChallenge(phone=phone,code_hash=otp_hash(code),expires_at=datetime.now(timezone.utc)+timedelta(seconds=settings.otp_ttl_seconds))
    db.add(ch); db.commit(); db.refresh(ch); get_otp_provider().send(phone,code)
    return OTPRequestOut(challenge_id=ch.id,expires_in=settings.otp_ttl_seconds,debug_code=code if settings.environment=="development" else None)
@router.post("/otp/verify",response_model=TokenOut)
def verify(body:OTPVerify,db:Session=Depends(get_db)):
    ch=db.get(OTPChallenge,body.challenge_id)
    if not ch or ch.consumed_at: raise HTTPException(400,"Invalid challenge")
    expires_at = ch.expires_at if ch.expires_at.tzinfo else ch.expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc): raise HTTPException(400,"OTP expired")
    if ch.attempts>=settings.otp_max_attempts: raise HTTPException(429,"Too many attempts")
    if not verify_otp(body.code,ch.code_hash):
        ch.attempts+=1; db.commit(); raise HTTPException(400,"Invalid OTP")
    ch.consumed_at=datetime.now(timezone.utc)
    user=db.query(User).filter(User.phone==ch.phone).first()
    if not user:
        user=User(phone=ch.phone); db.add(user); db.flush(); db.add(UserRole(user_id=user.id,role=Role.CUSTOMER))
    db.commit(); db.refresh(user)
    roles=sorted(role_names(user)); token=create_access_token(user.id,roles)
    return {"access_token":token,"user":{"id":user.id,"phone":user.phone,"full_name":user.full_name,"email":user.email,"roles":roles}}
@router.get("/me")
def me(user:User=Depends(current_user)): return {"id":user.id,"phone":user.phone,"full_name":user.full_name,"email":user.email,"roles":sorted(role_names(user))}
@router.patch("/me")
def update_me(body:UserUpdate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if body.full_name is not None: user.full_name=body.full_name
    if body.email is not None: user.email=body.email
    db.commit(); return {"ok":True}
