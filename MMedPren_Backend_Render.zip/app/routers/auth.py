from datetime import datetime, timedelta, timezone
import re
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.orm import Session
from app.db import get_db
from app.config import settings
from app.models import OTPChallenge, User, UserIdentity, UserRole, Role
from app.schemas import (
    OTPRequest, LoginIdentifierRequest, OTPRequestOut, OTPVerify, TokenOut, UserUpdate,
    PasswordLogin, PasswordSet, PasswordResetVerify, GoogleCredential, AppleCredential,
    IdentityAdd, IdentityPhoneVerify,
)
from app.security import generate_otp, otp_hash, verify_otp, create_access_token, hash_password, verify_password
from app.services.otp import get_otp_provider
from app.services.image_storage import ImageStorageError, ImageStorageNotConfigured, delete_image, resolve_image_mime, safe_upload_filename, upload_image
from app.utils import normalize_phone
from app.deps import current_user, role_names

router=APIRouter(prefix="/auth",tags=["auth"])


def _user_out(user: User):
    return {
        "id":user.id,"phone":user.phone,"full_name":user.full_name,"email":user.email,
        "whatsapp_phone":user.whatsapp_phone,"profile_kind":user.profile_kind,
        "profile_image_url":user.profile_image_url,"roles":sorted(role_names(user)),
        "password_enabled":bool(user.password_hash),
    }


def _mask_phone(phone: str) -> str:
    if len(phone) <= 6: return phone
    return phone[:4] + "•" * max(3, len(phone)-7) + phone[-3:]


def _normalize(kind: str, value: str) -> str:
    if kind == "phone": return normalize_phone(value)
    if kind == "email": return value.strip().lower()
    return value.strip()


def _find_identity(db: Session, kind: str, value: str, verified_only: bool=True):
    normalized=_normalize(kind,value)
    q=db.query(UserIdentity).filter(UserIdentity.kind==kind,UserIdentity.normalized_value==normalized)
    if verified_only: q=q.filter(UserIdentity.is_verified==True)
    return q.first()


def _find_user_by_identifier(db: Session, identifier: str):
    raw=identifier.strip()
    if "@" in raw:
        normalized=raw.lower()
        any_ident=_find_identity(db,"email",normalized,False)
        if any_ident:
            return db.get(User,any_ident.user_id) if any_ident.is_verified else None
        return db.query(User).filter(User.email==normalized,User.is_active==True).first()
    normalized=normalize_phone(raw)
    any_ident=_find_identity(db,"phone",normalized,False)
    if any_ident:
        return db.get(User,any_ident.user_id) if any_ident.is_verified else None
    return db.query(User).filter(User.phone==normalized,User.is_active==True).first()


def _ensure_identity(db: Session, user: User, kind: str, value: str, verified: bool=True, primary: bool=False):
    normalized=_normalize(kind,value)
    existing=db.query(UserIdentity).filter(UserIdentity.kind==kind,UserIdentity.normalized_value==normalized).first()
    if existing and existing.user_id != user.id:
        raise HTTPException(409,"Cet identifiant est déjà associé à un autre compte M’MEDPREN")
    if not existing:
        existing=UserIdentity(user_id=user.id,kind=kind,value=value.strip(),normalized_value=normalized,is_verified=verified,is_primary=primary)
        db.add(existing)
    else:
        existing.value=value.strip(); existing.is_verified=existing.is_verified or verified; existing.is_primary=existing.is_primary or primary
    return existing


def _primary_phone(db: Session, user: User):
    if user.phone: return user.phone
    ident=(db.query(UserIdentity).filter(UserIdentity.user_id==user.id,UserIdentity.kind=="phone",UserIdentity.is_verified==True)
           .order_by(UserIdentity.is_primary.desc(),UserIdentity.created_at.asc()).first())
    return ident.normalized_value if ident else None


def _token(user: User):
    return {"access_token":create_access_token(user.id,sorted(role_names(user))),"user":_user_out(user)}


def _create_phone_challenge(phone: str, db: Session):
    phone=normalize_phone(phone)
    latest=db.query(OTPChallenge).filter(OTPChallenge.phone==phone).order_by(OTPChallenge.created_at.desc()).first()
    if latest:
        created=latest.created_at if latest.created_at.tzinfo else latest.created_at.replace(tzinfo=timezone.utc)
        if (datetime.now(timezone.utc)-created).total_seconds() < settings.otp_request_cooldown_seconds:
            raise HTTPException(429,"Please wait before requesting another OTP")
    code=generate_otp()
    ch=OTPChallenge(phone=phone,code_hash=otp_hash(code),expires_at=datetime.now(timezone.utc)+timedelta(seconds=settings.otp_ttl_seconds))
    db.add(ch); db.commit(); db.refresh(ch); get_otp_provider().send(phone,code)
    return OTPRequestOut(challenge_id=ch.id,expires_in=settings.otp_ttl_seconds,debug_code=code if settings.environment=="development" else None,channel="phone",destination_hint=_mask_phone(phone))


def _consume_challenge(challenge_id: str, code: str, db: Session):
    ch=db.get(OTPChallenge,challenge_id)
    if not ch or ch.consumed_at: raise HTTPException(400,"Invalid challenge")
    expires_at=ch.expires_at if ch.expires_at.tzinfo else ch.expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc): raise HTTPException(400,"OTP expired")
    if ch.attempts>=settings.otp_max_attempts: raise HTTPException(429,"Too many attempts")
    if not verify_otp(code,ch.code_hash):
        ch.attempts+=1; db.commit(); raise HTTPException(400,"Invalid OTP")
    ch.consumed_at=datetime.now(timezone.utc); db.flush()
    return ch


@router.get("/config")
def auth_config():
    return {
        "google_enabled":bool(settings.google_client_id),
        "google_client_id":settings.google_client_id or None,
        "apple_enabled":bool(settings.apple_client_id and settings.apple_redirect_uri),
        "apple_client_id":settings.apple_client_id or None,
        "apple_redirect_uri":settings.apple_redirect_uri if settings.apple_client_id else None,
        "password_enabled":True,
    }


@router.post("/login/request",response_model=OTPRequestOut)
def request_login(body:LoginIdentifierRequest,db:Session=Depends(get_db)):
    identifier=body.identifier.strip()
    if "@" in identifier:
        user=_find_user_by_identifier(db,identifier)
        if not user or not user.is_active: raise HTTPException(404,"Aucun compte actif n'est associé à cette adresse e-mail")
        phone=_primary_phone(db,user)
        if not phone: raise HTTPException(409,"Ce compte n'a pas de téléphone vérifié. Utilisez votre mot de passe, Google ou Apple.")
        return _create_phone_challenge(phone,db)
    return _create_phone_challenge(identifier,db)


@router.post("/otp/request",response_model=OTPRequestOut)
def request_otp(body:OTPRequest,db:Session=Depends(get_db)):
    return _create_phone_challenge(body.phone,db)


@router.post("/otp/verify",response_model=TokenOut)
def verify(body:OTPVerify,db:Session=Depends(get_db)):
    ch=_consume_challenge(body.challenge_id,body.code,db)
    user=_find_user_by_identifier(db,ch.phone)
    if not user:
        user=User(phone=ch.phone); db.add(user); db.flush(); db.add(UserRole(user_id=user.id,role=Role.CUSTOMER))
    if not user.is_active: raise HTTPException(403,"Compte désactivé")
    if not user.phone: user.phone=ch.phone
    _ensure_identity(db,user,"phone",ch.phone,True,primary=(user.phone==ch.phone))
    db.commit(); db.refresh(user)
    return _token(user)


@router.post("/password/login",response_model=TokenOut)
def password_login(body:PasswordLogin,db:Session=Depends(get_db)):
    user=_find_user_by_identifier(db,body.identifier)
    if not user or not user.is_active or not verify_password(body.password,user.password_hash):
        raise HTTPException(401,"Identifiant ou mot de passe incorrect")
    return _token(user)


@router.post("/password/set")
def set_password(body:PasswordSet,user:User=Depends(current_user),db:Session=Depends(get_db)):
    try: user.password_hash=hash_password(body.password)
    except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    db.commit(); return {"ok":True,"password_enabled":True}


@router.post("/password/reset/request",response_model=OTPRequestOut)
def reset_password_request(body:LoginIdentifierRequest,db:Session=Depends(get_db)):
    user=_find_user_by_identifier(db,body.identifier)
    if not user or not user.is_active: raise HTTPException(404,"Compte introuvable")
    phone=_primary_phone(db,user)
    if not phone: raise HTTPException(409,"Ce compte n'a pas de téléphone vérifié. Reconnectez-vous avec Google ou Apple.")
    return _create_phone_challenge(phone,db)


@router.post("/password/reset/verify",response_model=TokenOut)
def reset_password_verify(body:PasswordResetVerify,db:Session=Depends(get_db)):
    ch=_consume_challenge(body.challenge_id,body.code,db)
    user=_find_user_by_identifier(db,ch.phone)
    if not user or not user.is_active: raise HTTPException(404,"Compte introuvable")
    try: user.password_hash=hash_password(body.new_password)
    except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    db.commit(); db.refresh(user); return _token(user)


def _social_user(db: Session, provider: str, subject: str, email: str|None, full_name: str|None, picture: str|None=None):
    ident=_find_identity(db,provider,subject,True)
    if ident:
        user=db.get(User,ident.user_id)
    else:
        user=None
        if email:
            email_ident=_find_identity(db,"email",email,False)
            if email_ident: user=db.get(User,email_ident.user_id)
            else: user=_find_user_by_identifier(db,email)
        if not user:
            user=User(phone=None,email=email,full_name=full_name,profile_image_url=picture)
            db.add(user); db.flush(); db.add(UserRole(user_id=user.id,role=Role.CUSTOMER))
        _ensure_identity(db,user,provider,subject,True,False)
    if not user.is_active: raise HTTPException(403,"Compte désactivé")
    if email:
        _ensure_identity(db,user,"email",email,True,primary=(user.email is None or user.email.lower()==email.lower()))
        if not user.email: user.email=email.lower()
    if full_name and not user.full_name: user.full_name=full_name
    if picture and not user.profile_image_url: user.profile_image_url=picture
    db.commit(); db.refresh(user); return user


@router.post("/google",response_model=TokenOut)
def google_login(body:GoogleCredential,db:Session=Depends(get_db)):
    if not settings.google_client_id: raise HTTPException(503,"Google Sign-In n'est pas encore configuré")
    try:
        from google.oauth2 import id_token
        from google.auth.transport import requests as google_requests
        info=id_token.verify_oauth2_token(body.credential,google_requests.Request(),settings.google_client_id)
        if info.get("iss") not in ("accounts.google.com","https://accounts.google.com"): raise ValueError("issuer")
        subject=str(info["sub"])
        email=(info.get("email") or "").strip().lower() or None
        if email and not info.get("email_verified"): raise ValueError("email not verified")
        user=_social_user(db,"google",subject,email,info.get("name"),info.get("picture"))
        return _token(user)
    except HTTPException: raise
    except Exception as exc: raise HTTPException(401,"Connexion Google invalide ou expirée") from exc


@router.post("/apple",response_model=TokenOut)
def apple_login(body:AppleCredential,db:Session=Depends(get_db)):
    if not settings.apple_client_id: raise HTTPException(503,"Sign in with Apple n'est pas encore configuré")
    try:
        import jwt
        jwks=jwt.PyJWKClient("https://appleid.apple.com/auth/keys")
        key=jwks.get_signing_key_from_jwt(body.credential)
        info=jwt.decode(body.credential,key.key,algorithms=["RS256"],audience=settings.apple_client_id,issuer="https://appleid.apple.com")
        email=(info.get("email") or "").strip().lower() or None
        user=_social_user(db,"apple",str(info["sub"]),email,body.full_name,None)
        return _token(user)
    except HTTPException: raise
    except Exception as exc: raise HTTPException(401,"Connexion Apple invalide ou expirée") from exc


@router.get("/identities")
def list_identities(user:User=Depends(current_user),db:Session=Depends(get_db)):
    rows=db.query(UserIdentity).filter(UserIdentity.user_id==user.id).order_by(UserIdentity.kind,UserIdentity.created_at).all()
    return [{"id":r.id,"kind":r.kind,"value":r.value if r.kind in ("phone","email") else r.kind,"verified":r.is_verified,"primary":r.is_primary} for r in rows]


@router.post("/identities/email")
def add_email_identity(body:IdentityAdd,user:User=Depends(current_user),db:Session=Depends(get_db)):
    # Ownership of arbitrary e-mail is not silently claimed. Google/Apple can promote it to verified later.
    email=body.value.strip().lower()
    if "@" not in email: raise HTTPException(422,"Adresse e-mail invalide")
    ident=_ensure_identity(db,user,"email",email,False,False)
    if not user.email: user.email=email
    db.commit(); return {"ok":True,"identity":{"id":ident.id,"kind":"email","value":email,"verified":ident.is_verified}}


@router.post("/identities/phone/request",response_model=OTPRequestOut)
def add_phone_request(body:OTPRequest,user:User=Depends(current_user),db:Session=Depends(get_db)):
    phone=normalize_phone(body.phone)
    existing=_find_identity(db,"phone",phone,False)
    if existing and existing.user_id!=user.id: raise HTTPException(409,"Ce numéro appartient déjà à un autre compte")
    return _create_phone_challenge(phone,db)


@router.post("/identities/phone/verify")
def add_phone_verify(body:IdentityPhoneVerify,user:User=Depends(current_user),db:Session=Depends(get_db)):
    ch=_consume_challenge(body.challenge_id,body.code,db)
    _ensure_identity(db,user,"phone",ch.phone,True,primary=(user.phone is None))
    if not user.phone: user.phone=ch.phone
    db.commit(); return {"ok":True,"phone":ch.phone}


@router.get("/me")
def me(user:User=Depends(current_user)): return _user_out(user)


@router.patch("/me")
def update_me(body:UserUpdate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if body.full_name is not None: user.full_name=body.full_name.strip() or None
    if body.email is not None:
        email=body.email.strip().lower() or None
        if email:
            existing=db.query(User).filter(User.email==email,User.id!=user.id).first()
            identity=_find_identity(db,"email",email,False)
            if existing or (identity and identity.user_id!=user.id): raise HTTPException(409,"Email already used")
            _ensure_identity(db,user,"email",email,False,primary=True)
        user.email=email
    if body.whatsapp_phone is not None:
        raw=body.whatsapp_phone.strip(); user.whatsapp_phone=normalize_phone(raw) if raw else None
    if body.profile_kind is not None: user.profile_kind=body.profile_kind
    db.commit(); db.refresh(user); return {"ok":True,"user":_user_out(user)}


@router.post("/me/image")
async def upload_profile_image(file: UploadFile=File(...),user:User=Depends(current_user),db:Session=Depends(get_db)):
    data=await file.read(settings.image_max_bytes+1); await file.close()
    if not data: raise HTTPException(422,"Image file is empty")
    if len(data)>settings.image_max_bytes: raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,"Image too large")
    mime=resolve_image_mime(data,file.content_type,file.filename)
    if not mime: raise HTTPException(415,"Le fichier sélectionné ne semble pas être une image compatible")
    old=user.profile_image_public_id
    try: stored=await upload_image(data,safe_upload_filename(file.filename,mime,"profil"),mime,folder="mmedpren/profiles")
    except ImageStorageNotConfigured as exc: raise HTTPException(503,str(exc)) from exc
    except ImageStorageError as exc: raise HTTPException(502,str(exc)) from exc
    user.profile_image_url=stored["url"]; user.profile_image_public_id=stored["public_id"]
    db.commit(); db.refresh(user)
    if old and old!=user.profile_image_public_id: await delete_image(old)
    return {"ok":True,"profile_image_url":user.profile_image_url,"user":_user_out(user)}


@router.delete("/me/image")
async def remove_profile_image(user:User=Depends(current_user),db:Session=Depends(get_db)):
    old=user.profile_image_public_id; user.profile_image_url=None; user.profile_image_public_id=None; db.commit(); await delete_image(old)
    return {"ok":True}
