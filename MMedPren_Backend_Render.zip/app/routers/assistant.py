import re
import httpx
from fastapi import APIRouter, Depends
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.config import settings
from app.db import get_db
from app.models import Product, SellerProfile, SellerStatus, Store
from app.schemas import AssistantMessage

router=APIRouter(prefix="/assistant",tags=["assistant"])

def local_answer(message: str, db: Session):
    text=message.strip(); v=text.lower()
    tokens=[t for t in re.findall(r"[a-zà-ÿ0-9]+",v) if len(t)>=4][:8]
    q=(db.query(Product).join(Product.store).join(Store.seller)
       .filter(Product.is_active==True,Product.moderation_status=="approved",Store.is_active==True,SellerProfile.status==SellerStatus.APPROVED))
    if tokens:
        clauses=[]
        for t in tokens:
            clauses += [Product.name.ilike(f"%{t}%"), Product.description.ilike(f"%{t}%"), Product.category.ilike(f"%{t}%")]
        q=q.filter(or_(*clauses))
    matches=q.order_by(Product.created_at.desc()).limit(3).all()
    products=[{"id":p.id,"name":p.name,"price":float(p.price),"currency":p.currency,"seller_id":p.store.seller.id if p.store and p.store.seller else None} for p in matches]
    if any(w in v for w in ["litige","plainte","problème vendeur","probleme vendeur","remboursement","arnaque","malentendu","service client","humain"]):
        return {"answer":"Je peux vous orienter, mais pour un litige, un malentendu avec un vendeur ou une demande qui nécessite une décision humaine, utilisez « Service client humain » afin qu’un administrateur M’MEDPREN reprenne le dossier.","intent":"support","products":products,"provider":"local"}
    if any(w in v for w in ["emploi","stage","travail","formation"]):
        return {"answer":"Pour les emplois, stages et formations, ouvrez Work4Future. Vous pouvez aussi créer votre profil professionnel afin de centraliser vos opportunités.","intent":"work","products":products,"provider":"local"}
    if any(w in v for w in ["boutique","vendre","vendeur"]):
        return {"answer":"Pour vendre, ouvrez Mon compte → Ma boutique. Une nouvelle publication produit doit être validée par l’administrateur avant d’apparaître dans le Marché.","intent":"seller","products":products,"provider":"local"}
    if products:
        names=", ".join(p["name"] for p in products)
        return {"answer":f"J’ai trouvé des produits qui peuvent correspondre : {names}. Vous pouvez les ouvrir dans le Marché, commander directement ou discuter avec le vendeur.","intent":"market","products":products,"provider":"local"}
    if any(w in v for w in ["commande","acheter","marché","produit","prix"]):
        return {"answer":"Je peux vous aider à chercher un produit, à passer une commande ou à ouvrir une discussion avec le vendeur. Précisez simplement le produit ou la catégorie recherchée.","intent":"market","products":[],"provider":"local"}
    return {"answer":"Je peux vous aider avec le Marché, vos commandes, une boutique, Work4Future, les services, les notifications ou vous transférer au service client humain en cas de litige.","intent":"general","products":products,"provider":"local"}

async def gemini_answer(message: str, fallback: dict):
    if not settings.gemini_api_key:
        return fallback
    prompt=("Tu es l'assistance M'MEDPREN. Réponds en français, brièvement et de façon pratique. "
            "N'invente ni paiement confirmé ni statut de commande. Pour tout litige ou malentendu client-vendeur, "
            "recommande le service client humain. Question: "+message)
    url=f"https://generativelanguage.googleapis.com/v1beta/models/{settings.gemini_model}:generateContent"
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            r=await client.post(url,params={"key":settings.gemini_api_key},json={"contents":[{"parts":[{"text":prompt}]}]})
            r.raise_for_status(); data=r.json()
        text=data.get("candidates",[{}])[0].get("content",{}).get("parts",[{}])[0].get("text")
        if text:
            return {**fallback,"answer":text.strip(),"provider":"gemini"}
    except Exception:
        pass
    return fallback

@router.post("/message")
async def message(body: AssistantMessage, db: Session=Depends(get_db)):
    fallback=local_answer(body.message,db)
    return await gemini_answer(body.message,fallback)
