from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Delivery, DeliveryStatus, Role, User, OrderStatus, OrderItem, Product, Store, SellerProfile
from app.schemas import DeliveryAssign, DeliveryStatusUpdate
from app.deps import current_user, require_role, role_names
from app.services.notifications import add_notification, notify_admins, notify_many

router=APIRouter(prefix="/deliveries",tags=["deliveries"])
def _seller_users_for_order(db, order_id):
    rows=(db.query(SellerProfile.user_id).join(Store,Store.seller_id==SellerProfile.id).join(Product,Product.store_id==Store.id).join(OrderItem,OrderItem.product_id==Product.id).filter(OrderItem.order_id==order_id).distinct().all())
    return [r[0] for r in rows]
def out(d): return {"id":d.id,"order_id":d.order_id,"courier_id":d.courier_id,"status":d.status}
@router.get("/mine")
def mine(user:User=Depends(require_role(Role.COURIER)),db:Session=Depends(get_db)): return [out(d) for d in db.query(Delivery).filter(Delivery.courier_id==user.id).all()]
@router.patch("/{delivery_id}/status")
def update_status(delivery_id:str,body:DeliveryStatusUpdate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    d=db.get(Delivery,delivery_id)
    if not d: raise HTTPException(404,"Delivery not found")
    roles=role_names(user)
    if 'admin' not in roles and d.courier_id!=user.id: raise HTTPException(403,"Forbidden")
    d.status=body.status
    if body.status==DeliveryStatus.DELIVERED:
        d.delivered_at=datetime.now(timezone.utc); d.order.status=OrderStatus.DELIVERED
    elif body.status in (DeliveryStatus.PICKED_UP,DeliveryStatus.IN_TRANSIT): d.order.status=OrderStatus.SHIPPED
    label=body.status.value.replace("_"," ")
    add_notification(db,d.order.customer_id,"delivery_status","Livraison mise à jour",f"Commande {d.order_id[:8]} • {label}.","delivery",d.id)
    notify_many(db,_seller_users_for_order(db,d.order_id),"delivery_status","Livraison mise à jour",f"Commande {d.order_id[:8]} • {label}.","delivery",d.id)
    notify_admins(db,"delivery_status","Livraison mise à jour",f"Commande {d.order_id[:8]} • {label}.","delivery",d.id,exclude_user_id=user.id)
    db.commit(); return out(d)
