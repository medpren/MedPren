from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Delivery, DeliveryStatus, Role, User, OrderStatus
from app.schemas import DeliveryAssign, DeliveryStatusUpdate
from app.deps import current_user, require_role, role_names

router=APIRouter(prefix="/deliveries",tags=["deliveries"])
def out(d): return {"id":d.id,"order_id":d.order_id,"courier_id":d.courier_id,"status":d.status}
@router.get("/mine")
def mine(user:User=Depends(require_role(Role.COURIER)),db:Session=Depends(get_db)): return [out(d) for d in db.query(Delivery).filter(Delivery.courier_id==user.id).all()]
@router.patch("/{delivery_id}/status")
def update_status(delivery_id:str,body:DeliveryStatusUpdate,user:User=Depends(current_user),db:Session=Depends(get_db)):
    d=db.get(Delivery,delivery_id)
    if not d: raise HTTPException(404,"Delivery not found")
    roles=role_names(user)
    if 'admin' not in roles and d.courier_id!=user.id: raise HTTPException(403,"Forbidden")
    d.status=body.status
    if body.status==DeliveryStatus.DELIVERED:
        d.delivered_at=datetime.now(timezone.utc); d.order.status=OrderStatus.DELIVERED
    elif body.status in (DeliveryStatus.PICKED_UP,DeliveryStatus.IN_TRANSIT): d.order.status=OrderStatus.SHIPPED
    db.commit(); return out(d)
