import re, unicodedata
from fastapi import HTTPException

def normalize_phone(phone:str):
    raw=re.sub(r"[\s().-]","",phone.strip())
    if raw.startswith("00"): raw="+"+raw[2:]
    if raw.startswith("0") and raw[1:].isdigit(): raw="+243"+raw[1:]
    elif raw.startswith("243") and raw.isdigit(): raw="+"+raw
    elif not raw.startswith("+") and raw.isdigit(): raw="+243"+raw
    if not re.fullmatch(r"\+[1-9]\d{7,14}",raw): raise HTTPException(status_code=422,detail="Invalid phone number")
    return raw
def slugify(s:str):
    s=unicodedata.normalize("NFKD",s).encode("ascii","ignore").decode().lower()
    s=re.sub(r"[^a-z0-9]+","-",s).strip("-")
    return s or "item"
