from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, Role
from app.security import decode_token

bearer=HTTPBearer(auto_error=False)
def current_user(creds:HTTPAuthorizationCredentials=Depends(bearer), db:Session=Depends(get_db)):
    if not creds: raise HTTPException(status_code=401,detail="Authentication required")
    try: payload=decode_token(creds.credentials); uid=payload.get("sub")
    except ValueError: raise HTTPException(status_code=401,detail="Invalid token")
    user=db.get(User,uid)
    if not user or not user.is_active: raise HTTPException(status_code=401,detail="Inactive user")
    return user
def role_names(user:User): return {r.role.value for r in user.roles}
def require_role(*roles:Role):
    allowed={r.value for r in roles}
    def dep(user:User=Depends(current_user)):
        if not (role_names(user)&allowed): raise HTTPException(status_code=403,detail="Insufficient permissions")
        return user
    return dep
