import enum, uuid
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import String, Boolean, DateTime, ForeignKey, Numeric, Integer, Text, Enum, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db import Base

def uid(): return str(uuid.uuid4())
def now(): return datetime.now(timezone.utc)

class Role(str, enum.Enum):
    CUSTOMER="customer"; SELLER="seller"; COURIER="courier"; ADMIN="admin"
class SellerStatus(str, enum.Enum): PENDING="pending"; APPROVED="approved"; SUSPENDED="suspended"
class OrderStatus(str, enum.Enum): PENDING="pending"; CONFIRMED="confirmed"; PROCESSING="processing"; READY="ready"; SHIPPED="shipped"; DELIVERED="delivered"; CANCELLED="cancelled"
class PaymentStatus(str, enum.Enum): CREATED="created"; PENDING="pending"; SUCCESS="success"; FAILED="failed"; REFUNDED="refunded"
class DeliveryStatus(str, enum.Enum): CREATED="created"; ASSIGNED="assigned"; PICKED_UP="picked_up"; IN_TRANSIT="in_transit"; DELIVERED="delivered"; FAILED="failed"

class User(Base):
    __tablename__="users"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    phone: Mapped[str]=mapped_column(String(32),unique=True,index=True)
    full_name: Mapped[str|None]=mapped_column(String(160),nullable=True)
    email: Mapped[str|None]=mapped_column(String(200),nullable=True,unique=True)
    is_active: Mapped[bool]=mapped_column(Boolean,default=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    roles: Mapped[list['UserRole']]=relationship(cascade="all, delete-orphan",back_populates="user")

class UserRole(Base):
    __tablename__="user_roles"
    __table_args__=(UniqueConstraint("user_id","role",name="uq_user_role"),)
    id: Mapped[int]=mapped_column(Integer,primary_key=True,autoincrement=True)
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id",ondelete="CASCADE"),index=True)
    role: Mapped[Role]=mapped_column(Enum(Role,name="role_enum"))
    user: Mapped[User]=relationship(back_populates="roles")

class OTPChallenge(Base):
    __tablename__="otp_challenges"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    phone: Mapped[str]=mapped_column(String(32),index=True)
    code_hash: Mapped[str]=mapped_column(String(128))
    attempts: Mapped[int]=mapped_column(Integer,default=0)
    expires_at: Mapped[datetime]=mapped_column(DateTime(timezone=True))
    consumed_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class SellerProfile(Base):
    __tablename__="seller_profiles"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id"),unique=True,index=True)
    legal_name: Mapped[str]=mapped_column(String(180))
    business_name: Mapped[str]=mapped_column(String(180))
    city: Mapped[str]=mapped_column(String(100))
    status: Mapped[SellerStatus]=mapped_column(Enum(SellerStatus,name="seller_status_enum"),default=SellerStatus.PENDING)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    store: Mapped['Store|None']=relationship(back_populates="seller",uselist=False,cascade="all, delete-orphan")

class Store(Base):
    __tablename__="stores"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    seller_id: Mapped[str]=mapped_column(ForeignKey("seller_profiles.id",ondelete="CASCADE"),unique=True,index=True)
    name: Mapped[str]=mapped_column(String(180))
    slug: Mapped[str]=mapped_column(String(180),unique=True,index=True)
    description: Mapped[str|None]=mapped_column(Text,nullable=True)
    is_active: Mapped[bool]=mapped_column(Boolean,default=True)
    seller: Mapped[SellerProfile]=relationship(back_populates="store")
    products: Mapped[list['Product']]=relationship(back_populates="store",cascade="all, delete-orphan")

class Product(Base):
    __tablename__="products"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    store_id: Mapped[str]=mapped_column(ForeignKey("stores.id",ondelete="CASCADE"),index=True)
    name: Mapped[str]=mapped_column(String(220),index=True)
    slug: Mapped[str]=mapped_column(String(220),unique=True,index=True)
    description: Mapped[str|None]=mapped_column(Text,nullable=True)
    category: Mapped[str]=mapped_column(String(100),index=True)
    price: Mapped[Decimal]=mapped_column(Numeric(12,2))
    currency: Mapped[str]=mapped_column(String(3),default="USD")
    stock_qty: Mapped[int]=mapped_column(Integer,default=0)
    image_url: Mapped[str|None]=mapped_column(Text,nullable=True)
    image_public_id: Mapped[str|None]=mapped_column(String(255),nullable=True)
    is_active: Mapped[bool]=mapped_column(Boolean,default=True)
    moderation_status: Mapped[str]=mapped_column(String(20),default="pending",index=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    store: Mapped[Store]=relationship(back_populates="products")

class Advertisement(Base):
    __tablename__="advertisements"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    title: Mapped[str]=mapped_column(String(180))
    body: Mapped[str|None]=mapped_column(Text,nullable=True)
    image_url: Mapped[str|None]=mapped_column(Text,nullable=True)
    image_public_id: Mapped[str|None]=mapped_column(String(255),nullable=True)
    link_url: Mapped[str|None]=mapped_column(Text,nullable=True)
    is_active: Mapped[bool]=mapped_column(Boolean,default=True,index=True)
    sort_order: Mapped[int]=mapped_column(Integer,default=0)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now)

class Conversation(Base):
    __tablename__="conversations"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    kind: Mapped[str]=mapped_column(String(32),index=True)  # customer_seller / admin_seller
    seller_id: Mapped[str|None]=mapped_column(ForeignKey("seller_profiles.id",ondelete="SET NULL"),nullable=True,index=True)
    seller_name: Mapped[str]=mapped_column(String(180))
    customer_id: Mapped[str|None]=mapped_column(ForeignKey("users.id",ondelete="SET NULL"),nullable=True,index=True)
    customer_name: Mapped[str|None]=mapped_column(String(180),nullable=True)
    subject: Mapped[str|None]=mapped_column(String(220),nullable=True)
    created_by_id: Mapped[str|None]=mapped_column(ForeignKey("users.id",ondelete="SET NULL"),nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now,index=True)

class ChatMessage(Base):
    __tablename__="chat_messages"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    conversation_id: Mapped[str]=mapped_column(ForeignKey("conversations.id",ondelete="CASCADE"),index=True)
    sender_id: Mapped[str|None]=mapped_column(ForeignKey("users.id",ondelete="SET NULL"),nullable=True,index=True)
    sender_role: Mapped[str]=mapped_column(String(32))
    body: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,index=True)

class Order(Base):
    __tablename__="orders"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    customer_id: Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    status: Mapped[OrderStatus]=mapped_column(Enum(OrderStatus,name="order_status_enum"),default=OrderStatus.PENDING)
    currency: Mapped[str]=mapped_column(String(3),default="USD")
    subtotal: Mapped[Decimal]=mapped_column(Numeric(12,2),default=0)
    delivery_fee: Mapped[Decimal]=mapped_column(Numeric(12,2),default=0)
    total: Mapped[Decimal]=mapped_column(Numeric(12,2),default=0)
    delivery_name: Mapped[str]=mapped_column(String(160))
    delivery_phone: Mapped[str]=mapped_column(String(32))
    delivery_address: Mapped[str]=mapped_column(Text)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    items: Mapped[list['OrderItem']]=relationship(cascade="all, delete-orphan",back_populates="order")
    payments: Mapped[list['Payment']]=relationship(cascade="all, delete-orphan",back_populates="order")
    delivery: Mapped['Delivery|None']=relationship(cascade="all, delete-orphan",back_populates="order",uselist=False)

class OrderItem(Base):
    __tablename__="order_items"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    order_id: Mapped[str]=mapped_column(ForeignKey("orders.id",ondelete="CASCADE"),index=True)
    product_id: Mapped[str|None]=mapped_column(ForeignKey("products.id",ondelete="SET NULL"),index=True,nullable=True)
    product_name: Mapped[str]=mapped_column(String(220))
    unit_price: Mapped[Decimal]=mapped_column(Numeric(12,2))
    quantity: Mapped[int]=mapped_column(Integer)
    line_total: Mapped[Decimal]=mapped_column(Numeric(12,2))
    order: Mapped[Order]=relationship(back_populates="items")

class Payment(Base):
    __tablename__="payments"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    order_id: Mapped[str]=mapped_column(ForeignKey("orders.id",ondelete="CASCADE"),index=True)
    provider: Mapped[str]=mapped_column(String(32),index=True)
    phone: Mapped[str]=mapped_column(String(32))
    amount: Mapped[Decimal]=mapped_column(Numeric(12,2))
    currency: Mapped[str]=mapped_column(String(3))
    status: Mapped[PaymentStatus]=mapped_column(Enum(PaymentStatus,name="payment_status_enum"),default=PaymentStatus.CREATED)
    provider_reference: Mapped[str|None]=mapped_column(String(200),nullable=True,index=True)
    raw_response: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now)
    order: Mapped[Order]=relationship(back_populates="payments")

class Delivery(Base):
    __tablename__="deliveries"
    id: Mapped[str]=mapped_column(String(36),primary_key=True,default=uid)
    order_id: Mapped[str]=mapped_column(ForeignKey("orders.id",ondelete="CASCADE"),unique=True,index=True)
    courier_id: Mapped[str|None]=mapped_column(ForeignKey("users.id"),nullable=True,index=True)
    status: Mapped[DeliveryStatus]=mapped_column(Enum(DeliveryStatus,name="delivery_status_enum"),default=DeliveryStatus.CREATED)
    pickup_note: Mapped[str|None]=mapped_column(Text,nullable=True)
    delivered_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True),nullable=True)
    order: Mapped[Order]=relationship(back_populates="delivery")
