from decimal import Decimal
from app.db import SessionLocal
from app.models import User, UserRole, Role, SellerProfile, SellerStatus, Store, Product

PRODUCTS = [
    ("Abreuvoir compact pour volailles", "abreuvoir-compact-volailles", "Élevage", "12", 24, "Abreuvoir pratique et robuste, adapté aux petits et moyens élevages."),
    ("Mangeoire grande capacité", "mangeoire-grande-capacite", "Élevage", "28", 18, "Mangeoire stable à grande capacité pour réduire les pertes d’aliments."),
    ("Mangeoire moyenne croissance", "mangeoire-moyenne-croissance", "Élevage", "22", 31, "Équipement de nourrissage fiable pour accompagner la croissance des poules."),
    ("Abreuvoir rouge renforcé", "abreuvoir-rouge-renforce", "Élevage", "19", 20, "Abreuvoir renforcé, facile à nettoyer et durable."),
]

def run():
    db=SessionLocal()
    try:
        if db.query(Product).count():
            print("Seed skipped: products already exist")
            return
        u=User(phone="+243999000001",full_name="Poules Élevage — Mundu ku Gundi")
        db.add(u); db.flush()
        db.add_all([UserRole(user_id=u.id,role=Role.CUSTOMER),UserRole(user_id=u.id,role=Role.SELLER)])
        s=SellerProfile(user_id=u.id,legal_name="Ets Mundu ku Gundi W4F",business_name="Poules Élevage",city="Bukavu",status=SellerStatus.APPROVED)
        db.add(s); db.flush()
        st=Store(seller_id=s.id,name=s.business_name,slug="poules-elevage-bukavu",description="Équipements pratiques pour un élevage sain, rentable et durable.")
        db.add(st); db.flush()
        for name,slug,category,price,stock,description in PRODUCTS:
            db.add(Product(store_id=st.id,name=name,slug=slug,description=description,category=category,price=Decimal(price),currency="USD",stock_qty=stock))
        db.commit(); print("M'MEDPREN seed data created: Poules Élevage")
    finally:
        db.close()

if __name__=="__main__": run()
