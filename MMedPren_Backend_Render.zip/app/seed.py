from decimal import Decimal
from app.config import settings
from app.db import SessionLocal
from app.models import User, UserRole, Role, SellerProfile, SellerStatus, Store, Product
from app.utils import normalize_phone

PRODUCTS = [
    ("Abreuvoir compact pour volailles", "abreuvoir-compact-volailles", "Élevage", "12", 24, "Abreuvoir pratique et robuste, adapté aux petits et moyens élevages."),
    ("Mangeoire grande capacité", "mangeoire-grande-capacite", "Élevage", "28", 18, "Mangeoire stable à grande capacité pour réduire les pertes d’aliments."),
    ("Mangeoire moyenne croissance", "mangeoire-moyenne-croissance", "Élevage", "22", 31, "Équipement de nourrissage fiable pour accompagner la croissance des poules."),
    ("Abreuvoir rouge renforcé", "abreuvoir-rouge-renforce", "Élevage", "19", 20, "Abreuvoir renforcé, facile à nettoyer et durable."),
]

def _ensure_role(db,user_id,role):
    if not db.query(UserRole).filter(UserRole.user_id==user_id,UserRole.role==role).first(): db.add(UserRole(user_id=user_id,role=role))

def ensure_initial_store_owner(db):
    raw=(settings.owner_phone or '').strip()
    if not raw: return
    try: phone=normalize_phone(raw)
    except Exception: phone=raw
    owner=db.query(User).filter(User.phone==phone).first()
    initial_store=db.query(Store).filter(Store.slug=='poules-elevage-bukavu').first()
    if not owner or not initial_store or not initial_store.seller: return
    initial_seller=initial_store.seller
    if initial_seller.user_id==owner.id:
        _ensure_role(db,owner.id,Role.SELLER); db.commit(); return
    existing=db.query(SellerProfile).filter(SellerProfile.user_id==owner.id).first()
    if existing and existing.id!=initial_seller.id:
        # Preserve every product the owner may already have by moving it into the initial shop.
        if existing.store:
            for p in list(existing.store.products): p.store=initial_store
        db.flush()
        db.delete(existing); db.flush()
    old_user_id=initial_seller.user_id
    initial_seller.user_id=owner.id
    initial_seller.status=SellerStatus.APPROVED
    initial_store.is_active=True
    _ensure_role(db,owner.id,Role.SELLER)
    old_role=db.query(UserRole).filter(UserRole.user_id==old_user_id,UserRole.role==Role.SELLER).first()
    if old_role: db.delete(old_role)
    db.commit()
    print("Initial Poules Élevage store assigned to OWNER_PHONE")

def run():
    db=SessionLocal()
    try:
        if not db.query(Product).count():
            u=User(phone="+243999000001",full_name="Poules Élevage — Mundu ku Gundi")
            db.add(u); db.flush(); _ensure_role(db,u.id,Role.CUSTOMER); _ensure_role(db,u.id,Role.SELLER)
            s=SellerProfile(user_id=u.id,legal_name="Ets Mundu ku Gundi W4F",business_name="Poules Élevage",city="Bukavu",status=SellerStatus.APPROVED)
            db.add(s); db.flush()
            st=Store(seller_id=s.id,name=s.business_name,slug="poules-elevage-bukavu",description="Équipements pratiques pour un élevage sain, rentable et durable.")
            db.add(st); db.flush()
            for name,slug,category,price,stock,description in PRODUCTS:
                db.add(Product(store_id=st.id,name=name,slug=slug,description=description,category=category,price=Decimal(price),currency="USD",stock_qty=stock,moderation_status="approved"))
            db.commit(); print("M'MEDPREN seed data created: Poules Élevage")
        ensure_initial_store_owner(db)
    finally: db.close()

if __name__=="__main__": run()
