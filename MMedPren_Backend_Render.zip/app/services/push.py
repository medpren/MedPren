from __future__ import annotations
import json
from sqlalchemy.orm import Session
from app.config import settings
from app.models import PushSubscription


def _payload(title: str, body: str | None, entity_type: str | None, entity_id: str | None):
    return json.dumps({
        "title": title,
        "body": body or "Nouvelle activité M’MEDPREN",
        "entity_type": entity_type,
        "entity_id": entity_id,
        "url": "./",
    }, ensure_ascii=False)


def send_push_to_user(db: Session, user_id: str | None, title: str, body: str | None = None,
                      entity_type: str | None = None, entity_id: str | None = None) -> int:
    """Best-effort Web Push. Never makes the business transaction fail."""
    if not user_id or not settings.push_configured:
        return 0
    try:
        from pywebpush import webpush, WebPushException
    except Exception:
        return 0
    rows = db.query(PushSubscription).filter(PushSubscription.user_id == user_id).all()
    sent = 0
    stale = []
    data = _payload(title, body, entity_type, entity_id)
    for sub in rows:
        try:
            webpush(
                subscription_info={
                    "endpoint": sub.endpoint,
                    "keys": {"p256dh": sub.p256dh, "auth": sub.auth},
                },
                data=data,
                vapid_private_key=settings.vapid_private_key,
                vapid_claims={"sub": settings.vapid_subject},
                timeout=6,
                ttl=86400,
            )
            sent += 1
        except WebPushException as exc:
            code = getattr(getattr(exc, "response", None), "status_code", None)
            if code in (404, 410):
                stale.append(sub)
        except Exception:
            continue
    for sub in stale:
        try: db.delete(sub)
        except Exception: pass
    return sent
