from sqlalchemy.orm import Session
from app.models import Notification, Role, User, UserRole


def add_notification(db: Session, user_id: str | None, kind: str, title: str, body: str | None = None, entity_type: str | None = None, entity_id: str | None = None):
    if not user_id:
        return None
    n = Notification(user_id=user_id, kind=kind, title=title, body=body, entity_type=entity_type, entity_id=entity_id)
    db.add(n)
    return n


def admin_user_ids(db: Session):
    rows = (db.query(UserRole.user_id)
            .filter(UserRole.role == Role.ADMIN)
            .distinct().all())
    return [r[0] for r in rows]


def notify_admins(db: Session, kind: str, title: str, body: str | None = None, entity_type: str | None = None, entity_id: str | None = None, exclude_user_id: str | None = None):
    seen=set()
    for uid in admin_user_ids(db):
        if uid == exclude_user_id or uid in seen:
            continue
        seen.add(uid)
        add_notification(db, uid, kind, title, body, entity_type, entity_id)


def notify_many(db: Session, user_ids, kind: str, title: str, body: str | None = None, entity_type: str | None = None, entity_id: str | None = None, exclude_user_id: str | None = None):
    seen=set()
    for uid in user_ids:
        if not uid or uid == exclude_user_id or uid in seen:
            continue
        seen.add(uid)
        add_notification(db, uid, kind, title, body, entity_type, entity_id)
