import httpx
from app.config import settings
class OTPProvider:
    def send(self, phone:str, code:str): raise NotImplementedError
class ConsoleOTPProvider(OTPProvider):
    def send(self, phone:str, code:str): print(f"[DEV OTP] {phone}: {code}")
class HttpOTPProvider(OTPProvider):
    def send(self, phone:str, code:str):
        if not settings.otp_http_url: raise RuntimeError("OTP_HTTP_URL is not configured")
        headers={"Content-Type":"application/json"}
        if settings.otp_http_token: headers["Authorization"]=f"Bearer {settings.otp_http_token}"
        r=httpx.post(settings.otp_http_url,json={"phone":phone,"code":code,"message":f"Votre code M'MEDPREN est {code}"},headers=headers,timeout=15)
        r.raise_for_status()
def get_otp_provider():
    if settings.otp_provider=="console": return ConsoleOTPProvider()
    if settings.otp_provider=="http": return HttpOTPProvider()
    raise RuntimeError(f"Unknown OTP provider: {settings.otp_provider}")
