from dataclasses import dataclass
from decimal import Decimal
@dataclass
class PaymentResult:
    reference:str
    status:str
    raw:dict
class PaymentProvider:
    code="base"
    def collect(self, *, phone:str, amount:Decimal, currency:str, external_id:str, callback_url:str)->PaymentResult: raise NotImplementedError
