import uuid
from .base import PaymentProvider, PaymentResult
class SandboxProvider(PaymentProvider):
    code="sandbox"
    def collect(self, **kwargs): return PaymentResult(reference=f"sandbox-{uuid.uuid4()}",status="pending",raw={"mode":"sandbox","request":{k:str(v) for k,v in kwargs.items() if k!='callback_url'}})
