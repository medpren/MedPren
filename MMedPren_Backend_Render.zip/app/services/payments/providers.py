import httpx
from fastapi import HTTPException
from app.config import settings
from .base import PaymentProvider, PaymentResult
from .sandbox import SandboxProvider

class ConfiguredHTTPProvider(PaymentProvider):
    required=()
    def configured(self): return all(getattr(settings,k) for k in self.required)
    def assert_configured(self):
        if not self.configured(): raise HTTPException(status_code=503,detail=f"{self.code} merchant credentials are not configured")

class MPesaProvider(ConfiguredHTTPProvider):
    code="mpesa"
    required=("mpesa_base_url","mpesa_api_key","mpesa_service_provider_code")
    def collect(self, **kwargs):
        self.assert_configured()
        # Endpoint/body vary according to the Vodacom DRC merchant product enabled on the Business portal.
        # Keep the provider-specific contract here; do not expose credentials to clients.
        raise HTTPException(status_code=501,detail="M-Pesa credentials detected, but map your Vodacom DRC C2B contract endpoint/body in MPesaProvider.collect before production")

class AirtelProvider(ConfiguredHTTPProvider):
    code="airtel"
    required=("airtel_base_url","airtel_client_id","airtel_client_secret")
    def collect(self, **kwargs):
        self.assert_configured()
        raise HTTPException(status_code=501,detail="Map the collection endpoint issued to your Airtel DRC application in AirtelProvider.collect")

class OrangeProvider(ConfiguredHTTPProvider):
    code="orange"
    required=("orange_base_url","orange_client_id","orange_client_secret","orange_merchant_key")
    def collect(self, **kwargs):
        self.assert_configured()
        raise HTTPException(status_code=501,detail="Map the Orange Money product enabled for your merchant account in OrangeProvider.collect")

PROVIDERS={"sandbox":SandboxProvider(),"mpesa":MPesaProvider(),"airtel":AirtelProvider(),"orange":OrangeProvider()}
def get_payment_provider(code:str):
    p=PROVIDERS.get(code)
    if not p: raise HTTPException(status_code=422,detail="Unknown payment provider")
    return p
