from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from urllib.parse import unquote, urlparse

import httpx

from app.config import settings


class ImageStorageError(RuntimeError):
    pass


class ImageStorageNotConfigured(ImageStorageError):
    pass


@dataclass(frozen=True)
class CloudinaryCredentials:
    cloud_name: str
    api_key: str
    api_secret: str


def _credentials() -> CloudinaryCredentials:
    raw = (settings.cloudinary_url or "").strip()
    if not raw:
        raise ImageStorageNotConfigured(
            "Image storage is not configured. Set CLOUDINARY_URL on the server."
        )
    parsed = urlparse(raw)
    if parsed.scheme != "cloudinary" or not parsed.hostname or not parsed.username or not parsed.password:
        raise ImageStorageNotConfigured("CLOUDINARY_URL is invalid.")
    return CloudinaryCredentials(
        cloud_name=parsed.hostname,
        api_key=unquote(parsed.username),
        api_secret=unquote(parsed.password),
    )


def _signature(params: dict[str, object], api_secret: str) -> str:
    payload = "&".join(f"{key}={params[key]}" for key in sorted(params) if params[key] is not None)
    return hashlib.sha1(f"{payload}{api_secret}".encode("utf-8")).hexdigest()


def detect_image_mime(data: bytes) -> str | None:
    if len(data) >= 3 and data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if len(data) >= 8 and data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


async def upload_image(data: bytes, filename: str, content_type: str) -> dict[str, str]:
    creds = _credentials()
    timestamp = int(time.time())
    signed_params = {
        "folder": settings.cloudinary_folder,
        "timestamp": timestamp,
    }
    request_data = {
        **signed_params,
        "api_key": creds.api_key,
        "signature": _signature(signed_params, creds.api_secret),
    }
    upload_url = f"https://api.cloudinary.com/v1_1/{creds.cloud_name}/image/upload"
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(35.0, connect=10.0)) as client:
            response = await client.post(
                upload_url,
                data=request_data,
                files={"file": (filename, data, content_type)},
            )
    except httpx.HTTPError as exc:
        raise ImageStorageError("Image storage is temporarily unreachable.") from exc

    if response.status_code >= 400:
        detail = ""
        try:
            detail = response.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise ImageStorageError(detail or "Image upload failed.")

    payload = response.json()
    secure_url = payload.get("secure_url")
    public_id = payload.get("public_id")
    if not secure_url or not public_id:
        raise ImageStorageError("Image storage returned an incomplete response.")
    return {"url": secure_url, "public_id": public_id}


async def delete_image(public_id: str | None) -> None:
    if not public_id:
        return
    try:
        creds = _credentials()
    except ImageStorageNotConfigured:
        return

    timestamp = int(time.time())
    signed_params = {"public_id": public_id, "timestamp": timestamp}
    request_data = {
        **signed_params,
        "api_key": creds.api_key,
        "signature": _signature(signed_params, creds.api_secret),
    }
    destroy_url = f"https://api.cloudinary.com/v1_1/{creds.cloud_name}/image/destroy"
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(20.0, connect=8.0)) as client:
            await client.post(destroy_url, data=request_data)
    except httpx.HTTPError:
        # Deletion failure must not break the product update path.
        return
