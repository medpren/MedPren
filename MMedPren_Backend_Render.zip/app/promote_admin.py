import sys
from app.db import SessionLocal
from app.models import User, UserRole, Role
from app.utils import normalize_phone
from app.deps import role_names
if len(sys.argv)!=2: raise SystemExit("Usage: python -m app.promote_admin +243...")
db=SessionLocal(); phone=normalize_phone(sys.argv[1]); u=db.query(User).filter(User.phone==phone).first()
if not u: raise SystemExit("User not found. Login once first.")
if Role.ADMIN.value not in role_names(u): db.add(UserRole(user_id=u.id,role=Role.ADMIN)); db.commit()
print(f"Admin enabled for {phone}")
