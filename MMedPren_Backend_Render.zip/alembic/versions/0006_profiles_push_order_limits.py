"""profiles, push notifications, order limits and cancellation audit

Revision ID: 0006_profiles_push_order_limits
Revises: 0005_notifications
"""
from alembic import op
import sqlalchemy as sa

revision="0006_profiles_push_order_limits"
down_revision="0005_notifications"
branch_labels=None
depends_on=None

def _cols(bind, table):
    return {c['name'] for c in sa.inspect(bind).get_columns(table)}

def upgrade():
    bind=op.get_bind(); insp=sa.inspect(bind); tables=set(insp.get_table_names())
    users=_cols(bind,'users')
    if 'whatsapp_phone' not in users: op.add_column('users',sa.Column('whatsapp_phone',sa.String(length=32),nullable=True))
    if 'profile_kind' not in users: op.add_column('users',sa.Column('profile_kind',sa.String(length=20),nullable=False,server_default='personal'))
    if 'profile_image_url' not in users: op.add_column('users',sa.Column('profile_image_url',sa.Text(),nullable=True))
    if 'profile_image_public_id' not in users: op.add_column('users',sa.Column('profile_image_public_id',sa.String(length=255),nullable=True))

    stores=_cols(bind,'stores')
    if 'logo_url' not in stores: op.add_column('stores',sa.Column('logo_url',sa.Text(),nullable=True))
    if 'logo_public_id' not in stores: op.add_column('stores',sa.Column('logo_public_id',sa.String(length=255),nullable=True))

    products=_cols(bind,'products')
    if 'min_order_qty' not in products: op.add_column('products',sa.Column('min_order_qty',sa.Integer(),nullable=False,server_default='1'))
    if 'max_order_qty' not in products: op.add_column('products',sa.Column('max_order_qty',sa.Integer(),nullable=False,server_default='100'))
    op.execute("UPDATE products SET min_order_qty=1 WHERE min_order_qty IS NULL OR min_order_qty < 1")
    op.execute("UPDATE products SET max_order_qty=CASE WHEN stock_qty > 0 THEN stock_qty ELSE 1 END WHERE max_order_qty IS NULL OR max_order_qty < 1")

    orders=_cols(bind,'orders')
    if 'cancelled_at' not in orders: op.add_column('orders',sa.Column('cancelled_at',sa.DateTime(timezone=True),nullable=True))
    if 'cancelled_by_id' not in orders:
        op.add_column('orders',sa.Column('cancelled_by_id',sa.String(length=36),nullable=True))
        op.create_foreign_key('fk_orders_cancelled_by_id_users','orders','users',['cancelled_by_id'],['id'],ondelete='SET NULL')
        op.create_index('ix_orders_cancelled_by_id','orders',['cancelled_by_id'],unique=False)
    if 'cancellation_reason' not in orders: op.add_column('orders',sa.Column('cancellation_reason',sa.Text(),nullable=True))

    if 'push_subscriptions' not in tables:
        op.create_table('push_subscriptions',
            sa.Column('id',sa.String(length=36),primary_key=True),
            sa.Column('user_id',sa.String(length=36),nullable=False),
            sa.Column('endpoint',sa.Text(),nullable=False,unique=True),
            sa.Column('p256dh',sa.Text(),nullable=False),
            sa.Column('auth',sa.Text(),nullable=False),
            sa.Column('user_agent',sa.Text(),nullable=True),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
            sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(['user_id'],['users.id'],ondelete='CASCADE'),
        )
        op.create_index('ix_push_subscriptions_user_id','push_subscriptions',['user_id'],unique=False)

def downgrade():
    bind=op.get_bind(); tables=set(sa.inspect(bind).get_table_names())
    if 'push_subscriptions' in tables: op.drop_table('push_subscriptions')
    # keep added columns during downgrade to preserve user and business data
