"""ads chat and product moderation

Revision ID: 0004_ads_chat_moderation_owner
Revises: 0003_admin_catalogue_lifecycle
"""
from alembic import op
import sqlalchemy as sa

revision="0004_ads_chat_moderation_owner"
down_revision="0003_admin_catalogue_lifecycle"
branch_labels=None
depends_on=None

def upgrade():
    bind=op.get_bind(); insp=sa.inspect(bind)
    cols={c['name'] for c in insp.get_columns('products')}
    if 'moderation_status' not in cols:
        op.add_column('products',sa.Column('moderation_status',sa.String(length=20),nullable=False,server_default='approved'))
        op.create_index('ix_products_moderation_status','products',['moderation_status'],unique=False)
        op.execute("UPDATE products SET moderation_status='approved' WHERE moderation_status IS NULL OR moderation_status='' ")

    tables=set(insp.get_table_names())
    if 'advertisements' not in tables:
        op.create_table('advertisements',
            sa.Column('id',sa.String(length=36),primary_key=True),
            sa.Column('title',sa.String(length=180),nullable=False),
            sa.Column('body',sa.Text(),nullable=True),
            sa.Column('image_url',sa.Text(),nullable=True),
            sa.Column('image_public_id',sa.String(length=255),nullable=True),
            sa.Column('link_url',sa.Text(),nullable=True),
            sa.Column('is_active',sa.Boolean(),nullable=False,server_default=sa.true()),
            sa.Column('sort_order',sa.Integer(),nullable=False,server_default='0'),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
            sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
        )
        op.create_index('ix_advertisements_is_active','advertisements',['is_active'],unique=False)

    if 'conversations' not in tables:
        op.create_table('conversations',
            sa.Column('id',sa.String(length=36),primary_key=True),
            sa.Column('kind',sa.String(length=32),nullable=False),
            sa.Column('seller_id',sa.String(length=36),nullable=True),
            sa.Column('seller_name',sa.String(length=180),nullable=False),
            sa.Column('customer_id',sa.String(length=36),nullable=True),
            sa.Column('customer_name',sa.String(length=180),nullable=True),
            sa.Column('subject',sa.String(length=220),nullable=True),
            sa.Column('created_by_id',sa.String(length=36),nullable=True),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
            sa.Column('updated_at',sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(['seller_id'],['seller_profiles.id'],ondelete='SET NULL'),
            sa.ForeignKeyConstraint(['customer_id'],['users.id'],ondelete='SET NULL'),
            sa.ForeignKeyConstraint(['created_by_id'],['users.id'],ondelete='SET NULL'),
        )
        op.create_index('ix_conversations_kind','conversations',['kind'],unique=False)
        op.create_index('ix_conversations_seller_id','conversations',['seller_id'],unique=False)
        op.create_index('ix_conversations_customer_id','conversations',['customer_id'],unique=False)
        op.create_index('ix_conversations_updated_at','conversations',['updated_at'],unique=False)

    tables=set(sa.inspect(bind).get_table_names())
    if 'chat_messages' not in tables:
        op.create_table('chat_messages',
            sa.Column('id',sa.String(length=36),primary_key=True),
            sa.Column('conversation_id',sa.String(length=36),nullable=False),
            sa.Column('sender_id',sa.String(length=36),nullable=True),
            sa.Column('sender_role',sa.String(length=32),nullable=False),
            sa.Column('body',sa.Text(),nullable=False),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(['conversation_id'],['conversations.id'],ondelete='CASCADE'),
            sa.ForeignKeyConstraint(['sender_id'],['users.id'],ondelete='SET NULL'),
        )
        op.create_index('ix_chat_messages_conversation_id','chat_messages',['conversation_id'],unique=False)
        op.create_index('ix_chat_messages_sender_id','chat_messages',['sender_id'],unique=False)
        op.create_index('ix_chat_messages_created_at','chat_messages',['created_at'],unique=False)

def downgrade():
    op.drop_table('chat_messages')
    op.drop_table('conversations')
    op.drop_table('advertisements')
    # keep moderation_status for safe downgrade / data preservation
