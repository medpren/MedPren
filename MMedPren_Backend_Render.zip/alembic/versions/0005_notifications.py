"""persistent notifications

Revision ID: 0005_notifications
Revises: 0004_ads_chat_moderation_owner
"""
from alembic import op
import sqlalchemy as sa

revision="0005_notifications"
down_revision="0004_ads_chat_moderation_owner"
branch_labels=None
depends_on=None

def upgrade():
    bind=op.get_bind(); insp=sa.inspect(bind)
    if 'notifications' not in set(insp.get_table_names()):
        op.create_table('notifications',
            sa.Column('id',sa.String(length=36),primary_key=True),
            sa.Column('user_id',sa.String(length=36),nullable=True),
            sa.Column('kind',sa.String(length=48),nullable=False),
            sa.Column('title',sa.String(length=220),nullable=False),
            sa.Column('body',sa.Text(),nullable=True),
            sa.Column('entity_type',sa.String(length=48),nullable=True),
            sa.Column('entity_id',sa.String(length=64),nullable=True),
            sa.Column('is_read',sa.Boolean(),nullable=False,server_default=sa.false()),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(['user_id'],['users.id'],ondelete='CASCADE'),
        )
        op.create_index('ix_notifications_user_id','notifications',['user_id'],unique=False)
        op.create_index('ix_notifications_kind','notifications',['kind'],unique=False)
        op.create_index('ix_notifications_entity_type','notifications',['entity_type'],unique=False)
        op.create_index('ix_notifications_entity_id','notifications',['entity_id'],unique=False)
        op.create_index('ix_notifications_is_read','notifications',['is_read'],unique=False)
        op.create_index('ix_notifications_created_at','notifications',['created_at'],unique=False)

def downgrade():
    op.drop_table('notifications')
