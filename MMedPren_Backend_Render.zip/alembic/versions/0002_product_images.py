"""add product image storage fields

Revision ID: 0002_product_images
Revises: 0001_initial
"""
from alembic import op
import sqlalchemy as sa

revision = "0002_product_images"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def _columns() -> set[str]:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    return {col["name"] for col in inspector.get_columns("products")}


def upgrade():
    columns = _columns()
    # 0001_initial uses Base.metadata.create_all(). On a brand-new database it can
    # already see the current model definition, so this migration intentionally
    # checks for each column before adding it. On the existing Render database,
    # where 0001 ran before V3.2, the fields are added normally.
    if "image_url" not in columns:
        op.add_column("products", sa.Column("image_url", sa.Text(), nullable=True))
    if "image_public_id" not in columns:
        op.add_column("products", sa.Column("image_public_id", sa.String(length=255), nullable=True))


def downgrade():
    columns = _columns()
    if "image_public_id" in columns:
        op.drop_column("products", "image_public_id")
    if "image_url" in columns:
        op.drop_column("products", "image_url")
