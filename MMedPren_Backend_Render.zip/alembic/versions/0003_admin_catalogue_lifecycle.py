"""allow hard deletion of products while preserving order history

Revision ID: 0003_admin_catalogue_lifecycle
Revises: 0002_product_images
"""
from alembic import op
import sqlalchemy as sa

revision = "0003_admin_catalogue_lifecycle"
down_revision = "0002_product_images"
branch_labels = None
depends_on = None


def _product_fk():
    inspector = sa.inspect(op.get_bind())
    for fk in inspector.get_foreign_keys("order_items"):
        if fk.get("constrained_columns") == ["product_id"]:
            return fk
    return None


def _product_column():
    inspector = sa.inspect(op.get_bind())
    for col in inspector.get_columns("order_items"):
        if col["name"] == "product_id":
            return col
    return None


def upgrade():
    bind = op.get_bind()
    fk = _product_fk()
    col = _product_column()
    current_ondelete = ((fk or {}).get("options") or {}).get("ondelete")
    already_set_null = str(current_ondelete or "").upper() == "SET NULL"
    already_nullable = bool(col and col.get("nullable"))
    if already_set_null and already_nullable:
        return

    if bind.dialect.name == "sqlite":
        with op.batch_alter_table("order_items", recreate="always") as batch:
            if fk and fk.get("name"):
                batch.drop_constraint(fk["name"], type_="foreignkey")
            batch.alter_column("product_id", existing_type=sa.String(length=36), nullable=True)
            batch.create_foreign_key(
                "fk_order_items_product_id_products",
                "products",
                ["product_id"],
                ["id"],
                ondelete="SET NULL",
            )
        return

    if fk and fk.get("name"):
        op.drop_constraint(fk["name"], "order_items", type_="foreignkey")
    op.alter_column("order_items", "product_id", existing_type=sa.String(length=36), nullable=True)
    op.create_foreign_key(
        "fk_order_items_product_id_products",
        "order_items",
        "products",
        ["product_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade():
    # A deleted product can leave historical order_items.product_id as NULL.
    # We therefore keep the safer nullable/SET NULL contract on downgrade rather
    # than destroying order history or failing on existing rows.
    pass
