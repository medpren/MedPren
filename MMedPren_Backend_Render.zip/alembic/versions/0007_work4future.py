"""Work4Future profiles, opportunities, applications and trainings

Revision ID: 0007_work4future
Revises: 0006_profiles_push_order_limits
"""
from alembic import op
import sqlalchemy as sa

revision = "0007_work4future"
down_revision = "0006_profiles_push_order_limits"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind(); tables = set(sa.inspect(bind).get_table_names())
    if "work_profiles" not in tables:
        op.create_table("work_profiles",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("user_id", sa.String(36), nullable=False, unique=True),
            sa.Column("headline", sa.String(180), nullable=True),
            sa.Column("skills", sa.Text(), nullable=True),
            sa.Column("city", sa.String(120), nullable=True),
            sa.Column("bio", sa.Text(), nullable=True),
            sa.Column("experience", sa.Text(), nullable=True),
            sa.Column("education", sa.Text(), nullable=True),
            sa.Column("availability", sa.String(100), nullable=True),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
            sa.ForeignKeyConstraint(["user_id"],["users.id"],ondelete="CASCADE"),
        ); op.create_index("ix_work_profiles_user_id","work_profiles",["user_id"],unique=True)
    if "work_opportunities" not in tables:
        op.create_table("work_opportunities",
            sa.Column("id",sa.String(36),primary_key=True),sa.Column("kind",sa.String(32),nullable=False),
            sa.Column("title",sa.String(220),nullable=False),sa.Column("organization",sa.String(220),nullable=False),
            sa.Column("location",sa.String(160),nullable=True),sa.Column("work_mode",sa.String(64),nullable=True),
            sa.Column("contract_type",sa.String(80),nullable=True),sa.Column("salary_text",sa.String(120),nullable=True),
            sa.Column("description",sa.Text(),nullable=False),sa.Column("requirements",sa.Text(),nullable=True),
            sa.Column("application_url",sa.Text(),nullable=True),sa.Column("contact_email",sa.String(200),nullable=True),
            sa.Column("deadline_at",sa.DateTime(timezone=True),nullable=True),sa.Column("is_active",sa.Boolean(),nullable=False,server_default=sa.true()),
            sa.Column("is_featured",sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column("created_by_id",sa.String(36),nullable=True),
            sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(["created_by_id"],["users.id"],ondelete="SET NULL"),
        )
        for name,col in [("kind","kind"),("title","title"),("organization","organization"),("location","location"),("deadline_at","deadline_at"),("is_active","is_active"),("is_featured","is_featured"),("created_by_id","created_by_id"),("created_at","created_at")]:
            op.create_index(f"ix_work_opportunities_{name}","work_opportunities",[col],unique=False)
    if "work_applications" not in tables:
        op.create_table("work_applications",
            sa.Column("id",sa.String(36),primary_key=True),sa.Column("opportunity_id",sa.String(36),nullable=False),sa.Column("user_id",sa.String(36),nullable=False),
            sa.Column("motivation",sa.Text(),nullable=True),sa.Column("status",sa.String(32),nullable=False,server_default="submitted"),sa.Column("admin_note",sa.Text(),nullable=True),
            sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(["opportunity_id"],["work_opportunities.id"],ondelete="CASCADE"),sa.ForeignKeyConstraint(["user_id"],["users.id"],ondelete="CASCADE"),
            sa.UniqueConstraint("opportunity_id","user_id",name="uq_work_application_user_opportunity"),
        ); op.create_index("ix_work_applications_opportunity_id","work_applications",["opportunity_id"]); op.create_index("ix_work_applications_user_id","work_applications",["user_id"]); op.create_index("ix_work_applications_status","work_applications",["status"]); op.create_index("ix_work_applications_created_at","work_applications",["created_at"])
    if "work_trainings" not in tables:
        op.create_table("work_trainings",
            sa.Column("id",sa.String(36),primary_key=True),sa.Column("title",sa.String(220),nullable=False),sa.Column("provider",sa.String(220),nullable=False),
            sa.Column("category",sa.String(100),nullable=True),sa.Column("mode",sa.String(64),nullable=True),sa.Column("location",sa.String(160),nullable=True),
            sa.Column("level",sa.String(80),nullable=True),sa.Column("duration_text",sa.String(100),nullable=True),sa.Column("fee_text",sa.String(100),nullable=True),
            sa.Column("description",sa.Text(),nullable=False),sa.Column("prerequisites",sa.Text(),nullable=True),sa.Column("external_url",sa.Text(),nullable=True),
            sa.Column("start_at",sa.DateTime(timezone=True),nullable=True),sa.Column("deadline_at",sa.DateTime(timezone=True),nullable=True),sa.Column("capacity",sa.Integer(),nullable=True),
            sa.Column("is_active",sa.Boolean(),nullable=False,server_default=sa.true()),sa.Column("is_featured",sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column("created_by_id",sa.String(36),nullable=True),
            sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(["created_by_id"],["users.id"],ondelete="SET NULL"),
        )
        for name in ["title","provider","category","deadline_at","is_active","is_featured","created_by_id","created_at"]: op.create_index(f"ix_work_trainings_{name}","work_trainings",[name])
    if "work_enrollments" not in tables:
        op.create_table("work_enrollments",
            sa.Column("id",sa.String(36),primary_key=True),sa.Column("training_id",sa.String(36),nullable=False),sa.Column("user_id",sa.String(36),nullable=False),
            sa.Column("status",sa.String(32),nullable=False,server_default="registered"),sa.Column("note",sa.Text(),nullable=True),sa.Column("admin_note",sa.Text(),nullable=True),
            sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),sa.Column("updated_at",sa.DateTime(timezone=True),nullable=False),
            sa.ForeignKeyConstraint(["training_id"],["work_trainings.id"],ondelete="CASCADE"),sa.ForeignKeyConstraint(["user_id"],["users.id"],ondelete="CASCADE"),
            sa.UniqueConstraint("training_id","user_id",name="uq_work_enrollment_user_training"),
        ); op.create_index("ix_work_enrollments_training_id","work_enrollments",["training_id"]); op.create_index("ix_work_enrollments_user_id","work_enrollments",["user_id"]); op.create_index("ix_work_enrollments_status","work_enrollments",["status"]); op.create_index("ix_work_enrollments_created_at","work_enrollments",["created_at"])


def downgrade():
    for table in ["work_enrollments","work_trainings","work_applications","work_opportunities","work_profiles"]:
        if table in set(sa.inspect(op.get_bind()).get_table_names()): op.drop_table(table)
