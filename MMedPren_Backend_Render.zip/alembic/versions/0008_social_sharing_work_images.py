"""Social sharing and images for Work4Future cards

Revision ID: 0008_social_sharing_work_images
Revises: 0007_work4future
"""
from alembic import op
import sqlalchemy as sa

revision = "0008_social_sharing_work_images"
down_revision = "0007_work4future"
branch_labels = None
depends_on = None


def _cols(table: str):
    bind = op.get_bind()
    return {c["name"] for c in sa.inspect(bind).get_columns(table)}


def upgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    for table in ("work_opportunities", "work_trainings"):
        if table not in tables:
            continue
        cols = _cols(table)
        if "image_url" not in cols:
            op.add_column(table, sa.Column("image_url", sa.Text(), nullable=True))
        cols = _cols(table)
        if "image_public_id" not in cols:
            op.add_column(table, sa.Column("image_public_id", sa.String(255), nullable=True))


def downgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    for table in ("work_trainings", "work_opportunities"):
        if table not in tables:
            continue
        cols = _cols(table)
        if "image_public_id" in cols:
            op.drop_column(table, "image_public_id")
        cols = _cols(table)
        if "image_url" in cols:
            op.drop_column(table, "image_url")
