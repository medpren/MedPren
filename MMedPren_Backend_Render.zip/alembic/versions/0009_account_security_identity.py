"""Account identities, password security and social login readiness

Revision ID: 0009_account_security_identity
Revises: 0008_social_sharing_work_images
"""
from alembic import op
import sqlalchemy as sa

revision = "0009_account_security_identity"
down_revision = "0008_social_sharing_work_images"
branch_labels = None
depends_on = None


def upgrade():
    bind=op.get_bind()
    inspector=sa.inspect(bind)
    tables=set(inspector.get_table_names())
    user_cols={c['name'] for c in inspector.get_columns('users')}
    if 'password_hash' not in user_cols:
        op.add_column('users',sa.Column('password_hash',sa.String(500),nullable=True))
    # Google/Apple accounts may be email-only, so the legacy primary phone becomes optional.
    if bind.dialect.name == 'sqlite':
        with op.batch_alter_table('users') as batch:
            batch.alter_column('phone',existing_type=sa.String(32),nullable=True)
    else:
        op.alter_column('users','phone',existing_type=sa.String(32),nullable=True)
    if 'user_identities' not in tables:
        op.create_table(
            'user_identities',
            sa.Column('id',sa.String(36),primary_key=True),
            sa.Column('user_id',sa.String(36),sa.ForeignKey('users.id',ondelete='CASCADE'),nullable=False),
            sa.Column('kind',sa.String(24),nullable=False),
            sa.Column('value',sa.String(500),nullable=False),
            sa.Column('normalized_value',sa.String(500),nullable=False),
            sa.Column('is_verified',sa.Boolean(),nullable=False,server_default=sa.true()),
            sa.Column('is_primary',sa.Boolean(),nullable=False,server_default=sa.false()),
            sa.Column('created_at',sa.DateTime(timezone=True),nullable=False,server_default=sa.func.now()),
            sa.UniqueConstraint('kind','normalized_value',name='uq_identity_kind_value'),
        )
        op.create_index('ix_user_identities_user_id','user_identities',['user_id'])
        op.create_index('ix_user_identities_kind','user_identities',['kind'])
        op.create_index('ix_user_identities_normalized_value','user_identities',['normalized_value'])
        op.create_index('ix_user_identities_is_verified','user_identities',['is_verified'])
    # Preserve all existing accounts and promote their current phone/e-mail to verified identities.
    users=bind.execute(sa.text('SELECT id, phone, email FROM users')).mappings().all()
    for u in users:
        if u.get('phone'):
            bind.execute(sa.text("""INSERT INTO user_identities (id,user_id,kind,value,normalized_value,is_verified,is_primary,created_at)
                VALUES (:id,:uid,'phone',:v,:v,true,true,CURRENT_TIMESTAMP)
                ON CONFLICT (kind,normalized_value) DO NOTHING"""),{'id':__import__('uuid').uuid4().hex[:36],'uid':u['id'],'v':u['phone']})
        if u.get('email'):
            v=u['email'].strip().lower()
            bind.execute(sa.text("""INSERT INTO user_identities (id,user_id,kind,value,normalized_value,is_verified,is_primary,created_at)
                VALUES (:id,:uid,'email',:v,:v,true,true,CURRENT_TIMESTAMP)
                ON CONFLICT (kind,normalized_value) DO NOTHING"""),{'id':__import__('uuid').uuid4().hex[:36],'uid':u['id'],'v':v})


def downgrade():
    op.drop_table('user_identities')
    op.drop_column('users','password_hash')
    try:
        op.alter_column('users','phone',existing_type=sa.String(32),nullable=False)
    except Exception:
        pass
