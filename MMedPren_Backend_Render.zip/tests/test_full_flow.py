from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from fastapi.testclient import TestClient

from app.db import Base, get_db
from app.main import app
from app.models import User, UserRole, Role, Delivery

engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
TestingSession = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base.metadata.create_all(engine)

def override_db():
    db=TestingSession()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db]=override_db
client=TestClient(app)

def login(phone):
    r=client.post('/api/v1/auth/otp/request',json={'phone':phone}); assert r.status_code==200, r.text
    d=r.json(); assert d['debug_code']
    r=client.post('/api/v1/auth/otp/verify',json={'challenge_id':d['challenge_id'],'code':d['debug_code']}); assert r.status_code==200, r.text
    return r.json()['access_token'], r.json()['user']['id']

def auth(t): return {'Authorization':f'Bearer {t}'}

def test_complete_commerce_flow():
    admin_token,admin_id=login('+243970000001')
    db=TestingSession(); db.add(UserRole(user_id=admin_id,role=Role.ADMIN)); db.commit(); db.close()

    seller_token,_=login('+243970000002')
    r=client.post('/api/v1/sellers/apply',headers=auth(seller_token),json={'legal_name':'Ets Mundu ku Gundi W4F','business_name':'Poules Élevage','city':'Bukavu'})
    assert r.status_code==200, r.text
    sellers=client.get('/api/v1/admin/sellers',headers=auth(admin_token)); assert sellers.status_code==200, sellers.text
    seller_id=sellers.json()[0]['id']
    r=client.patch(f'/api/v1/admin/sellers/{seller_id}',headers=auth(admin_token),json={'status':'approved'}); assert r.status_code==200, r.text

    r=client.post('/api/v1/products',headers=auth(seller_token),json={'name':'Mangeoire grande capacité','description':'Équipement test','category':'Élevage','price':28,'currency':'USD','stock_qty':10})
    assert r.status_code==200, r.text
    product=r.json(); assert product['store_name']=='Poules Élevage'

    customer_token,_=login('+243970000003')
    r=client.post('/api/v1/orders',headers=auth(customer_token),json={'items':[{'product_id':product['id'],'quantity':2}],'delivery_name':'Client Test','delivery_phone':'+243970000003','delivery_address':'Bukavu, Ibanda','delivery_fee':2})
    assert r.status_code==200, r.text
    order=r.json(); assert float(order['total'])==58.0

    r=client.post('/api/v1/payments',headers=auth(customer_token),json={'order_id':order['id'],'provider':'sandbox','phone':'+243970000003'}); assert r.status_code==200, r.text
    payment=r.json()
    r=client.post(f"/api/v1/payments/{payment['id']}/sandbox/succeed",headers=auth(customer_token)); assert r.status_code==200, r.text

    courier_token,courier_id=login('+243970000004')
    r=client.post(f'/api/v1/admin/users/{courier_id}/roles/courier',headers=auth(admin_token)); assert r.status_code==200, r.text
    db=TestingSession(); delivery=db.query(Delivery).filter(Delivery.order_id==order['id']).first(); delivery_id=delivery.id; db.close()
    r=client.patch(f'/api/v1/admin/deliveries/{delivery_id}/assign',headers=auth(admin_token),json={'courier_id':courier_id}); assert r.status_code==200, r.text
    r=client.patch(f'/api/v1/deliveries/{delivery_id}/status',headers=auth(courier_token),json={'status':'delivered'}); assert r.status_code==200, r.text
    assert r.json()['status']=='delivered'


def test_admin_suspension_deletion_and_store_editing():
    admin_token, admin_id = login('+243970100001')
    db = TestingSession(); db.add(UserRole(user_id=admin_id, role=Role.ADMIN)); db.commit(); db.close()

    seller_token, _ = login('+243970100002')
    r = client.post('/api/v1/sellers/apply', headers=auth(seller_token), json={
        'legal_name': 'Entreprise Test', 'business_name': 'Elevage Initial', 'city': 'Bukavu'
    })
    assert r.status_code == 200, r.text
    seller_id = r.json()['id']

    r = client.patch(f'/api/v1/admin/sellers/{seller_id}', headers=auth(admin_token), json={'status': 'approved'})
    assert r.status_code == 200, r.text

    r = client.patch('/api/v1/sellers/me', headers=auth(seller_token), json={
        'business_name': 'Elevage Modifie', 'store_name': 'Boutique Elevage Modifie',
        'store_description': 'Nouvelle description', 'city': 'Goma'
    })
    assert r.status_code == 200, r.text
    assert r.json()['store']['name'] == 'Boutique Elevage Modifie'

    r = client.post('/api/v1/products', headers=auth(seller_token), json={
        'name': 'Produit cycle', 'description': 'test', 'category': 'Elevage',
        'price': 10, 'currency': 'USD', 'stock_qty': 3
    })
    assert r.status_code == 200, r.text
    product_id = r.json()['id']
    assert any(p['id'] == product_id for p in client.get('/api/v1/products').json())

    r = client.patch(f'/api/v1/admin/sellers/{seller_id}', headers=auth(admin_token), json={'status': 'suspended'})
    assert r.status_code == 200, r.text
    assert not any(p['id'] == product_id for p in client.get('/api/v1/products').json())
    admin_products = client.get('/api/v1/admin/products', headers=auth(admin_token)).json()
    assert next(p for p in admin_products if p['id'] == product_id)['effective_status'] == 'seller_suspended'

    r = client.patch(f'/api/v1/admin/sellers/{seller_id}', headers=auth(admin_token), json={'status': 'approved'})
    assert r.status_code == 200, r.text
    assert any(p['id'] == product_id for p in client.get('/api/v1/products').json())

    r = client.patch(f'/api/v1/admin/products/{product_id}', headers=auth(admin_token), json={'status': 'suspended'})
    assert r.status_code == 200, r.text
    assert not any(p['id'] == product_id for p in client.get('/api/v1/products').json())
    r = client.patch(f'/api/v1/admin/products/{product_id}', headers=auth(admin_token), json={'status': 'active'})
    assert r.status_code == 200, r.text

    # Admin can edit any shop, including a seeded/initial shop that is not their own seller profile.
    r = client.patch(f'/api/v1/admin/sellers/{seller_id}/profile', headers=auth(admin_token), json={
        'store_name': 'Elevage Admin', 'store_description': 'Editee par admin'
    })
    assert r.status_code == 200, r.text
    assert r.json()['seller']['store_name'] == 'Elevage Admin'

    r = client.delete(f'/api/v1/admin/products/{product_id}', headers=auth(admin_token))
    assert r.status_code == 200, r.text
    assert all(p['id'] != product_id for p in client.get('/api/v1/admin/products', headers=auth(admin_token)).json())

    r = client.post('/api/v1/products', headers=auth(seller_token), json={
        'name': 'Produit vendeur', 'description': 'test', 'category': 'Elevage',
        'price': 12, 'currency': 'USD', 'stock_qty': 2
    })
    assert r.status_code == 200, r.text
    r = client.delete(f'/api/v1/admin/sellers/{seller_id}', headers=auth(admin_token))
    assert r.status_code == 200, r.text
    assert r.json()['user_preserved'] is True
    assert client.get('/api/v1/sellers/me', headers=auth(seller_token)).status_code == 403

