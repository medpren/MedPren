from app.services.image_storage import detect_image_mime


def test_detect_image_mime():
    assert detect_image_mime(b"\xff\xd8\xff" + b"x" * 20) == "image/jpeg"
    assert detect_image_mime(b"\x89PNG\r\n\x1a\n" + b"x" * 20) == "image/png"
    assert detect_image_mime(b"RIFF" + b"1234" + b"WEBP" + b"x" * 20) == "image/webp"
    assert detect_image_mime(b"not-an-image") is None
