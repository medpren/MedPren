from app.security import otp_hash, verify_otp, create_access_token, decode_token
def test_otp_hash():
    h=otp_hash("123456"); assert verify_otp("123456",h); assert not verify_otp("654321",h)
def test_jwt():
    t=create_access_token("u1",["customer"]); p=decode_token(t); assert p["sub"]=="u1"
